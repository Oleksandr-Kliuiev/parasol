import { PrismaClient } from '@prisma/client';
import type { Prisma } from '@prisma/client';
import { AtlasError } from '../core/contracts.ts';
import { powerOfficeError } from './contracts.ts';
import type { PowerOfficeErrorCode } from './contracts.ts';

/**
 * The ONE original monotonic 10 s budget of a PowerOffice cleanup runner transaction (docs/stage4/03_DATA_AND_CONCURRENCY.md
 * "Explicit bounded maintenance"; S4C-rc1 review R1/R2). The deadline is fixed once, before the runner client exists, and is
 * never reset. It bounds every phase with ACTUAL database cancellation, not only a client-side check:
 *   - acquisition (connect/login/pool) and BEGIN: Prisma maxWait = the remaining budget; a structured acquisition timeout
 *     (PrismaClientInitializationError.errorCode / code P2024) is POWEROFFICE_CLEANUP_TIMEOUT — no callback, no SQL ran;
 *   - the server-side ABSOLUTE deadline: the first statement after BEGIN sets transaction-locally lock_timeout 1000 ms,
 *     statement_timeout ≤ remaining and transaction_timeout = remaining − ANCHOR_RESERVE_MS. PostgreSQL 17 arms that timer at
 *     the statement's arrival and never extends it within the transaction (re-setting it does not re-arm it); when it fires the
 *     server terminates the session and the transaction rolls back — during any later statement, while the client is idle
 *     between statements, and during COMMIT including deferred trigger work. The anchor is accepted only if its own round
 *     trip measured by the client is ≤ ANCHOR_RESERVE_MS: the server timer then started no later than the client receipt,
 *     so it fires at or before the original client deadline. A slower anchor fails closed (timeout, rollback, no retry);
 *   - every later statement: statement_timeout re-set to the remaining budget and a client check before it is sent;
 *   - a client check before the callback returns (COMMIT); COMMIT itself is bounded by the server timer above.
 * The client never returns before the database outcome is settled ($transaction awaits COMMIT/ROLLBACK); Prisma's own
 * transaction timeout is only a backstop set beyond the budget so it cannot misreport a commit that the server completed
 * before the deadline. The single residual is PostgreSQL's atomic commit point itself (interrupts are held while the commit
 * record is written). Fixed outcomes, no raw message is read or echoed: timeouts (own marker, SQLSTATE 57014/55P03/25P03/
 * 25P04, Prisma P2024/P2028, initialization errorCode P2024/P1002/P1001, or any failure once the server deadline window
 * [deadline − reserve, deadline] is reached) are POWEROFFICE_CLEANUP_TIMEOUT; 40P01/40001 POWEROFFICE_DB_CONFLICT; other
 * client initialization failures (authentication P1000, unknown database/role, …) POWEROFFICE_RUNTIME_NOT_READY; anything
 * else POWEROFFICE_CLEANUP_FAILED. Never retried.
 */
export const CLEANUP_BUDGET_MS = 10_000;
export const CLEANUP_LOCK_TIMEOUT_MS = 1_000;
export const ANCHOR_RESERVE_MS = 250;
/** Client backstop beyond the budget: Prisma must not abandon a COMMIT the server already bounded and may have completed. */
export const CLIENT_BACKSTOP_MS = 2_000;

export interface Budget { readonly left: () => number }
/** Starts the original budget now (before the runner client exists). */
export function startBudget(now: () => number = () => performance.now()): Budget {
  const deadline = now() + CLEANUP_BUDGET_MS;
  return Object.freeze({ left: () => Math.floor(deadline - now()) });
}

/** Private marker: the client observed the original budget exhausted (never a raw error, never exported). */
const budgetMarkers = new WeakSet<object>();
function spent(): never { const marker = powerOfficeError('POWEROFFICE_CLEANUP_TIMEOUT'); budgetMarkers.add(marker); throw marker; }

const TIMEOUT_STATES: ReadonlySet<string> = new Set(['57014', '55P03', '25P03', '25P04']);
const TIMEOUT_CODES: ReadonlySet<unknown> = new Set(['P2024', 'P2028']);
/**
 * Client initialization codes that mean the connection/login did not complete in time: P2024 (pool/acquisition wait),
 * P1002 (server reached, timed out) and P1001 (connect timeout). The runner target is proven identical to the runtime
 * target that just served the admission, so these are acquisition timeouts, not a misconfigured target. Authentication
 * (P1000), a missing database/role and every other initialization failure stay POWEROFFICE_RUNTIME_NOT_READY.
 */
const INIT_TIMEOUT_CODES: ReadonlySet<unknown> = new Set(['P2024', 'P1002', 'P1001']);
const PASSED: ReadonlySet<string> = new Set(['POWEROFFICE_RUNTIME_NOT_READY', 'POWEROFFICE_SYNC_BUSY', 'POWEROFFICE_CLEANUP_FAILED']);
/** SQLSTATE from structured fields only: Prisma's meta.code, or a driver error's own 5-character code. Never the message. */
function structuredState(error: unknown): string | undefined {
  const e = error as { code?: unknown; meta?: { code?: unknown }; clientVersion?: unknown } | null;
  if (typeof e?.meta?.code === 'string') return e.meta.code;
  return e?.clientVersion === undefined && typeof e?.code === 'string' && /^[0-9A-Z]{5}$/.test(e.code) ? e.code : undefined;
}
/** Structured fields only (name, code, errorCode, SQLSTATE); messages are never parsed for the decision or echoed. */
export function runnerFailure(error: unknown, budget: Budget): PowerOfficeErrorCode {
  if (typeof error === 'object' && error !== null && budgetMarkers.has(error)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (error instanceof AtlasError && PASSED.has(error.code)) return error.code as PowerOfficeErrorCode;
  const e = error as { name?: unknown; code?: unknown; errorCode?: unknown } | null;
  const state = structuredState(error);
  if ((state !== undefined && TIMEOUT_STATES.has(state)) || TIMEOUT_CODES.has(e?.code) || TIMEOUT_CODES.has(e?.errorCode)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (state === '40P01' || state === '40001' || e?.code === 'P2034') return 'POWEROFFICE_DB_CONFLICT';
  if (budget.left() <= ANCHOR_RESERVE_MS) return 'POWEROFFICE_CLEANUP_TIMEOUT'; // the server deadline window was reached
  if (e?.name === 'PrismaClientInitializationError') return INIT_TIMEOUT_CODES.has(e.errorCode) ? 'POWEROFFICE_CLEANUP_TIMEOUT' : 'POWEROFFICE_RUNTIME_NOT_READY';
  return 'POWEROFFICE_CLEANUP_FAILED';
}

/** The statement helper handed to the body: re-bounds statement_timeout to the remaining budget before each statement. */
export interface Bounded { statement(): Promise<void>; check(): void }

/**
 * One runner transaction on `url` under `budget`. `body` runs after the anchor; it must call `bounded.statement()` before
 * each of its statements. Throws the fixed failure code; returns only after the database outcome is settled.
 */
export async function runBoundedTransaction<T>(url: string, budget: Budget, body: (tx: Prisma.TransactionClient, bounded: Bounded) => Promise<T>): Promise<T> {
  if (budget.left() < 1) spent();
  const runner = new PrismaClient({ datasourceUrl: url });
  try {
    const maxWait = Math.max(1, budget.left());
    return await runner.$transaction(async tx => {
      const check = () => { if (budget.left() < 1) spent(); };
      // The anchor: first statement after BEGIN, before any lock, readiness or routine call.
      const ms = budget.left() - ANCHOR_RESERVE_MS;
      if (ms < 1) spent();
      const sent = performance.now();
      await tx.$executeRawUnsafe(`SELECT set_config('lock_timeout', $1, true), set_config('statement_timeout', $2, true), set_config('transaction_timeout', $3, true)`,
        `${CLEANUP_LOCK_TIMEOUT_MS}ms`, `${Math.min(ms, CLEANUP_BUDGET_MS)}ms`, `${ms}ms`);
      if (performance.now() - sent > ANCHOR_RESERVE_MS) spent(); // the server timer could otherwise start too late
      const bounded: Bounded = {
        check,
        async statement() {
          check();
          await tx.$executeRawUnsafe(`SELECT set_config('statement_timeout', $1, true)`, `${Math.min(budget.left(), CLEANUP_BUDGET_MS)}ms`);
          check();
        },
      };
      const result = await body(tx, bounded);
      check(); // pre-COMMIT; COMMIT itself stays under the server-side transaction_timeout
      return result;
    }, { maxWait, timeout: maxWait + CLIENT_BACKSTOP_MS });
  } catch (error) {
    throw powerOfficeError(runnerFailure(error, budget));
  } finally {
    await runner.$disconnect().catch(() => undefined);
  }
}

# Stage 4 data isolation and concurrency

## Scoped tables

Add prisma/poweroffice.prisma and additive migrations only. Every row has workspaceId,clientId,connectionId and scoped
Connection FK; every cross-row reference includes that scope. FORCE RLS and transaction-local app scope apply to all
new tables. Runtime cannot own tables or have BYPASSRLS. All identity fields are immutable; SQL CHECKs explicitly reject
NULL for mandatory fields, not SQL UNKNOWN. Named invoker triggers have fixed search_path and revoked PUBLIC EXECUTE,
so the accepted Stage3 fence definer gains no callable routine or relation privilege.

| Table | Identity and state |
|---|---|
| PowerOfficeState | PK(scope,connection); nextSequence>=1; nullable activeAttemptId; nullable snapshotId+snapshotVersion; lastAttemptId/state/code, lastSuccessAt; updatedAt (lastAttemptId nullable until first claim) |
| PowerOfficeAttempt | PK(scope,connection,id UUID); unique(scope,connection,sequence); immutable claimToken UUID, allocatedSnapshotId UUID, lifecycleVersion, actorId, correlationId, startedAt, readDeadlineAt, deadlineAt; state ACTIVE|SUCCEEDED|FAILED|ABANDONED; completedAt/code nullable until terminal |
| PowerOfficeSnapshot | PK(scope,connection,id UUID); scoped attempt FK; lifecycleVersion; asOf, businessDate, publishedAt, expiresAt; strict bounded aggregate JSON; synthetic marker |

Attempt.actorId has a workspace-scoped Actor FK; the connection FK fixes its client scope.
State active pointer uses a scoped FK to attempt; snapshotId+snapshotVersion uses a scoped FK to snapshot including its
lifecycleVersion. Partial-null pairs are invalid. State.lastAttemptId also has a scoped attempt FK.
Snapshot has unique(scope,connection,id,lifecycleVersion) and one snapshot
per attempt. allocatedSnapshotId is an allocated UUID, not a reference to a possibly nonexistent row. Snapshots are immutable.
A partial unique index permits only one ACTIVE attempt per scoped connection. ACTIVE means completedAt/code are null;
terminal means completedAt non-null. Exact startedAt+60s readDeadlineAt and startedAt+80s deadlineAt are constrained.
Snapshot asOf=attempt.startedAt, publishedAt>=asOf and<attempt.deadlineAt, expiresAt=publishedAt+24h; synthetic marker fixed.
A scoped Snapshot→Attempt FK includes lifecycleVersion and asOf→startedAt, backed by a matching attempt UNIQUE identity.
Aggregate JSON validation in TS and SQL enforces02 fields/types/counts/amount bounds and no extras. State/attempt lifecycle
triggers prohibit terminal revival, sequence rewind, claim replacement, identity mutation or pointer to an uncommitted snapshot.
Deferrable constraint triggers check at COMMIT that active pointers name ACTIVE attempts and published snapshot pointers
name committed SUCCEEDED attempts. FAILED/ABANDONED require fixed codes; SUCCEEDED requires no error code.
All state/pointer/snapshot/attempt publication changes are one commit with client audit.

## Lock order and admission

All new transactions use workspace authority fence → Connection FOR SHARE → State FOR UPDATE → Attempt FOR UPDATE
(if involved) → Snapshot (if involved). Maintenance takes the same order; new DDL helpers must not acquire earlier locks
from later positions. Never hold a transaction, fence or row lock over port I/O. Fence completeness/readiness remains
mandatory; corrupt/incomplete fence refuses, with documented offline repair only. New code never advances Connection
lifecycle/status, so it cannot acquire the fence via a late Connection UPDATE trigger.

Initialize the state with ON CONFLICT DO NOTHING then lock it, under the earlier locks. First authenticate for a workspace
hint, then lock its exact fence; re-authenticate and recheck the binding/current client permissions after ALL locks using
DB clock. After an attempt lock, reread caller expiry again; no cached pre-lock authorization or clocks. Record one current
ACTIVE attempt and monotonically allocated sequence atomically before any port call. Existing ACTIVE returns BUSY even
when expired; explicit recover at deadlineAt or later marks ABANDONED, clears the pointer, never publishes its pages.

Publication locks in the same order, requires the exact private attempt token/ID/sequence/version and ACTIVE row,
DB clock<deadlineAt, unchanged FIXTURE binding and fresh current sync authority. It commits snapshot, state pointer,
SUCCEEDED and audit together. Publication cannot return partially updated state. Stale/abandoned/expired identity refuses
with no financial data written. A committed identical publication is a no-op with no duplicate audit, even if the caller
receives an ambiguous commit response; sequence and allocatedSnapshotId provide stable identity.

Only known rollback40P01/40001 permits at most3 transaction attempts to record the SAME complete in-memory aggregate,
allocated snapshot and audit identity; every retry rechecks current authority/deadline/binding and calls no port. Admission,
page authorization, ordinary reads, recovery and cleanup do not automatically retry. Exhaustion returns PUBLICATION_CONFLICT,
leaving the active attempt recoverable. No generic fallback that converts an unknown commit into a new export.

An owned private failure continuation may close its own still-ACTIVE attempt as FAILED and clear its active pointer after
caller revocation or binding loss, with fixed error and audit only. It carries no permission for a read, source call or
snapshot publication. It uses the same lock order and checks exact attempt ownership; it preserves the last snapshot.
Its terminal replay is no-op. After lease expiry it does not mutate; recover handles it. A failed attempt-audit transaction
leaves ACTIVE intact and a fixed error; no raw error, silent audit suppression or second export. Failure recording may use
the same bounded known-rollback transaction policy; no new authority/clock window is minted.

## Role readiness and compatibility

Runtime privileges on the new tables are exact: SELECT all; INSERT state/attempt/snapshot; UPDATE only State operational
pointers/sequence/outcomes and Attempt state/completedAt/safeErrorCode. No UPDATE of immutable identities, tokens,
version/times/aggregates; no DELETE/TRUNCATE, sequence ownership, broad definer EXECUTE or new ApiToken visibility.
Extend startup assertRuntimeRole with the same exact allowlist; existing role and Stage3 fence-definer checks stay strict.
Old upgrade fixtures/reports/migrations remain byte-exact. New permission values change only the membership CHECK, not
membership assignments. Role/test renderers must support the two new maintenance roles without weakening old exact-role tests.
Stage1 resolveConnection/resolveCredential must refuse PowerOffice with a fixed unavailable code before any resolver;
only the new private composition can use it. Generic bindConnection's bindable-system allowlist stays unchanged.

## Retention maintenance

New EXECUTE-only PowerOffice cleanup runner and dedicated SECURITY DEFINER owner, separate from the M365 runner/definer.
The function takes validated workspace/client/connection and DB time only (no caller clock, arbitrary SQL, table/path or
summary). Trusted operator CLI first performs fresh maintain admission, then calls it on the separate runner; the owner's
admitted one-connection cleanup may complete after subsequent revocation, like the accepted Stage2 maintenance boundary.
It never returns data, only local outcome/count metadata to the CLI; counts never enter audit. Fixed search_path=pg_catalog,public,
REVOKE PUBLIC, no runtime or Stage3 definer EXECUTE, no membership/auth/credentials access, no table ownership/BYPASSRLS.

Its role has only Connection/fence scoped SELECT, fence UPDATE(workspaceId) privilege solely for SELECT FOR UPDATE locking (never execute an UPDATE), state SELECT and pointer
UPDATE, attempt SELECT/DELETE, snapshot SELECT/DELETE, audit INSERT. FORCE policies are dedicated to that role and parameters;
no cross-client policy or table-wide runtime grant. Validate immutable binding identifiers, lock order, predicate scope and
row counts in the function; acquire the existing fence first. If an ACTIVE attempt exists, return BUSY (even expired; recover
first). Recovery accepts a DISABLED or advanced-lifecycle connection in the same immutable synthetic binding, and closes
only the old attempt; it grants no snapshot publication or source call. Purge expired snapshots and clear current pointer before deletion atomically with safe audit. Delete terminal
attempts older than30days only when neither a snapshot nor State.lastAttemptId/activeAttemptId references them; never delete
ACTIVE or reset nextSequence. Last-attempt metadata may retain one terminal attempt beyond30days. Max1000rows
per call, max10s transaction, no automatic loop; timeout rolls everything back. If more remain, return morePending boolean.
Purge is explicit even for DISABLED or advanced-lifecycle connections (no source I/O); it validates the same immutable
PowerOffice synthetic binding/scope but does not require the old snapshot lifecycle to equal the current one. Expiry
cannot be defeated by disabling a connection. Purge snapshot rows first, then unreferenced old attempts within the combined1000row
budget; recompute morePending on scoped eligible rows. No unbounded scan/materialization before the bounded deletion.

Reads suppress expired payload regardless of cleanup availability. Lifetime metadata growth is bounded operationally by
cleanup; a connection with1000retained attempts refuses new sync with SYNC_LIMIT until maintenance removes eligible rows.
The runner capability and runtime URL must be verified against the same DB target without logging URLs; do not grant an
arbitrary app process the runner credentials. Provision only in disposable tests until separate pilot admission.

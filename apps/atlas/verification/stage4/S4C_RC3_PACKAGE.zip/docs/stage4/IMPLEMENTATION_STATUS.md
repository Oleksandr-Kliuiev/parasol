# Stage 4 implementation status

Architecture: **S4-design-rc2 DUAL APPROVED**, unchanged eight-file package. Latest code checkpoint: **S4-B ACCEPTED on S4B-rc2**
by a fresh explicit GPT-6 Astra/xhigh actual-code review. [S4-B acceptance](reviews/ASTRA_S4B_RC2.md) · [architecture](REVIEW_STATUS.md) · [plan](05_IMPLEMENTATION_PLAN.md).

| Checkpoint | State |
|---|---|
| S4-A DTO, schema, isolation, exact roles and compatibility | ACCEPTED — S4A-rc5, fresh Astra/xhigh |
| S4-B synthetic sync, publication and recovery | ACCEPTED — S4B-rc2, fresh Astra/xhigh |
| S4-C dedicated reads/API/CLI and maintenance | RC3 IMPLEMENTED —217/217 unit +558/558 PG; fresh Astra/xhigh acceptance PENDING |
| S4-LIVE current vendor contract and explicit read admission | NOT_STARTED — DEFERRED_BY_OWNER |

S4-A includes strict immutable normalized DTOs, BigInt currency summaries and Oslo dates, complete bounded exports,
private bearer authority with final under-lock checks, three scoped FORCE-RLS tables with deferred history invariants,
exact runtime/maintenance roles and readiness, synthetic binding integrity, bounded SQL cleanup foundation and generic
connection exclusion. It does not expose a source service or public PowerOffice entry point.

Final required checks on exact RC5 source: **196/196 unit/PGlite +475/475 PostgreSQL**, schema validation/generation,
typecheck, API build/smoke, PostgreSQL17, schema drift and whitespace — all passed. Native actual Opus5.5/high implemented
and repaired S4-A in one session, native Anthropic subscription, no credits/API/fallback. Attributable quota is unknown.
[Evidence](../../verification/stage4/S4A_RC5_IMPLEMENTATION_EVIDENCE.json) · seal `verification/stage4/S4A_APPROVED.json`.

[RC1 review](reviews/ASTRA_S4A_RC1.md) remains CHANGES_REQUIRED in preserved history. Later packages close its four findings:
maintenance-role routine confinement across schemas/access paths, actual DB-clock deadline despite backdated timestamps,
full paired binding proof without credential visibility, and irreversible disposal of incomplete exports. Cleanup,
provisioning and readiness also require the exact installed binding-constraint definition. RC5 also closes subsequent foreign-schema relation, TEMP-routine and schema-authority gaps, plus builtin and large-object
ACL paths. RC4 closes PG17 MAINTAIN and nondefault PUBLIC tablespace CREATE gaps; RC5 closes all runtime table/column grant-option paths. Shared/builtin drift tests now remain uncommitted, with a separate observer proving invisibility. The PGlite compatibility path and independent RC5 verification
and any residual qualifications are recorded in the acceptance report; implementer test results alone are not acceptance.

Acceptance qualification: the new grant-option and builtin/shared/global/host-capable ACL probes always roll back.
Existing disposable-DB tests also commit DB-local synthetic PUBLIC fixtures (one-byte LO, NO HANDLER FDW/server,
synthetic relations/routines) with repair/drop cleanup. The universal no-PUBLIC-commit wording in frozen RC5 notes is
too broad and is qualified by the exact acceptance report and seal.

S4-B implements built-in MOCK source sessions, durable claims, fresh page authority, complete export, atomic publication,
owned failure and explicit recovery, with concurrency, retry/replay, cancellation and privacy evidence. S4-C retains fresh maintain admission, paired runner DB verification, original
whole-transaction10s cancellation/1s lock timeout wrapper, dedicated read API/CLI and associated privacy/error journeys.

Accepted Stage1/2/3 norms, installed20 migrations+lock and history remain unchanged. Final verification used disposable
DBs and rollback-only shared-catalog drift. An earlier committed PUBLIC parameter test grant was restored, then the test
was corrected; the exact qualification and zero-residue probe are preserved in RC3/RC4/RC5 orchestration notes. No PowerOffice
account/vendor API/auth, persistent DB/pilot setup, binding command, deployment,
financial write or background schedule was performed. MOCK acceptance does not establish LIVE/accounting readiness.

S4-B implementation authorized2026-10-09 from exact accepted S4A-rc5; [bounded brief](S4B_IMPLEMENTATION_BRIEF.md). S4-A seal/history stays immutable; S4-C/LIVE remain separate.

Historical [S4-B RC1 review](reviews/ASTRA_S4B_RC1.md) remains CHANGES_REQUIRED. Its R1 completed-fact provenance finding was fixed in the same native Opus5.5/high session and closed by fresh Astra/xhigh acceptance on RC2. Prior artifacts remain unchanged.

S4-B actual-code acceptance: [Astra/xhigh RC2](reviews/ASTRA_S4B_RC2.md), exact seal `verification/stage4/S4B_APPROVED.json`.
Final208 unit/PGlite +510 PostgreSQL tests and all11required checks passed.
Native actual Opus5.5/high, native subscription/no credits or fallback; quota attribution unknown.
FK tuple-lock qualification and independent verification are recorded in the exact acceptance report.
Next is S4-C dedicated reads/API/CLI and maintenance. LIVE remains DEFERRED_BY_OWNER.

S4-C authorized2026-10-10: [bounded brief](S4C_IMPLEMENTATION_BRIEF.md). Exact baseline/preflight in verification/stage4/S4C_BASELINE.json and S4C_PREFLIGHT.json. Native Opus5.5/high implementation; fresh Astra/xhigh acceptance required.

S4-C code/checks complete: [implementation report](S4C_IMPLEMENTATION_REPORT.md). All11 required checks passed. Codex regained write ownership after native Opus exited; exact S4C-rc1 package is being frozen for fresh independent Astra/xhigh. No architecture amendment; LIVE remains deferred.

Fresh [S4-C RC1 review](reviews/ASTRA_S4C_RC1.md) found a reproducible late COMMIT beyond the original10s and login-timeout misclassification. Acceptance withheld; exact original report/probes preserved. Repair in the same native Opus5.5/high session, then new artifact and fresh Astra/xhigh review because deadline/atomicity are critical invariants.

RC2 repairs original10s cleanup COMMIT coverage and structured acquisition-timeout classification in the SAME native Opus5.5/high session. [Repair report](S4C_RC2_IMPLEMENTATION_REPORT.md); all11 required checks passed. RC1 CHANGES_REQUIRED history remains immutable. Critical deadline/cancellation changes require fresh Astra/xhigh acceptance.

Fresh [S4-C RC2 review](reviews/ASTRA_S4C_RC2.md) found reproducible late COMMIT beyond the original10s when the runner inherits a nonzero transaction_timeout. Acceptance withheld; exact original report/probes preserved. Repair in the same native Opus5.5/high session, then new artifact and fresh Astra/xhigh review because deadline/atomicity are critical invariants.

RC3 establishes runner timer settings on one dedicated connection BEFORE BEGIN, including inherited role/database/startup settings; all11 required checks passed. [RC3 report](S4C_RC3_IMPLEMENTATION_REPORT.md). Existing pinned pg moved to runtime dependencies with production-install/import, unit217/217, PG maintenance6/6 and typecheck checks; no dependency versions/integrities changed. Original Opus session retained. Fresh Astra/xhigh required; prior RC1/RC2 findings/history preserved.

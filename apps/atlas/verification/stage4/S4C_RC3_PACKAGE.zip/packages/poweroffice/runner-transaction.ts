import { AtlasError } from '../core/contracts.ts';
import { powerOfficeError } from './contracts.ts';
import type { PowerOfficeErrorCode } from './contracts.ts';

/**
 * The ONE original monotonic 10 s budget of a PowerOffice cleanup runner transaction (docs/stage4/03_DATA_AND_CONCURRENCY.md
 * "Explicit bounded maintenance"; Astra S4C-rc1 R1/R2, S4C-rc2 R1). The deadline is fixed once, before the runner connection
 * exists, and never reset. It bounds every phase with ACTUAL server-side cancellation on ONE explicit connection:
 *   1. acquisition: one dedicated `pg` client (never a pool) connects within min(remaining budget, the paired URL's
 *      connect_timeout, Prisma's 5 s default when absent). Nothing else runs on it; it is closed at the end.
 *   2. BEFORE BEGIN, on that same session: the inherited timeouts are read, then transaction_timeout = remaining −
 *      ANCHOR_RESERVE_MS, statement_timeout ≤ it, lock_timeout 1000 ms (each lowered to a STRICTER positive inherited value,
 *      never raised) and search_path (the paired URL's Prisma `schema`, default public) are set as SESSION settings; the
 *      effective values are read back from pg_settings and must be exactly these with source "session" — replacing any
 *      inherited role, database, user or connection-startup value (verified on PG17). PostgreSQL arms its transaction timer
 *      when a transaction STARTS and never replaces an active one; the previous implicit transactions end before BEGIN, so
 *      BEGIN arms the timer with exactly this value (an in-transaction set — the RC2 design — cannot replace a timer that an
 *      inherited setting armed at BEGIN). From compute to the BEGIN reply the client measures ≤ ANCHOR_RESERVE_MS, so the
 *      server timer fires no later than the original client deadline; slower setup fails closed (ROLLBACK, timeout, no retry).
 *   3. inside: before every statement a client budget check and statement_timeout re-set to the remaining budget; when the
 *      server timer fires PostgreSQL terminates the session and rolls back — during a statement, while idle between
 *      statements, and during COMMIT including deferred trigger work.
 *   4. a pre-COMMIT client check, then COMMIT awaited; a failure sends ROLLBACK (best effort) and closes the connection. The
 *      client returns only after the database outcome settled; there is no client-side race against the database.
 * The only residual is PostgreSQL's atomic commit point (interrupts are held while the commit record is written).
 * Classification uses structured fields only (name, code, errorCode, SQLSTATE, own timers), never message text, and echoes
 * nothing: own budget/connect-timer markers, SQLSTATE 57014/55P03/25P03/25P04, Prisma P2024/P2028 and initialization
 * errorCode P2024/P1002/P1001, or any failure inside the server deadline window [deadline − reserve, deadline] →
 * POWEROFFICE_CLEANUP_TIMEOUT; 40P01/40001/P2034 → POWEROFFICE_DB_CONFLICT; a refused connection/authentication/missing
 * database or role (28xxx/3D000/08xxx, socket errors, Prisma initialization) → POWEROFFICE_RUNTIME_NOT_READY; anything else
 * POWEROFFICE_CLEANUP_FAILED. Never retried. Requires PostgreSQL 17 (transaction_timeout).
 */
export const CLEANUP_BUDGET_MS = 10_000;
export const CLEANUP_LOCK_TIMEOUT_MS = 1_000;
export const ANCHOR_RESERVE_MS = 250;
/** Prisma's documented connect_timeout default (seconds) — the paired URL's semantics are kept for this transport. */
export const DEFAULT_CONNECT_TIMEOUT_S = 5;

export interface Budget { readonly left: () => number }
/** Starts the original budget now (before the runner connection exists). */
export function startBudget(now: () => number = () => performance.now()): Budget {
  const deadline = now() + CLEANUP_BUDGET_MS;
  return Object.freeze({ left: () => Math.floor(deadline - now()) });
}

/** Private markers: the client observed the budget exhausted / its own connect timer expired (never raw, never exported). */
const budgetMarkers = new WeakSet<object>();
function spent(): never { const marker = powerOfficeError('POWEROFFICE_CLEANUP_TIMEOUT'); budgetMarkers.add(marker); throw marker; }

const TIMEOUT_STATES: ReadonlySet<string> = new Set(['57014', '55P03', '25P03', '25P04']);
const TIMEOUT_CODES: ReadonlySet<unknown> = new Set(['P2024', 'P2028']);
/** Prisma initialization codes of a connection/login that did not complete in time (kept from RC2 for any Prisma caller). */
const INIT_TIMEOUT_CODES: ReadonlySet<unknown> = new Set(['P2024', 'P1002', 'P1001']);
const PASSED: ReadonlySet<string> = new Set(['POWEROFFICE_RUNTIME_NOT_READY', 'POWEROFFICE_SYNC_BUSY', 'POWEROFFICE_CLEANUP_FAILED']);
/** SQLSTATE from structured fields only: Prisma's meta.code, or a driver error's own 5-character code. Never the message. */
function structuredState(error: unknown): string | undefined {
  const e = error as { code?: unknown; meta?: { code?: unknown }; clientVersion?: unknown } | null;
  if (typeof e?.meta?.code === 'string') return e.meta.code;
  return e?.clientVersion === undefined && typeof e?.code === 'string' && /^[0-9A-Z]{5}$/.test(e.code) ? e.code : undefined;
}
/** Structured fields only (name, code, errorCode, SQLSTATE); messages are never parsed for the decision or echoed. */
export function runnerFailure(error: unknown, budget: Budget): PowerOfficeErrorCode {
  if (typeof error === 'object' && error !== null && budgetMarkers.has(error)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (error instanceof AtlasError && PASSED.has(error.code)) return error.code as PowerOfficeErrorCode;
  const e = error as { name?: unknown; code?: unknown; errorCode?: unknown } | null;
  const state = structuredState(error);
  if ((state !== undefined && TIMEOUT_STATES.has(state)) || TIMEOUT_CODES.has(e?.code) || TIMEOUT_CODES.has(e?.errorCode)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (state === '40P01' || state === '40001' || e?.code === 'P2034') return 'POWEROFFICE_DB_CONFLICT';
  if (budget.left() <= ANCHOR_RESERVE_MS) return 'POWEROFFICE_CLEANUP_TIMEOUT'; // the server deadline window was reached
  if (e?.name === 'PrismaClientInitializationError') return INIT_TIMEOUT_CODES.has(e.errorCode) ? 'POWEROFFICE_CLEANUP_TIMEOUT' : 'POWEROFFICE_RUNTIME_NOT_READY';
  return 'POWEROFFICE_CLEANUP_FAILED';
}
/** A connection that never became usable: our connect timer → timeout; refused/authentication/unknown target → readiness. */
function connectFailure(error: unknown, timedOut: boolean, budget: Budget): PowerOfficeErrorCode {
  if (timedOut || budget.left() <= ANCHOR_RESERVE_MS) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  const state = structuredState(error);
  if (state !== undefined && TIMEOUT_STATES.has(state)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  return 'POWEROFFICE_RUNTIME_NOT_READY';
}

/** One query on the runner's single connection: rows of a parameterized statement. */
export type RunnerQuery = <R>(sql: string, ...params: unknown[]) => Promise<R[]>;
/** The statement helper handed to the body: re-bounds statement_timeout to the remaining budget before each statement. */
export interface Bounded { statement(): Promise<void>; check(): void }

/** Paired-URL options this transport keeps: Prisma's `schema` (search_path) and `connect_timeout` (seconds). */
function urlOptions(url: string): { schema: string; connectTimeoutMs: number } {
  const u = new URL(url);
  const schema = u.searchParams.get('schema') ?? 'public';
  const raw = u.searchParams.get('connect_timeout');
  const seconds = raw === null ? DEFAULT_CONNECT_TIMEOUT_S : /^[0-9]{1,4}$/.test(raw) ? Number(raw) : NaN;
  if (!/^[A-Za-z_][A-Za-z0-9_]{0,62}$/.test(schema) || !Number.isFinite(seconds)) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
  return { schema, connectTimeoutMs: seconds === 0 ? Infinity : seconds * 1000 };
}

interface PgClient {
  connect(): Promise<void>; query(sql: string, params?: unknown[]): Promise<{ rows: unknown[] }>; end(): Promise<void>; on(event: string, listener: (e: unknown) => void): unknown;
}
async function pgClient(url: string, connectionTimeoutMillis: number): Promise<PgClient> {
  let pg: { Client: new (config: object) => PgClient };
  try { pg = (await import('pg')).default as unknown as typeof pg; } catch { throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY'); }
  return new pg.Client({ connectionString: url, connectionTimeoutMillis });
}

/**
 * One runner transaction on `url` under `budget`. `body` runs inside it and must call `bounded.statement()` before each of
 * its statements. Throws the fixed failure code; returns only after the database outcome is settled.
 */
export async function runBoundedTransaction<T>(url: string, budget: Budget, body: (query: RunnerQuery, bounded: Bounded) => Promise<T>): Promise<T> {
  if (budget.left() < 1) spent();
  const options = urlOptions(url);
  const connectMs = Math.max(1, Math.min(budget.left(), options.connectTimeoutMs));
  const client = await pgClient(url, connectMs);
  client.on('error', () => undefined); // a server-terminated session surfaces on the pending query; never an unhandled event
  const query: RunnerQuery = async <R>(sql: string, ...params: unknown[]) => (await client.query(sql, params)).rows as R[];
  const started = performance.now();
  try { await client.connect(); } catch (error) {
    await client.end().catch(() => undefined);
    throw powerOfficeError(connectFailure(error, performance.now() - started >= connectMs - 1, budget));
  }
  let open = false;
  try {
    const check = () => { if (budget.left() < 1) spent(); };
    // Session settings BEFORE BEGIN on this very connection; then BEGIN arms the server timer with exactly this value. An
    // inherited (role/database/user/startup) value is honored only when it is STRICTER; it never extends either bound.
    const computed = performance.now();
    const inherited = await query<{ name: string; ms: number }>(`SELECT name, setting::int AS ms FROM pg_catalog.pg_settings
      WHERE name IN ('transaction_timeout', 'statement_timeout', 'lock_timeout')`);
    const stricter = (name: string, ours: number) => { const v = inherited.find(r => r.name === name)?.ms; return v !== undefined && v > 0 && v < ours ? v : ours; };
    if (inherited.length !== 3) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
    const remaining = budget.left() - ANCHOR_RESERVE_MS;
    if (remaining < 1) spent();
    const ms = stricter('transaction_timeout', remaining);
    const statementMs = stricter('statement_timeout', Math.min(ms, CLEANUP_BUDGET_MS));
    const lockMs = stricter('lock_timeout', CLEANUP_LOCK_TIMEOUT_MS);
    await query(`SELECT set_config('transaction_timeout', $1, false), set_config('statement_timeout', $2, false), set_config('lock_timeout', $3, false),
      set_config('search_path', $4, false)`, `${ms}ms`, `${statementMs}ms`, `${lockMs}ms`, options.schema);
    const effective = await query<{ name: string; setting: string; source: string }>(`SELECT name, setting, source FROM pg_catalog.pg_settings
      WHERE name IN ('transaction_timeout', 'statement_timeout', 'lock_timeout') ORDER BY name`);
    const expected: Record<string, string> = { lock_timeout: String(lockMs), statement_timeout: String(statementMs), transaction_timeout: String(ms) };
    if (effective.length !== 3 || effective.some(r => r.setting !== expected[r.name] || r.source !== 'session')) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
    await client.query('BEGIN');
    open = true;
    if (performance.now() - computed > ANCHOR_RESERVE_MS) spent(); // the server timer could otherwise end after the deadline
    const bounded: Bounded = {
      check,
      async statement() {
        check();
        await query(`SELECT set_config('statement_timeout', $1, true)`, `${Math.max(1, Math.min(budget.left(), statementMs))}ms`);
        check();
      },
    };
    const result = await body(query, bounded);
    check(); // pre-COMMIT; COMMIT itself stays under the server-side transaction timer armed at BEGIN
    await client.query('COMMIT');
    open = false;
    return result;
  } catch (error) {
    if (open) await client.query('ROLLBACK').catch(() => undefined);
    throw powerOfficeError(runnerFailure(error, budget));
  } finally {
    await client.end().catch(() => undefined);
  }
}

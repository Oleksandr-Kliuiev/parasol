# Stage 4 implementation status

Architecture checkpoint: **S4-design-rc2 DUAL APPROVED** by fresh explicit Astra/xhigh and native Fable5.1/high on the
same frozen artifact. Code: **S4-A IN_PROGRESS**; independent code acceptance pending. [Review status](REVIEW_STATUS.md) · [plan](05_IMPLEMENTATION_PLAN.md).

| Checkpoint | State |
|---|---|
| S4-A DTO, schema, isolation, exact roles and compatibility | RC3 PENDING_REVIEW — full confinement repair and safe rollback tests; fresh Astra/xhigh pending |
| S4-B synthetic sync, publication and recovery | NOT_STARTED — accepted S4-A required |
| S4-C dedicated reads/API/CLI and maintenance | NOT_STARTED — accepted S4-B required |
| S4-LIVE current vendor contract and explicit read admission | NOT_STARTED — DEFERRED_BY_OWNER |

This is MOCK-only design acceptance. Existing accepted Stage1/2/3 code is preserved. No PowerOffice account/API/token
operation, persistent DB/pilot setup, binding, deployment, financial write or background schedule was performed.
RC1 required checks passed: 195 unit/PGlite and 446 PostgreSQL tests, schema/generation, typecheck, build/smoke and drift.
Fresh Astra/xhigh independently ran 14 unit and 50 PostgreSQL tests and reproduced four required boundary fixes.
RC1 is not accepted; production/accounting readiness is not claimed. [Mandatory implementation clarifications](IMPLEMENTATION_HANDOFF.md)
carry the eight non-blocking Fable notes, with bounded retained-xhigh Astra consistency confirmation; these remain code acceptance obligations. [RC1 review](reviews/ASTRA_S4A_RC1.md) requires maintenance EXECUTE confinement,
actual-clock deadline guards, full paired synthetic binding at cleanup, and terminal disposal of incomplete exports.
RC2 final checks: 196 unit/PGlite and 456 PostgreSQL tests, all required checks passed.
A bounded integration pass also aligned exact binding-constraint checks in cleanup, provisioning and readiness.
Dependent S4-B/C remain NOT_STARTED. Repairs stay in the same native Opus5.5/high session, then a fresh Astra/xhigh gate.

Fresh [RC2 review](reviews/ASTRA_S4A_RC2.md) independently passed86 tests and confirmed three maintenance-confinement
gaps: foreign-schema relations, user-created TEMP routines, excess schema CREATE/ownership. RC2 remains unaccepted;
fix the full application-object boundary within approved contracts, then seal RC3 and obtain fresh Astra/xhigh acceptance.

RC3 final source: 196/196 unit/PGlite +466/466 PostgreSQL, all11 required checks passed. Broader ACL checks cover
foreign/TEMP objects, builtin initial privileges, large objects, FDW/server and shared-object authority. Earlier committed
PUBLIC parameter test drift was restored (0 ACL rows confirmed); final shared/builtin drift tests are always rolled back,
with separate observer proving invisibility. A disclosed nondefault PUBLIC tablespace limitation awaits independent review.

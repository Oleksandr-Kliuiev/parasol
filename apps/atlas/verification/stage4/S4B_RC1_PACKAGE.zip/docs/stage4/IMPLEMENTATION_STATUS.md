# Stage 4 implementation status

Architecture: **S4-design-rc2 DUAL APPROVED**, unchanged eight-file package. Code checkpoint: **S4-A ACCEPTED on S4A-rc5**
by a fresh explicit GPT-6 Astra/xhigh actual-code review. [Acceptance](reviews/ASTRA_S4A_RC5.md) · [architecture](REVIEW_STATUS.md) · [plan](05_IMPLEMENTATION_PLAN.md).

| Checkpoint | State |
|---|---|
| S4-A DTO, schema, isolation, exact roles and compatibility | ACCEPTED — S4A-rc5, fresh Astra/xhigh |
| S4-B synthetic sync, publication and recovery | RC1 PENDING_REVIEW — implemented by native Opus5.5/high;208 unit/PGlite +507 PG passed; Astra/xhigh acceptance pending |
| S4-C dedicated reads/API/CLI and maintenance | NOT_STARTED — accepted S4-B required |
| S4-LIVE current vendor contract and explicit read admission | NOT_STARTED — DEFERRED_BY_OWNER |

S4-A includes strict immutable normalized DTOs, BigInt currency summaries and Oslo dates, complete bounded exports,
private bearer authority with final under-lock checks, three scoped FORCE-RLS tables with deferred history invariants,
exact runtime/maintenance roles and readiness, synthetic binding integrity, bounded SQL cleanup foundation and generic
connection exclusion. It does not expose a source service or public PowerOffice entry point.

Final required checks on exact RC5 source: **196/196 unit/PGlite +475/475 PostgreSQL**, schema validation/generation,
typecheck, API build/smoke, PostgreSQL17, schema drift and whitespace — all passed. Native actual Opus5.5/high implemented
and repaired S4-A in one session, native Anthropic subscription, no credits/API/fallback. Attributable quota is unknown.
[Evidence](../../verification/stage4/S4A_RC5_IMPLEMENTATION_EVIDENCE.json) · seal `verification/stage4/S4A_APPROVED.json`.

[RC1 review](reviews/ASTRA_S4A_RC1.md) remains CHANGES_REQUIRED in preserved history. Later packages close its four findings:
maintenance-role routine confinement across schemas/access paths, actual DB-clock deadline despite backdated timestamps,
full paired binding proof without credential visibility, and irreversible disposal of incomplete exports. Cleanup,
provisioning and readiness also require the exact installed binding-constraint definition. RC5 also closes subsequent foreign-schema relation, TEMP-routine and schema-authority gaps, plus builtin and large-object
ACL paths. RC4 closes PG17 MAINTAIN and nondefault PUBLIC tablespace CREATE gaps; RC5 closes all runtime table/column grant-option paths. Shared/builtin drift tests now remain uncommitted, with a separate observer proving invisibility. The PGlite compatibility path and independent RC5 verification
and any residual qualifications are recorded in the acceptance report; implementer test results alone are not acceptance.

Acceptance qualification: the new grant-option and builtin/shared/global/host-capable ACL probes always roll back.
Existing disposable-DB tests also commit DB-local synthetic PUBLIC fixtures (one-byte LO, NO HANDLER FDW/server,
synthetic relations/routines) with repair/drop cleanup. The universal no-PUBLIC-commit wording in frozen RC5 notes is
too broad and is qualified by the exact acceptance report and seal.

Next S4-B implements built-in MOCK source sessions, claim/publication/failure/recovery services and their concurrency,
retry/replay and cancellation evidence. S4-C retains fresh maintain admission, paired runner DB verification, original
whole-transaction10s cancellation/1s lock timeout wrapper, dedicated read API/CLI and associated privacy/error journeys.

Accepted Stage1/2/3 norms, installed20 migrations+lock and history remain unchanged. Final verification used disposable
DBs and rollback-only shared-catalog drift. An earlier committed PUBLIC parameter test grant was restored, then the test
was corrected; the exact qualification and zero-residue probe are preserved in RC3/RC4/RC5 orchestration notes. No PowerOffice
account/vendor API/auth, persistent DB/pilot setup, binding command, deployment,
financial write or background schedule was performed. MOCK acceptance does not establish LIVE/accounting readiness.

S4-B implementation authorized2026-10-09 from exact accepted S4A-rc5; [bounded brief](S4B_IMPLEMENTATION_BRIEF.md). S4-A seal/history stays immutable; S4-C/LIVE remain separate.

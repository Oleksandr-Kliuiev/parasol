# Stage 3 contracts

## Authority and commands

New client permissions: `actions:read`, `actions:request`, `actions:approve`, `actions:execute`.
Every operation additionally requires `context:read`, on ONE same-client membership; no merging across memberships.
`action-preview`, `action-request`: request+read. `action-get`, `action-list`: read.
`action-approve`, `action-reject`: approve+read. `action-cancel`: requester identity + request+read.
`action-execute`, `action-verify`, `action-recover`: execute+read. No administrative/workspace grant implies any of these.

CLI is the initial exposure; no action HTTP endpoint or executable tool in the read Gateway is added. Trusted CLI composition
authenticates the bearer token via the confined runtime. It passes an opaque action credential, never a caller-supplied Actor.
Request/approval/execution gates re-read live credential, Actor and membership inside their authority-fenced transaction.
Unauthorized client or missing permission → exactly one safe workspace SecurityAuditEvent, no client audit or dispatch.
Unknown/unusable credential → generic authentication refusal; no actor is invented for an audit. Policy refusal for an
authorized actor → allowlisted client audit. Audit failure stops the operation; transaction effects roll back.

## Input and immutable intent

Request input contains only `connectionId`, `title`, `description`, `idempotencyKey` (UUID). Client comes from trusted command scope.
Reject unknown fields. Server deterministically derives request UUID: first 128 bits of SHA-256 over canonicalJson({dto:"action-id/1", workspaceId, clientId, requesterActorId, idempotencyKey}), formatted as UUIDv8; marker is `[Atlas:<request UUID>]`. No identity/marker supplied by a caller is trusted. Preview displays complete marked title.
`action-preview` is a non-persisting fenced evaluation of this intent; its private file includes exact canonical hash. `action-request` additionally requires `--hash` matching that preview hash after re-evaluating current authority/binding/policy. A changed preview refuses ACTION_PREVIEW_STALE; requester previews again. Different actors have different derived IDs. Approval uses the hash of the stored request, never just a draft.
Canonical input fields: DTO version, workspace/client, type/version, requester actor/token row ID, connection ID, system,
customer key, lifecycleVersion, secretRef digest, policy version `ticket-policy/1`, port version, mode MOCK, normalized title,
description, marker. Hash is SHA-256 of existing canonicalJson encoding. Hashes bind exact codepoint-normalized text, not summaries.
The canonical body is immutable. A changed target/body/mode/policy/port/binding requires a new request and approval.
No secrets or raw DTOs enter canonical input. Token digest is internal auth lookup material, separately protected and never output.

Idempotency uniqueness `(workspace, client, requester, idempotencyKey)`: same validated user intent returns the existing request
(including its original marker), without state change or new approval; changed intent → IDEMPOTENCY_CONFLICT. Compare normalized
user intent before server-generated request ID/marker. Caller idempotency keys do not deduplicate separate actions globally.

## Approval and reservation

Approval binds request ID, exact input hash, action version, policy/port versions, connection lifecycle, signer actor and
signer token row identity, decision timestamp and expiry. `action-approve` supplies the expected hash; stale hash refuses.
Same signer repeated approval returns its existing decision. A conflicting decision/signer or non-pending request refuses.
Requester cannot approve own request. Token rotation/revocation/expiry or loss of required signer permission invalidates
unconsumed approval; a previously valid Actor object does not preserve authority.

Reservation checks current requester request+read/context rights, approver approve+read/context rights, executor execute+read/context
rights, all three original/current credentials, actor ACTIVE states, approval expiry and exact binding/policy/port/mode.
Approval consumption, request state, unique attempt and client audit commit atomically before any port invocation.
That commit is the authorization linearization point. Cancellation, approval revocation, authority changes and binding changes
that win the fence first prevent reservation. Later changes cannot retroactively cancel that already authorized bounded attempt.
Approval expiry is checked using clock_timestamp after locks; the issued single-use permit also expires before actual invocation.

## Safe output and errors

Public output: local request/approval/attempt IDs, statuses, timestamps, versions, safe codes, counts and `synthetic: true`.
Protected preview is an explicit NEW 0600 file outside the repository, with exact intent and hash; never implicit stdout text.
List/get summaries omit title/body, customer/vendor IDs, token row IDs/digests, secretRef and remote DTOs.
Ticket ID is private result/reconciliation material, accepted only as bounded input to verification; never audit/stdout.
Fixed error vocabulary: ACTION_MODE_DISABLED, ACTION_MODE_REFUSED, ACTION_PERMISSION_DENIED, ACTION_CONNECTION_REFUSED,
ACTION_INPUT_INVALID, ACTION_PREVIEW_STALE, IDEMPOTENCY_CONFLICT, APPROVAL_SELF_REFUSED, APPROVAL_HASH_MISMATCH, APPROVAL_NOT_VALID,
ACTION_ALREADY_RESERVED, ACTION_STATE_CONFLICT, ACTION_NOT_DUE, ACTION_NOT_DISPATCHED, ACTION_OUTCOME_UNKNOWN,
ACTION_VERIFICATION_FAILED, ACTION_VERIFICATION_BUDGET, ACTION_AUDIT_FAILED. Wrap unknown exceptions without text.

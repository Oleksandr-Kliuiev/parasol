# Stage 3 execution, verification and port

## State machine

Request starts AWAITING_APPROVAL → APPROVED, REJECTED or CANCELLED. Expired pending/approved authority becomes EXPIRED
at the next guarded operation. APPROVED → DISPATCH_RESERVED consumes approval and inserts its unique attempt.
The request can then become NOT_DISPATCHED, OUTCOME_UNKNOWN, CREATED_UNVERIFIED, VERIFICATION_MISMATCH or VERIFIED.
No post-reservation state transitions back to APPROVED/AWAITING_APPROVAL. No second create permit exists for that request.

Reservation yields one private, mode/binding/hash/nonce-bound capability, consumed by the executor's internal dispatcher.
Within its start deadline, consume the capability once before calling create. A positively known local pre-call refusal
publishes NOT_DISPATCHED with zero calls and leaves the unique attempt consumed. A restart cannot prove whether a reserved
call occurred; after 35 seconds recover to OUTCOME_UNKNOWN, never re-dispatch. Liveness is intentionally weaker than duplicate safety.

One create call has a 15-second AbortSignal deadline. The port must honor it; late results remain possible and are fenced.
Every exception, malformed response, ambiguous failure or loss of persistence after possible invocation is OUTCOME_UNKNOWN.
HTTP status classes never establish non-creation in this slice. No automatic retry on timeout, 429, 5xx or crash.
Receiving a valid ticket ID yields CREATED_UNVERIFIED, followed by a distinct bounded verification read.

## Internal port, not vendor wire schema

TicketPort.createOne receives immutable normalized customer key, marked title, description and invocation nonce; returns
only bounded ticket ID. TicketPort.readOne receives that exact connection and a bounded ticket ID; returns ID, customer key,
marked title, description and `synthetic: true`. No request method, URL, arbitrary header or raw vendor object is accepted.
The supplied implementation is ActionMockTicket storage with independent scoped commits. It accepts only a trusted MOCK
composition and FIXTURE connection; it neither resolves an API credential nor imports native fetch/HTTP libraries.
Tests can inject controlled failures/latency at this private boundary, never through user config or public commands.

## Verification and recovery

Verification requires exact ID, customer key, marker, normalized complete title/description match. A mismatch never becomes
VERIFIED. Original customer identity must match the immutable Connection snapshot, not a caller assertion. Remote status
or other mutable fields are outside this internal port contract and cannot establish success.
Each verification reservation atomically increments the persisted count (≤3), with a separate attempt nonce/fence. One active
verification at a time; stale completion cannot overwrite a newer result. Transient read failure keeps CREATED_UNVERIFIED
or OUTCOME_UNKNOWN with its safe code; exhausted count stays visible. Repeated VERIFIED read returns stored outcome, no port call.

For OUTCOME_UNKNOWN, an actor may provide one candidate ticket ID to action-verify. It is untrusted; read under the exact
approved binding and verify the complete marker/content/customer tuple. No name matching, listing/search, inferred ID or
operator assertion is proof. A successful match can establish VERIFIED for this request; it never claims no other tickets exist.
Unknown result without a matching candidate stays unresolved indefinitely; no create retry or fabricated success is allowed.

After recovery marked UNKNOWN, a late original create result may attach its ticket ID under the SAME attempt token without
returning state to an executable one; it remains CREATED_UNVERIFIED/UNKNOWN until verification. A known VERIFIED result
cannot be downgraded or replaced; a conflicting late ID is an audited result conflict. No replacement attempt token on recovery.
Cancellation/revocation after reservation report already reserved and cannot claim that an external effect was prevented.

## Live contract gate

Public primary references: [Atera API FAQ](https://support.atera.com/hc/en-us/articles/11071761826844-API-FAQ) confirms ticket
creation via POST; [Using the API](https://support.atera.com/hc/en-us/articles/219083397-Using-the-Atera-API) documents token
permissions and authenticated documentation access. Official app.atera.com/apidocs was unavailable unauthenticated.
No unofficial schema is accepted as current primary evidence. No upstream idempotency guarantee is assumed.

Before LIVE: obtain current official create/read schemas, customer/contact routing and content/default/notification effects;
freeze validated projection/verification semantics and actual HTTPS endpoints/auth; review this amendment independently;
admit token rights, designated target and exact human-approved write; run source/secret/data/privacy/retention and recovery gates.
Adding a LIVE flag to the MOCK implementation is not an admitted extension.

# Stage 3 synthetic acceptance matrix

Every case is MOCK-only unless explicitly labelled future LIVE. Independent acceptance covers the exact current artifact.

| ID | Required behavior |
|---|---|
| A1 | RLS across two workspaces/clients; all scoped FKs; runtime owner/bypass/extra grants fail startup; auth rows remain owner-only |
| A2 | NFC/canonical hash and UUIDv8 deterministic; field/text limits; exact marked preview matches stored intent; changed binding/hash rejects request; UUID collision cannot adopt another action; invalid fields zero effects |
| A3 | Requester idempotency same intent returns same request; different intent conflicts; concurrency produces one request; audit rollback |
| A4 | Canonical/request/approval/attempt/mock identities protected even through direct runtime SQL; legacy Approval remains inert |
| B1 | Every command scope/permission denial safe audited once; invalid token no fabricated actor; no permission merging; no provider calls |
| B2 | Other ACTIVE actor approves exact hash; self/stale/changed/expired/revoked actor/token/membership/connection refuses |
| B3 | Owner authority/Connection mutations serialize via fence; DB clock after locks; revocation-before-reservation wins; no deadlock bypass |
| B4 | Approval consumption+attempt+state+audit atomic; concurrent execute/cancel/revoke order deterministic; one permit, no repeated dispatch |
| C1 | Complete request → independent approval → reserved create → distinct matching read → VERIFIED; all outputs explicitly synthetic |
| C2 | Crash before/after create commit/response/publication; timeout/429/5xx/malformed ID → visible uncertainty; one create lifetime per request |
| C3 | Known pre-call failure → NOT_DISPATCHED; restarted reservation → UNKNOWN after grace; never reset latch or blindly re-POST |
| C4 | Mismatched customer/body/title/marker/ID never VERIFIED; supplied candidate not proof; other-client mock rows never returned |
| C5 | Verification budget3 persists across invocations; concurrency/late result cannot overwrite current/VERIFIED result; audit failure rollback |
| C6 | Late create response same owned attempt recorded without replay; conflicting ticket ID visible; revoked actor cannot initiate new read/create |
| C7 | Public canaries absent: title/body/customer/ticket IDs/credential refs/token hashes/raw errors; protected preview is new0600 outside repo |
| C8 | CLI mode DISABLED default; LIVE/origin/custom port/provider callbacks refuse; MOCK only FIXTURE; native network trap sees zero calls |
| R1 | Existing read Gateway still refuses writes; ClientContextV1/DTOs and Atera/Huntress/M365 read behavior remain compatible |
| R2 | Full checkpoint suite passes; context budget ≤700; all frozen migrations/accepted reports preserved; new upgrade/grant path passes |

Mock store contents and synthetic journal cannot satisfy Stage 1/2 live gates. Stage 3 engineering acceptance makes no claim
of verified Atera wire payload, token routing, notifications, production idempotency, backup/restore or operational readiness.
Future S3-LIVE requires separately reviewed official adapter contract, retention/privacy/operational prerequisites and owner
approval for a designated real write. S2-LIVE remains deferred and is not silently closed by this new stage.

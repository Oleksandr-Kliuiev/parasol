# Stage 3 persistence and concurrency

Add new migrations and `prisma/actions.prisma`; never edit frozen migrations. Preserve the existing reserved `Approval`
model/table, historical rows and Gateway contracts; it is not accepted as an executable approval. New action models are separate.

## Models and database invariants

ActionRequest: scope+UUID PK; requester actor ID/token row ID/digest; scoped Connection FK; idempotency key and normalized
user-intent hash; immutable canonical input/hash/policy/port/mode/binding snapshot; state; creation time; private result ID;
safe code; reservation/completion timestamps. Composite scoped FKs everywhere. Unique requester idempotency key; any derived UUID collision against a different request is refused, never adopted.
ActionApproval: scope+request FK; unique request; signer actor/token row ID/digest; exact input hash/version snapshot;
decision APPROVED|REJECTED|REVOKED|CONSUMED; approvedAt/expiresAt/consumedAt. Signer cannot equal requester (DB trigger).
ActionAttempt: scope+request FK; unique request (one create attempt lifetime); random attempt token; immutable invocation
nonce/reservedAt/startDeadlineAt; state RESERVED|NOT_DISPATCHED|UNKNOWN|CREATED|VERIFIED|MISMATCH; private ticket ID;
create/verification safe codes; verification count 0..3; timestamps. Attempt identity and nonce never reset or overwritten.
ActionMockTicket: scope+Connection FK; UUID ID; constant `S3_SYNTHETIC`; customer key, marked title and description;
creation time. Its port create commits independently from ActionAttempt, deliberately simulating an upstream side effect.
These rows are not ExternalEntity, RawEvent, ResourceSnapshot or live evidence; existing context readers never include them.
ActionAuthorityFence: one workspace FK/PK and monotonic version. Workspace creation installs it; migrate existing workspaces.

All action tables have ENABLE+FORCE RLS. Client rows use verified workspace/client scope; fence uses verified workspace only.
Runtime has SELECT/INSERT, column-limited mutable UPDATE; no DELETE/TRUNCATE. Request canonical/identity, approval identity,
attempt immutable fields and mock-ticket contents are protected by grants and triggers. Fence has UPDATE(workspaceId) solely for
locking, not runtime version mutation. Add every protected table and exact new grants to assertRuntimeRole self-check.
Audit events remain append-only; ActionMockTicket rows remain immutable and uniquely identified, not deduplicated by marker.

## Authority fence and lock discipline

Fresh authentication resolves the credential/workspace, then the action transaction locks that workspace's fence, rechecks
the credential and reads current authority under READ COMMITTED. Authority checks use the existing token/actor lookup
RLS protocol with transaction-local app.token_hash/app.actor_id, restored/cleared before action data access.
Signer digests are read from protected action rows, not caller inputs; their tokens/actors/memberships are checked with that
same lookup protocol. No owner connection or definer function reads application authority on the caller's behalf.

Migration installs BEFORE mutation triggers for Actor, ClientMembership, ApiToken and relevant Connection changes, plus
workspace/fence lifecycle. Any authority mutation or Connection status/lifecycle/secretRef/target mutation takes the same
workspace fence and increments its version before becoming visible. Cross-workspace identity moves are prohibited.
The trigger's narrowly scoped SECURITY DEFINER updates ONLY that fence row; fixed pg_catalog/public search_path,
no dynamic SQL/user query input, no callable ordinary function, public EXECUTE revoked. It grants no read or auth capability.
Normal owner revocations are serialized even when they do not use the action service. Runtime never gains auth-row UPDATE.

Action lock order: workspace fence → ActionRequest → ActionApproval → ActionAttempt. Cancellation/rejection/revocation,
reservation and publication follow the same order. Owner operations/other existing workflows may acquire relation locks
before trigger execution: a PostgreSQL deadlock aborts the entire pre-dispatch transaction, with zero port invocation;
it is surfaced as a safe conflict, not blindly retried. Tests must prove no authority bypass or action dispatch after an abort.
No network/port call inside a DB transaction. Use DB clock after lock acquisition, not transaction-start timestamp.

## Atomic transitions and retention boundary

Request+request audit; approval decision+audit; cancellation/rejection/revocation+audit; consumption+reservation+audit;
each result publication+audit are single transactions. Failure leaves the prior state intact, never an unaudited effect.
Only identity-fenced owned attempts can publish. Narrow continuation handles are minted by trusted reservation code,
kept in a private capability map and never returned in CLI/API output. They can persist result facts after signer revocation
but cannot create another attempt, invoke a port or perform fresh verification. This preserves an already occurred result.
Fresh user verification/recovery requires fresh current execution authority.

No purge/delete/retention runner is introduced here; content stays RLS-confined and synthetic. Before any LIVE amendment,
define and review actual ticket-content retention/erasure and deployment/secret management. No new production claim is made.

# Stage 3 implementation status

Architecture: S3-design-rc4 (verification/stage3/S3_DESIGN_APPROVED.json), MOCK only. Live: DEFERRED_BY_OWNER.
Implementer reports are not acceptance. Each checkpoint needs actual independent Astra/xhigh acceptance first.

| Checkpoint | State | Evidence |
|---|---|---|
| S3-A | ACCEPTED — S3A-rc3, fresh GPT-6 Astra/xhigh; F1–F4 and F1-R1 closed | [Acceptance](reviews/ASTRA_S3A_RC3.md); verification/stage3/S3A_RC3_IMPLEMENTATION_EVIDENCE.json |
| S3-B | RC1 CHANGES_REQUIRED (F1, F2); RC2 repair implemented by native Opus5.5/high — awaiting Codex freeze and fresh explicit Astra/xhigh re-review (implementer report is not acceptance) | [RC1 review](reviews/ASTRA_S3B_RC1.md); verification/stage3/S3B_IMPLEMENTATION_EVIDENCE.json (RC1), S3B_RC2_IMPLEMENTATION_EVIDENCE.json (RC2) |
| S3-C | Not started | — |

## S3-A integration delta (accepted in RC3)

- Schema: migrations 202610091000_stage3_action_fence (permission CHECK + four action permissions; ActionAuthorityFence,
  backfill before FORCE; SECURITY DEFINER trigger function; Actor/ClientMembership/ApiToken/Connection row fence and
  statement TRUNCATE triggers; Workspace init/delete/identity/TRUNCATE guards; fence self-guard) and
  202610091100_stage3_action_requests (ActionRequest/Approval/Attempt/Verification/MockTicket with scoped FKs, CHECKs,
  history/lifecycle triggers, ENABLE+FORCE RLS; ApiToken (workspace, actor, id) unique key for signed token FKs).
  prisma/actions.prisma plus back-relations on Workspace, ApiToken and Connection.
- Provisioning: prisma/roles.sql adds the NOLOGIN fence definer (fifth distinct role incl. owner), its exact column
  grants and role-specific policy, function ownership/ACL, and the owner/definer global completeness count; runtime gets
  SELECT on action tables, INSERT on ActionRequest only and UPDATE(workspaceId) on the fence.
- Readiness: packages/graph/fence-role.ts facts joined to the runtime self-check and re-run by every fenced admission;
  action tables join PROTECTED_TABLES.
- Adjacent paths: exact AT001 → ACTION_FENCE_NOT_READY mapping in bind, Stage 1 activation, M365 activation, m365-disable
  and the owner seed (packages/graph/fence-errors.ts); audit allowlist gains actionRequestId/actionType/requestState.
- Test helpers: four-role roles.sql renderer; byte-exact accepted Stage 2 roles.sql fixture for upgrade tests.
- Routing: packages/actions/AGENTS.md, docs/AI_CONTEXT_MAP.md, prisma/AGENTS.md, tests/pg/AGENTS.md; RUNBOOK §9.

RC2 repair (bounded F1–F4): the fence definer's routine privileges are exact (own trigger function plus an explicit list of
accepted Stage 1/2 invoker helpers through PUBLIC; any explicit grant, SECURITY DEFINER or unlisted routine fails readiness;
roles.sql removes grants it can revoke and otherwise refuses); the new history/lifecycle trigger functions hold no PUBLIC
EXECUTE; protected input opens non-blocking (a FIFO is refused at once); the ACTIVE-claim and approval-lifetime CHECKs require
every mandatory field non-null and never evaluate to SQL NULL; docs/ROADMAP.md restored byte-exact (Stage 2 normative file,
it carries no Stage 3 status — status lives here and in REVIEW_STATUS.md).

RC3 repair (F1-R1): every shared-helper allowance is the approved schema-qualified identity
`quote_ident(schema).quote_ident(name)(identity arguments)` — all 32 in `public` — in both the readiness check and roles.sql;
other application schemas are still scanned, so a routine with an allowed name/arguments in another schema is refused.

Implementation choices inside the approved contracts (flag for review): ACTION_NOT_FOUND for an invisible/unknown request
ID; ACTION_STATE_CONFLICT for a derived-ID collision; validity hints CURRENT/NOT_PENDING/AUTHORITY_CHANGED/SIGNER_EXPIRED;
policy version atlas-action-policy/1 and port version atlas-synthetic-ticket-port/1; idempotency keys are lower-case UUIDs.

## S3-B integration delta (implemented; independent acceptance pending)

- Code: packages/actions/guard.ts (lock order, DB clock after locks, shared stored signer/binding guard, committed terminal
  loss), approvals.ts (approve/reject/revoke/cancel), reservation.ts (atomic reservation, WeakMap single-use permit);
  contracts.ts gains the S3-B permission sets, TTL/start window and result types; authority.ts exports setLocal and
  requests.ts exports assertComposition (no behavior change). Audit allowlist gains actionApprovalId/actionAttemptId/approvalDecision.
- No migration: the installed S3-A schema (CHECKs, history/lifecycle triggers, scoped FKs) supports every S3-B write; all
  20 migrations and the lock are unchanged. Provisioning: roles.sql grants the runtime INSERT on ActionApproval/ActionAttempt
  and UPDATE of the request (state, safeErrorCode, updatedAt, terminalAt) and approval (decision, consumedAt, revokedAt,
  safeErrorCode) lifecycle columns only; readiness (fence-role.ts ACTION_RUNTIME_PRIVILEGES) is the same allowlist.
- Tests: action-approvals, action-guard, action-reserve, action-upgrade-s3b (support tests/support/action-approval.ts and
  the byte-exact accepted S3-A roles.sql fixture tests/support/roles-s3a.sql); the S3-A A4 test's final runtime-write loop
  now asserts the S3-B closed surface instead of "no write path".

Implementation choices inside the approved contracts (flag for review): natural expiry stores and returns
APPROVAL_NOT_VALID; cancel by another actor and cancel of other terminal states return ACTION_STATE_CONFLICT; revoke by
another signer, reject of an APPROVED request and approve/reserve of a non-approvable state return APPROVAL_NOT_VALID;
the caller's own token expiring after admission is checked on the DB clock read after the command's LAST row lock,
before ANY outcome (stored terminal replay, approval replay, refusal audit, committed loss, decision or reservation), and
returns ACTION_AUTHENTICATION_FAILED with no mutation or audit (RC2 repair of RC1-F1); reject and revoke take the expected hash, cancel the request ID only; a repeated own cancel returns the stored
result like a repeated own revoke; reject/revoke/cancel also run the guard (a detected loss is committed instead).

RC2 repair (bounded RC1-F1/F2): F1 — every S3-B command takes all its row locks, then guard.ts lockedClock reads the DB clock
and refuses an expired caller before any outcome. F2 — authority.ts maps a deadlock/serialization abort of the client or
denial audit INSERT (40P01/40001, P2034) to ACTION_DB_CONFLICT instead of ACTION_AUDIT_FAILED; other audit failures keep
ACTION_AUDIT_FAILED. Both fixed codes only, no retry. Real PostgreSQL lock-wait and deadlock-at-audit regressions added.

## Accepted S3-A artifact

S3A-rc3: package `754eee15cf8e89cd7f61d8914f4796d3a5314f44e41169fac33145495134a51c`, 586 reviewed files;
manifest `verification/stage3/S3A_RC3_MANIFEST.json`, source ZIP `verification/stage3/S3A_RC3_PACKAGE.zip`
SHA-256 `9f54ac0667d2658e4bb8404009aab2e6b90617d0b9c7103d9de205aa4f56bcee`. Acceptance: [Astra RC3](reviews/ASTRA_S3A_RC3.md), fresh explicit gpt-6-astra/xhigh.

All ten checkpoint checks passed: **177/177 unit/PGlite and 341/341 PostgreSQL**, schema validation, generation, typecheck,
build, smoke, PostgreSQL17/schema drift and whitespace. Independent review: 12/12 unit, 24/24 action PostgreSQL, two schema/signature probes.
Native Opus5.5/high used one cohesive session with two bounded repair turns; original RC1/RC2 reports/evidence remain historical.
Strict routine identity includes schema/signature; future callable-routine changes require deliberate review. No approval/reservation
or execution service is accepted yet. S2-LIVE and real vendor writes remain deferred; pilot DB/configuration was untouched.

After acceptance only administrative status/record updates are allowed by this handoff; their exact hashes are in
`verification/stage3/S3A_APPROVED.json`. All reviewed source/tests/migrations retain accepted RC3 hashes.

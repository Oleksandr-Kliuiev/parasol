# Prisma context routing

Read docs/AI_CONTEXT_MAP.md and the current stage workflow first. Schema commands use the prisma directory:
- schema.prisma: generator/datasource and Foundation models.
- m365.prisma: Stage 2 M365 models; reviewed contracts in docs/stage2/02_CONTRACTS.md.
- actions.prisma: Stage 3 action models; reviewed contracts in docs/stage3/03_DATA_AND_CONCURRENCY.md.
- roles.sql: post-migration role provisioning (runtime, cleanup definer/runner, Stage 3 fence definer); runtime checks in
  packages/graph/runtime-role.ts and packages/graph/fence-role.ts.

Do not load the migration history wholesale. Query one named constraint/function or current migration.
Existing migrations are frozen; changes require new migrations after the accepted checkpoint.
S2-B repair: 202610081300_stage2_m365_directory_retry (M365ResourceState.retryAt, its CHECK/trigger; grant in roles.sql);
202610081400_stage2_m365_directory_budget (attemptsUsed, backfill, CHECK, transition trigger; grant in roles.sql).
Stage 2 SQL invariants: tests/m365-sql-invariants.ts and tests/m365-cleanup-invariants.ts.
S3-A: 202610091000_stage3_action_fence (permissions, fence table/backfill, definer trigger function, auth/Connection/Workspace
triggers) and 202610091100_stage3_action_requests (action tables, scoped FKs, CHECKs, history/lifecycle triggers, FORCE RLS).
Tests: tests/pg/action-*.pg.test.ts. Never inspect FORCE action tables as a non-superuser owner; use the scoped runtime.
S3-B: no migration. roles.sql grants the runtime INSERT on ActionApproval/ActionAttempt and UPDATE only of the request
(state, safeErrorCode, updatedAt, terminalAt) and approval (decision, consumedAt, revokedAt, safeErrorCode) lifecycle
columns; packages/graph/fence-role.ts ACTION_RUNTIME_PRIVILEGES is the matching readiness allowlist.

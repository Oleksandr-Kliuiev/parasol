# Stage 3 governed actions — context routing

Design: docs/stage3/AGENTS.md, 01_SPEC.md, then only the relevant 02–06 section. Current checkpoint state:
docs/stage3/IMPLEMENTATION_STATUS.md. MOCK only; no vendor adapter, network transport or live write exists or may be added here.

S3-A (accepted in S3A-rc3) — entry files by concern:
- contracts.ts: versions, permissions, fixed error codes, preview whitelist, safe summary types.
- canonical.ts: raw-scalar Unicode validation → NFC/trim → limits; UUIDv8 request ID; marker; intent/canonical hashes.
- private-file.ts: protected 0600 preview output (outside any Git checkout) and protected JSON input reader.
- policy.ts: DISABLED-by-default composition (only exact MOCK); FIXTURE atera connection policy.
- authority.ts: opaque bearer credential; fenced admission (auth → fence FOR UPDATE → readiness → re-auth after the lock →
  ACTIVE actor/membership → one workspace denial audit); validity hints; fixed failure mapping.
- requests.ts: preview, request (store or idempotent retrieval), get, stored-preview export, keyset list.
S3-B (implemented; independent Astra/xhigh acceptance pending):
- guard.ts: lock order request → approval after the fence; lockedClock (DB clock after the LAST lock, caller's own token
  re-checked before any outcome); the shared stored guard (deployed
  versions, exact epoch, stored signers ACTIVE + rights via the confined actor context, exact binding, both expiry snapshots,
  approval expiry); a loss is committed (INVALIDATED/EXPIRED, approval REVOKED, audit) and refused after the commit.
- approvals.ts: approve (exact STORED preview file + hash, never self, same-signer replay without renewal; TTL 15 min capped
  by both snapshots), reject, revoke (original signer; repeat returns stored), cancel (original requester).
- reservation.ts: one transaction consumes the approval + unique attempt + DISPATCH_RESERVED + audit; only a committed
  reservation mints the WeakMap-bound single-use permit (start deadline min(5 s, approval expiry), monotonic, never renewed).
Database: prisma/actions.prisma, migrations 202610091000 (fence) and 202610091100 (action tables); prisma/roles.sql §4b;
readiness facts packages/graph/fence-role.ts; fence error mapping packages/graph/fence-errors.ts.
Tests: tests/action-canonical.test.ts and tests/pg/action-*.pg.test.ts (support: tests/support/action-fixtures.ts).

Tests: tests/pg/action-{approvals,guard,reserve,upgrade-s3b}.pg.test.ts (support: tests/support/action-approval.ts).

Not here yet (S3-C, after actual independent acceptance of S3-B): synthetic port, create dispatch/fact publication,
verification, recovery and operator CLI. A permit is consumed only by that future trusted dispatcher; S3-B calls nothing.
Runtime grants stay exactly as prisma/roles.sql lists them; a new write path is a reviewed roles.sql + readiness change.
Never print or audit titles, descriptions, customer keys, token IDs/digests, secret references or preview file paths.

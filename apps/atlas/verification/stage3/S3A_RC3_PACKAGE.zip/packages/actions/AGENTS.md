# Stage 3 governed actions — context routing

Design: docs/stage3/AGENTS.md, 01_SPEC.md, then only the relevant 02–06 section. Current checkpoint state:
docs/stage3/IMPLEMENTATION_STATUS.md. MOCK only; no vendor adapter, network transport or live write exists or may be added here.

S3-A (implemented, independent acceptance pending) — entry files by concern:
- contracts.ts: versions, permissions, fixed error codes, preview whitelist, safe summary types.
- canonical.ts: raw-scalar Unicode validation → NFC/trim → limits; UUIDv8 request ID; marker; intent/canonical hashes.
- private-file.ts: protected 0600 preview output (outside any Git checkout) and protected JSON input reader.
- policy.ts: DISABLED-by-default composition (only exact MOCK); FIXTURE atera connection policy.
- authority.ts: opaque bearer credential; fenced admission (auth → fence FOR UPDATE → readiness → re-auth after the lock →
  ACTIVE actor/membership → one workspace denial audit); validity hints; fixed failure mapping.
- requests.ts: preview, request (store or idempotent retrieval), get, stored-preview export, keyset list.
Database: prisma/actions.prisma, migrations 202610091000 (fence) and 202610091100 (action tables); prisma/roles.sql §4b;
readiness facts packages/graph/fence-role.ts; fence error mapping packages/graph/fence-errors.ts.
Tests: tests/action-canonical.test.ts and tests/pg/action-*.pg.test.ts (support: tests/support/action-fixtures.ts).

Not here yet (later checkpoints, each after actual independent acceptance of the previous one): approvals/rejection/
revocation/cancellation and reservation (S3-B); synthetic port, execution, verification, recovery and operator CLI (S3-C).
Runtime grants stay exactly as prisma/roles.sql lists them; a new write path is a reviewed roles.sql + readiness change.
Never print or audit titles, descriptions, customer keys, token IDs/digests, secret references or preview file paths.

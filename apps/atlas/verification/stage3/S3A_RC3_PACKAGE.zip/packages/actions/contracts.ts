import { AtlasError } from '../core/contracts.ts';
import type { ErrorKind } from '../core/contracts.ts';

/**
 * Stage 3 governed-action contracts (docs/stage3/01_SPEC.md, 02_CONTRACTS.md). S3-A: typed input, deterministic preview,
 * immutable request and idempotent retrieval. Approval, reservation, the synthetic port and verification are later
 * checkpoints; their states are named here only because the stored lifecycle already constrains them.
 */
export const ACTION_TYPE = 'atera.create_ticket';
/** Atlas port contract version (not a claim about Atera's HTTP payload). */
export const ACTION_VERSION = 'atlas-ticket-port/1/mock';
export const ACTION_POLICY_VERSION = 'atlas-action-policy/1';
export const ACTION_PORT_VERSION = 'atlas-synthetic-ticket-port/1';
export const ACTION_MODE = 'MOCK';
export const ACTION_REQUEST_DTO = 'atlas-action-request/1';
export const ACTION_ID_DTO = 'action-id/1';
export const ACTION_INTENT_DTO = 'action-intent/1';
export const ACTION_PREVIEW_DTO = 'atlas-action-preview/1';

/** Same-client permissions (ClientMembership vocabulary, migration 202610091000). Every command also needs context:read. */
export const ACTIONS_READ = 'actions:read';
export const ACTIONS_REQUEST = 'actions:request';
export const ACTIONS_APPROVE = 'actions:approve';
export const ACTIONS_EXECUTE = 'actions:execute';
export const CONTEXT_READ = 'context:read';
export const ACTION_PERMISSIONS: readonly string[] = [ACTIONS_READ, ACTIONS_REQUEST, ACTIONS_APPROVE, ACTIONS_EXECUTE];
/** Permissions per S3-A operation, all-of on ONE membership of the client (never merged across memberships). */
export const PREVIEW_PERMISSIONS: readonly string[] = [CONTEXT_READ, ACTIONS_READ, ACTIONS_REQUEST];
export const REQUEST_PERMISSIONS: readonly string[] = [CONTEXT_READ, ACTIONS_READ, ACTIONS_REQUEST];
export const READ_PERMISSIONS: readonly string[] = [CONTEXT_READ, ACTIONS_READ];

export const TITLE_MAX = 160;
export const DESCRIPTION_MAX = 2000;
export const MARKED_TITLE_MAX = 240;
export const INPUT_MAX_BYTES = 16 * 1024;
export const LIST_DEFAULT = 50;
export const LIST_MAX = 100;

export type RequestState = 'AWAITING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'CANCELLED' | 'REVOKED' | 'INVALIDATED' | 'EXPIRED'
  | 'DISPATCH_RESERVED' | 'NOT_DISPATCHED' | 'OUTCOME_UNKNOWN' | 'CREATED_UNVERIFIED' | 'VERIFICATION_MISMATCH' | 'VERIFIED';
export const PENDING_STATES: readonly RequestState[] = ['AWAITING_APPROVAL', 'APPROVED'];

/** Fixed error codes (02_CONTRACTS "Public output and fixed errors"). No value, body or SQL diagnostic ever follows. */
export const ACTION_ERROR_CODES = [
  'ACTION_AUTHENTICATION_FAILED', 'SCOPE_DENIED', 'PERMISSION_DENIED', 'ACTION_MODE_DISABLED', 'ACTION_MODE_REFUSED', 'ACTION_CONNECTION_REFUSED',
  'ACTION_INPUT_INVALID', 'ACTION_PREVIEW_STALE', 'ACTION_OUTPUT_INVALID', 'ACTION_OUTPUT_FAILED', 'IDEMPOTENCY_CONFLICT',
  'APPROVAL_SELF_REFUSED', 'APPROVAL_HASH_MISMATCH', 'APPROVAL_PREVIEW_MISMATCH', 'APPROVAL_NOT_VALID', 'ACTION_AUTHORITY_CHANGED',
  'ACTION_FENCE_NOT_READY', 'ACTION_CONTRACT_VERSION_CHANGED', 'ACTION_PUBLICATION_CONFLICT', 'ACTION_STATE_CONFLICT', 'ACTION_ALREADY_RESERVED',
  'ACTION_RECOVERY_NOT_DUE', 'ACTION_DB_CONFLICT', 'ACTION_NOT_DISPATCHED', 'ACTION_OUTCOME_UNKNOWN', 'ACTION_VERIFICATION_BUSY',
  'ACTION_VERIFICATION_FAILED', 'ACTION_VERIFICATION_BUDGET', 'ACTION_AUDIT_FAILED', 'ACTION_NOT_FOUND', 'UNEXPECTED_ERROR',
] as const;
export type ActionErrorCode = typeof ACTION_ERROR_CODES[number];
const KINDS: Partial<Record<ActionErrorCode, ErrorKind>> = {
  SCOPE_DENIED: 'SCOPE', PERMISSION_DENIED: 'SCOPE', ACTION_AUTHENTICATION_FAILED: 'SCOPE', ACTION_INPUT_INVALID: 'VALIDATION',
  ACTION_OUTPUT_INVALID: 'VALIDATION', ACTION_PREVIEW_STALE: 'CONFLICT', IDEMPOTENCY_CONFLICT: 'CONFLICT', ACTION_STATE_CONFLICT: 'CONFLICT',
  ACTION_DB_CONFLICT: 'TRANSIENT', ACTION_CONNECTION_REFUSED: 'VALIDATION', ACTION_NOT_FOUND: 'VALIDATION',
};
/** The one way action code raises: a fixed code, no details. */
export const actionError = (code: ActionErrorCode): AtlasError => new AtlasError(code, KINDS[code] ?? 'PERMANENT');

/** User-entered input file (02_CONTRACTS): exactly these four fields. Client and actor come from trusted scope/bearer. */
export interface ActionInput { connectionId: string; title: string; description: string; idempotencyKey: string }
/** Normalized, validated content (NFC, trimmed); title is the unmarked user title. */
export interface NormalizedInput { connectionId: string; title: string; description: string; idempotencyKey: string }

/** Private preview document (exact whitelist). Written only to a protected file, never to stdout, audit or errors. */
export interface ActionPreviewDocument {
  kind: 'ACTION_INPUT_PREVIEW' | 'STORED_ACTION_PREVIEW'; dto: typeof ACTION_PREVIEW_DTO; requestId: string;
  workspaceId: string; clientId: string; connectionId: string; actionType: string; actionVersion: string;
  policyVersion: string; portVersion: string; mode: typeof ACTION_MODE; title: string; description: string; marker: string; inputHash: string;
}
export const PREVIEW_FIELDS: readonly (keyof ActionPreviewDocument)[] = ['kind', 'dto', 'requestId', 'workspaceId', 'clientId', 'connectionId',
  'actionType', 'actionVersion', 'policyVersion', 'portVersion', 'mode', 'title', 'description', 'marker', 'inputHash'];

/**
 * Why a stored request could no longer be approved now, without changing it (retrieval is not admission): CURRENT, or the
 * first applicable loss — not pending any more, the workspace authority epoch moved, or the requester's token snapshot expired.
 */
export type ValidityHint = 'CURRENT' | 'NOT_PENDING' | 'AUTHORITY_CHANGED' | 'SIGNER_EXPIRED';

/** Safe public summary: local IDs, statuses, times, hashes/versions, hints. No bodies, customer/token IDs, refs or digests. */
export interface ActionRequestSummary {
  requestId: string; state: RequestState; actionType: string; actionVersion: string; policyVersion: string; portVersion: string;
  mode: typeof ACTION_MODE; inputHash: string; authorityEpoch: number; createdAt: string; updatedAt: string;
  validity: ValidityHint; synthetic: true;
}
export interface ActionPreviewResult { requestId: string; inputHash: string; idempotent: boolean; validity: ValidityHint; synthetic: true }
export interface ActionRequestResult extends ActionRequestSummary { idempotent: boolean }
export interface ActionListPage { items: ActionRequestSummary[]; nextCursor: string | null; synthetic: true }

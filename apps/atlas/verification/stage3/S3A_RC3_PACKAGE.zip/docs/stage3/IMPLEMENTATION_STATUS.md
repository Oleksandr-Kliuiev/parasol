# Stage 3 implementation status

Architecture: S3-design-rc4 (verification/stage3/S3_DESIGN_APPROVED.json), MOCK only. Live: DEFERRED_BY_OWNER.
Implementer reports are not acceptance. Each checkpoint needs actual independent Astra/xhigh acceptance first.

| Checkpoint | State | Evidence |
|---|---|---|
| S3-A | RC1 and RC2 reviews REQUIRED_CHANGES (docs/stage3/reviews/ASTRA_S3A_RC1.md F1–F4; ASTRA_S3A_RC2.md F1-R1); RC3 repair implemented, independent Astra/xhigh acceptance PENDING | RC1: verification/stage3/S3A_IMPLEMENTATION_EVIDENCE.json, RC2: S3A_RC2_IMPLEMENTATION_EVIDENCE.json (historical); RC3: S3A_RC3_IMPLEMENTATION_EVIDENCE.json |
| S3-B | Not started (blocked on S3-A acceptance) | — |
| S3-C | Not started | — |

## S3-A integration delta (for review)

- Schema: migrations 202610091000_stage3_action_fence (permission CHECK + four action permissions; ActionAuthorityFence,
  backfill before FORCE; SECURITY DEFINER trigger function; Actor/ClientMembership/ApiToken/Connection row fence and
  statement TRUNCATE triggers; Workspace init/delete/identity/TRUNCATE guards; fence self-guard) and
  202610091100_stage3_action_requests (ActionRequest/Approval/Attempt/Verification/MockTicket with scoped FKs, CHECKs,
  history/lifecycle triggers, ENABLE+FORCE RLS; ApiToken (workspace, actor, id) unique key for signed token FKs).
  prisma/actions.prisma plus back-relations on Workspace, ApiToken and Connection.
- Provisioning: prisma/roles.sql adds the NOLOGIN fence definer (fifth distinct role incl. owner), its exact column
  grants and role-specific policy, function ownership/ACL, and the owner/definer global completeness count; runtime gets
  SELECT on action tables, INSERT on ActionRequest only and UPDATE(workspaceId) on the fence.
- Readiness: packages/graph/fence-role.ts facts joined to the runtime self-check and re-run by every fenced admission;
  action tables join PROTECTED_TABLES.
- Adjacent paths: exact AT001 → ACTION_FENCE_NOT_READY mapping in bind, Stage 1 activation, M365 activation, m365-disable
  and the owner seed (packages/graph/fence-errors.ts); audit allowlist gains actionRequestId/actionType/requestState.
- Test helpers: four-role roles.sql renderer; byte-exact accepted Stage 2 roles.sql fixture for upgrade tests.
- Routing: packages/actions/AGENTS.md, docs/AI_CONTEXT_MAP.md, prisma/AGENTS.md, tests/pg/AGENTS.md; RUNBOOK §9.

RC2 repair (bounded F1–F4): the fence definer's routine privileges are exact (own trigger function plus an explicit list of
accepted Stage 1/2 invoker helpers through PUBLIC; any explicit grant, SECURITY DEFINER or unlisted routine fails readiness;
roles.sql removes grants it can revoke and otherwise refuses); the new history/lifecycle trigger functions hold no PUBLIC
EXECUTE; protected input opens non-blocking (a FIFO is refused at once); the ACTIVE-claim and approval-lifetime CHECKs require
every mandatory field non-null and never evaluate to SQL NULL; docs/ROADMAP.md restored byte-exact (Stage 2 normative file,
it carries no Stage 3 status — status lives here and in REVIEW_STATUS.md).

RC3 repair (F1-R1): every shared-helper allowance is the approved schema-qualified identity
`quote_ident(schema).quote_ident(name)(identity arguments)` — all 32 in `public` — in both the readiness check and roles.sql;
other application schemas are still scanned, so a routine with an allowed name/arguments in another schema is refused.

Implementation choices inside the approved contracts (flag for review): ACTION_NOT_FOUND for an invisible/unknown request
ID; ACTION_STATE_CONFLICT for a derived-ID collision; validity hints CURRENT/NOT_PENDING/AUTHORITY_CHANGED/SIGNER_EXPIRED;
policy version atlas-action-policy/1 and port version atlas-synthetic-ticket-port/1; idempotency keys are lower-case UUIDs.

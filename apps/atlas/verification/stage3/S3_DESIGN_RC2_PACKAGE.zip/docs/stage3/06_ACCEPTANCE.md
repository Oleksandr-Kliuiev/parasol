# Stage 3 synthetic acceptance matrix — RC2

Every case is MOCK-only unless future LIVE. Independent acceptance covers the exact current artifact.

| ID | Required behavior |
|---|---|
| A1 | Two-workspace/client RLS and scoped FKs; runtime owner/bypass/membership/extra grants refuse startup; no auth writes |
| A2 | NFC/lone-surrogate and scalar/text limits; deterministic UUIDv8 retains122 hash bits; exact marked stored preview; changed new binding/hash refuses; collision cannot adopt another action |
| A3 | Same user intent/key returns original immutable request despite stale syntactic hash, token rotation, binding/epoch drift or terminal outcome; no renewal; different intent conflicts; concurrent one request; new admission requires fresh hash; audit rollback |
| A4 | Direct runtime SQL cannot alter immutable canonical/epoch/approval/attempt/mock identity; legacy Approval stays inert; stored token ROW IDs only; descriptor lookup cannot widen ordinary auth or publish token hashes |
| A5 | COMPLETE fence provisioned in S3-A: nonsuperuser owner with blank/wrong GUC can mutate auth/Connection under FORCE RLS; dedicated role exact ACL/attributes/no memberships; cleanup checks unchanged; owner Workspace insert initializes one fence |
| A6 | Missing fence/zero-row update rejects and rolls back owner mutation; wrong-workspace GUC and pg_temp shadow cannot target another fence; no-op mutations increment; Workspace/scope-key moves/deletes refused; disabled trigger/bad role/policy fails readiness |
| B1 | Every command scope/permission denial safe audited once; invalid token no fabricated actor; no permission merging or provider calls |
| B2 | Independent approver with read+approve but without request grant exports stored exact preview and approves; mismatched content/hash/file/request, self approval, stale token/actor/membership/connection fail |
| B3 | Remove+restore/no-op/unrelated owner mutations permanently invalidate prior unreserved epoch; DB clock after locks; revocation-before-reservation wins; no Connection/auth row lock inversion or deadlock bypass |
| B4 | Consume+attempt+state+audit atomic; concurrent execute/cancel/revoke deterministic; one permit, no repeated dispatch; SQL deadlock/cancel before reservation means zero call and fixed safe error |
| B5 | Original signer explicit revoke and repeat; other actor denied; original requester cancel and pending rejection; loss/expiry commits terminal invalidation+approval revocation+audit; rights restoration cannot revive; post-reservation ACTION_ALREADY_RESERVED |
| C1 | Complete request → stored-preview independent approval → reserved create → separately authorized matching read ordinal1 → VERIFIED; every response synthetic |
| C2 | Crash before/after create commit/response/publication; timeout/429/5xx/malformed ID visible uncertainty; one lifetime create; audit rollback never false success |
| C3 | Proven pre-call refusal NOT_DISPATCHED; restarted reservation UNKNOWN only after35s; NOT_DUE before; no reset/re-POST; authorization revocation after reserve cannot retroactively prevent approved create |
| C4 | Wrong customer/body/title/marker/ID never VERIFIED; candidate is untrusted; other-client mock invisible; fresh caller/binding authority required for new read/recovery |
| C5 | Budget3 includes initial/failed/crashed reads; claim crash recovers ABANDONED after35s; ordinal never refunded; one active lease; busy/budget/error codes; late/expired/abandoned nonce cannot publish even without replacement |
| C6 | Late original ID versus active candidate same/different IDs in both orderings; conflicting original/verified ID cannot replace verified fact; known original ID cannot be overwritten by candidate; no new read/create from continuation |
| C7 | Title/body/customer/ticket IDs/credential refs/token hashes/raw errors absent from public outputs; stored private preview whitelist exact; new absolute wx0600/no-follow file outside any Git worktree; existing/symlink/repo paths refuse; no echoed private input |
| C8 | DISABLED default; LIVE/origin/custom port/provider callbacks refuse; MOCK only FIXTURE; network trap observes zero native calls |
| R1 | Existing Gateway still refuses writes; ClientContextV1/DTO and Atera/Huntress/M365 reads compatible |
| R2 | Full checkpoint suite; active files≤700; frozen migrations/reports preserved; owner upgrade from accepted Stage2 and exact grant/role rendering tests pass |

Synthetic store/journal cannot satisfy Stage1/2 live gates or claim verified vendor wire schema, token routing, notifications,
production idempotency, backup/restore or operational readiness. Future S3-LIVE needs reviewed official adapter contract,
retention/privacy/operational prerequisites and owner approval for a designated real write. S2-LIVE remains deferred.

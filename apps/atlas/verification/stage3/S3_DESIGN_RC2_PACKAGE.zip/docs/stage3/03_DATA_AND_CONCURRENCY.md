# Stage 3 persistence and concurrency — RC2

Add new migrations + prisma/actions.prisma; preserve every frozen migration and reserved legacy Approval row/model.
Legacy Approval never authorizes these actions; existing read Gateway stays write-denying.

## Models and immutable columns

ActionRequest: scoped UUID PK; requester Actor/token ROW ID (no digest); scoped Connection FK; idempotency key/user-intent
hash; immutable canonical input/hash/type/policy/port/mode/binding/authorityEpoch; state/timestamps/private ticket ID/safe code.
Unique (workspace,client,requester,idempotencyKey); derived UUID collision never adopts another request.
ActionApproval: scoped request FK; unique request; signer Actor/token ROW ID; immutable request hash/version/epoch/decision
identity; mutable decision APPROVED|REJECTED|REVOKED|CONSUMED and consumedAt; fixed approvedAt/expiresAt. DB rejects self-approval.
ActionAttempt: scoped request FK; unique request for lifetime; random immutable attempt token/nonce/reservedAt/startDeadlineAt;
state RESERVED|NOT_DISPATCHED|UNKNOWN|CREATED|VERIFIED|MISMATCH; immutable-once private original and verified ticket IDs;
safe codes/timestamps; request private result ID can be set once only by successful verification;
verificationCount 0..3 and monotonic verificationSeq; nullable activeVerificationToken/startedAt/deadlineAt/candidateID;
verification state IDLE|ACTIVE|FAILED|ABANDONED|VERIFIED|MISMATCH. Current claim fields mutable, attempt identity never reset.
ActionVerification: scoped attempt FK; PK ordinal1..3; immutable nonce/candidateID/startedAt/deadlineAt/request hash/create nonce;
state ACTIVE|FAILED|ABANDONED|VERIFIED|MISMATCH and completion time/safe code. No reset or replacement of consumed ordinal.
ActionMockTicket: scoped Connection FK/UUID, constant S3_SYNTHETIC, customer key, marked title/body/time. Immutable independent
commit, no deduplication by marker. Not ExternalEntity/RawEvent/ResourceSnapshot; never read by baseline context or live evidence.
ActionAuthorityFence: workspaceId FK/PK and monotonic version. Runtime locks via UPDATE(workspaceId) privilege, cannot change it.
All scoped relations use composite FKs including workspace/client; actor/token identities use workspace-scoped composite FKs.

New tables use ENABLE+FORCE RLS. Runtime policies: workspace/client for client rows, workspace for fence. Runtime has SELECT,
INSERT only where services create rows, column-limited mutable UPDATE, no DELETE/TRUNCATE. Fence runtime has SELECT and only
UPDATE(workspaceId), no INSERT/version UPDATE. Identity/intent/epoch/nonce fields and mock contents immutable via grants/triggers.
Existing baseline FORCE setting is unchanged; owner test fixtures create auth/Connection rows before runtime action services.
Do not assume unscoped non-superuser owner can read/insert new FORCE tables; migration initialization is before FORCE is enabled.

## Credential-row recheck without persisted digests

Current bearer is hashed only in memory; initial lookup uses the accepted app.token_hash protocol. Inside fenced transaction,
re-read current bearer, resolve Actor/membership, derive verified workspace/client and current ApiToken ROW ID. Never trust an
Actor supplied by a caller. Clear token_hash before ordinary scoped data access; all GUCs transaction-local.
Add a SELECT-only ApiToken lookup policy for same verified workspace + app.actor_id. Its purpose is descriptor revalidation
by recorded row ID; select only workspace/id/actorId/revokedAt/expiresAt, never tokenHash or label. Temporarily set actor_id
from immutable stored signer identity, load that exact token row and ACTIVE actor/membership, then restore executor context.
It grants no INSERT/UPDATE or app endpoint; old initial auth with empty workspace/actor continues using only bearer-hash lookup.
Action rows/DTOs contain no token digest. Ordinary action reads never use signer lookup policy to publish credentials.

## Privileged fence surface, initialization and ACL

One trigger-only function public.atlas_action_authority_fence(), SECURITY DEFINER, owned by a NEW dedicated
atlas_action_fence_definer (rendered unique name per disposable DB). NOLOGIN, NOINHERIT, NOSUPERUSER, NOBYPASSRLS,
NOCREATEDB/NOCREATEROLE/NOREPLICATION; no member-of roles; no relation ownership. Existing cleanup definer/grants unchanged.
Only trusted migration owner may have creator membership ADMIN+SET, never INHERIT (same controlled PG16+ exception as cleanup
provisioning). Runtime and all other roles have no membership/SET path to fence definer.
Exact definer grants: schema USAGE; fence SELECT(workspaceId,version), INSERT(workspaceId,version), UPDATE(version); no DELETE,
no other relation/sequence/function privileges. Fence FORCE policies TO that exact role allow these operations USING/WITH CHECK
true; runtime policy remains workspace-scoped. Role has no access to Actor/tokens/membership/client action content.
Function search_path=pg_catalog,pg_temp; ALL relations/functions referenced fully qualified public or pg_catalog. PUBLIC and
runtime EXECUTE revoked; trigger-only return type, no ordinary callable wrapper. No dynamic SQL or caller workspace argument.

Migration creates fence and populates existing Workspace IDs before FORCE. Roles.sql creates/validates definer, sets grants,
installs role-specific fence policies and transfers trigger function owner. Applications and owner auth/Connection mutation
must stay stopped between deploy and completed roles provisioning; startup refuses incomplete surface.
Workspace AFTER INSERT creates exactly one version0 fence from NEW.id in the same transaction, through the definer.
Workspace DELETE is explicitly refused in this slice; no fence-row deletion exists (whole disposable DB teardown unaffected).
Workspace identity moves, and workspace/client/identity moves on auth/Connection rows, are refused. Missing/collision fence
creation -> rollback, not repair by an application. Ordinary runtime cannot initialize missing fences.

BEFORE INSERT/UPDATE/DELETE on Actor/ClientMembership/ApiToken/Connection always takes/increments the SAME fence version,
even no-op or unrelated mutation: derive workspace ONLY from affected NEW/OLD row. UPDATE increments exactly one row;
GET DIAGNOSTICS row_count must equal1, otherwise raise ACTION_FENCE_NOT_READY and roll back the AUTH/BINDING mutation.
Do not use app.workspace_id for privileged trigger scope. Global version never resets; any such mutation invalidates all
unreserved requests in that workspace. S3-A installs the COMPLETE function/role/policies/triggers before fenced requests.

Roles.sql extends its role-name validation/rendering, function ownership and grants for this separate role only. Startup
facts retain every cleanup check, then check fence function exactly once, security-definer/owner/settings/ACL, exact role
attributes/memberships/privileges, exact role policy and runtime column grants, FORCE RLS, enabled four mutation triggers +
Workspace insertion/deletion triggers, and one fence per workspace. Mutation admission also refuses an invalid privileged
surface. Owner DDL that disables triggers is outside supported operation and is detected by those checks.

## Locking and atomic outcomes

READ COMMITTED: authenticate workspace hint -> lock fence -> recheck current credential/signers/binding/epoch -> request ->
approval -> attempt -> verification ordinal. Do not row-lock Connection/auth rows; plain reads behind fence are sufficient.
Other workflows may hold their row before firing a fence trigger: DB deadlock/serialization abort is ACTION_DB_CONFLICT,
whole pre-dispatch transaction rollback, zero port calls; no automatic retry. Cross-workspace moves are prohibited.
Clock_timestamp is evaluated after locks. No port call inside any transaction.

Request/audit, approval/audit, terminal denial/audit, consume+reservation/audit, each result/audit are atomic. Guard invalidation
is a committed terminal outcome; caller returns failure after commit instead of throwing away the persisted invalidation.
Private continuation handles minted on reservation can record owned create facts after signer revocation; no new invocation
or verification authority. They never leave trusted composition/capability map. New user reads/recovery verify fresh authority.
No purge runner is introduced: synthetic RLS-confined content retained; actual retention/erasure is required in future LIVE amendment.

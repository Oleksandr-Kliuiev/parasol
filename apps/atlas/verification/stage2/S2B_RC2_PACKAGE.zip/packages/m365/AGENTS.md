# M365 domain services routing (Stage 2, S2-B)

Read docs/AI_CONTEXT_MAP.md first; contracts: docs/stage2/02_CONTRACTS.md §1–3, 03_CONNECTOR_SYNC.md §2–6.
Graph transport/auth/nextLink rules live in ../../connectors/microsoft365 (contract.ts, http.ts, auth.ts, connector.ts).
- authority.ts: pins (tenant + lifecycleVersion), Connection-first lock, current-authority recheck, Graph session authority.
- activation.ts: versioned one-use activation capability (private numeric expiry), probes, conditional ACTIVE.
- directory.ts: claim → stage pages → ONE publication transaction (mirrors, pointer, counts, audit) / fenced failure;
  persisted 429 `retryAt` (migration 202610081300) gates claims before any I/O.
- windows.ts: sign-in request, root-job budget, attempt claim, publication, failure, requeue. ingest.ts: leaves, pages, splits.
- signin-rows.ts (pure: [from,to) position, version hash, backoff, split), status.ts (pure read semantics), io.ts (composition).
Lock order everywhere: Connection → request (counters) → window/resource state → root job → attempt/generation → leaf.
Never hold a lock over network I/O; read the clock after locks; never store nextLinks or tokens. Keep files ≤500 lines.
Leases/deadlines/bounds are read from the persisted rows; claim descriptors are informational only.
M365SyncRequest.state stays OPEN by design in S2-B (finished outcomes are immutable while requeue may reopen a job);
per-root job states are authoritative; a derived request status belongs to S2-C m365-status.
Tests: tests/m365-{auth,http,adapter}.test.ts and tests/pg/m365-{activation,directory,directory-retry,order,windows,window-recovery,
window-publication,window-limits,retry-upgrade}.pg.test.ts.
S2-C (read API/tools/CLI, correlation, retention service) is not here yet.

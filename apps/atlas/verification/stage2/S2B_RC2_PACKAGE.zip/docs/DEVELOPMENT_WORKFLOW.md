# Atlas delivery workflow

Established 2026-10-08. This is an operating policy, outside the Stage 2 normative package.
It neither accepts an architecture nor authorizes implementation, live access or deployment.
The current stage's specification, implementation plan and acceptance criteria remain authoritative.

## Roles and gates

| Role | Responsibility | Execution route |
|---|---|---|
| Codex orchestrator | Clarify scope with the owner; prepare architecture and task briefs; coordinate work, verification, integration and status | Current Codex project chat |
| GPT-6 Astra | Independent architecture review and implementation checkpoint acceptance | Explicit `gpt-6-astra` subagent, `xhigh` effort |
| Claude Fable 5.1 | Independent architecture review; exceptional unresolved reasoning problems | Claude Code, native Anthropic, explicit `claude-fable-5-1` |
| Claude implementer | Implement the approved concern, run relevant checks and report evidence | Claude Code with an explicit model and effort |
| DeepSeek V4.1 Flash | Optional additional search for contract inconsistencies, edge cases and missing tests | DeepSeek Harness `dsh`; explicit `deepseek-flash` provider model |

For a new stage or material architecture change:

1. Codex prepares a bounded specification, contracts, acceptance cases and checkpoint plan.
2. Astra and Fable review the same frozen package independently, without each other's initial verdicts.
3. Codex resolves findings, updates the package identity and obtains both approvals for the current version.
4. Within an implementation request, Codex delegates one coherent task or tightly coupled task group to Claude Code.
5. The implementer runs focused checks. At a checkpoint, Codex inspects the diff and required evidence, then Astra reviews independently.
6. Required findings return to the implementer. Astra verifies the fixes before dependent checkpoint work advances.

Ordinary changes inside approved architecture do not require another two-model architecture review.
A change to authority, data boundaries, durability, public contracts or accepted behavior does.
DeepSeek findings are evaluated on their evidence; its approval cannot replace Astra or Fable.
Initial architecture reviews and the first review of each checkpoint use fresh context, with no other reviewer verdict
in the initial brief. Astra is always explicitly gpt-6-astra with explicit effort; prefer a native subagent with
fork_turns="none", never parent-model inheritance. A bounded re-review can retain its own session only for closure and
nearby regressions with unchanged contracts/invariants and passed affected checks. New scope or critical invariant changes
require a fresh xhigh reviewer. A resumed session keeps its effective effort unless the runtime actually changes it.

Reviewers do not edit the implementation they are accepting. Acceptance is tied to exact content and scope,
not a majority vote or a model's self-assessment. Before advancing, verify the current artifact still matches the accepted
identity. Later changes need renewed review of the affected scope. Status-only administration needs no code re-review
unless it changes requirements, reviewed content or acceptance evidence. Live and production gates remain separate.

## Initial model policy

The owner's Anthropic plan is Max 5x. Evaluate the cost of reaching acceptance, including repairs and review.
This allocation is a starting hypothesis, not a measured comparison of these models on Atlas.

| Work | Model / effort | Reason for allocation |
|---|---|---|
| Bounded implementation with explicit contracts; DTOs; routine API wiring; straightforward tests | Sonnet 5.5 / medium | Main implementation path with restrained reasoning spend |
| Authorization, isolation, SQL constraints/migrations, atomic publication, concurrent workers, recovery, identity resolution | Opus 5.5 / high | Start with more reasoning where mistakes can invalidate the design |
| Difficult task whose implementation remains stuck after diagnosis | Opus 5.5 / high, then deeper effort only when justified | Escalate on evidence instead of repeating unsuccessful attempts |
| Independent architecture review | Fable 5.1 / high, plus GPT-6 Astra / xhigh | The owner's required reviewers |
| Independent checkpoint acceptance (S2-A, S2-B, S2-C) | GPT-6 Astra / xhigh | Verify the actual implementation and checkpoint evidence |
| Bounded re-review of identified fixes with unchanged contracts/invariants and passed affected checks | GPT-6 Astra / high | Only when reviewed architecture and surrounding invariants remain unchanged |
| Exceptional problem still unresolved by Opus | Fable 5.1 with a bounded brief and verified billing | A targeted escalation, not the routine code generator |

Pin full model IDs (`claude-sonnet-5-5`, `claude-opus-5-5`, `claude-fable-5-1`) and effort on every launch.
For Astra, explicitly set `model: gpt-6-astra` and `reasoning_effort: xhigh` (or `high` for the bounded re-review above).
Use a fresh `xhigh` reviewer for new scope or changes to authorization, isolation, atomicity, concurrency, recovery,
public contracts or other critical invariants. Diff size does not determine effort. Reserve `max` for exceptional
unresolved problems; record the effective effort with the review evidence.
Record the selected effort in review evidence; do not infer it retrospectively for older reviews.
Do not rely on the CLI's personal default or a moving alias. Changing this policy does not silently change that default.
Use normal inference speed; premium fast modes, API billing and usage credits are outside included-limit work unless agreed.
Haiku is not the initial choice for Atlas implementation; saving tokens on the first attempt is not the acceptance metric.

### Stage 2 allocation, after its architecture gate

| Plan task | Initial implementation assignment |
|---|---|
| 2.1 focused contracts and DTO schemas | Sonnet / medium; escalate if the approved contract needs a design decision |
| 2.2 persistence/grants and 2.3 permission/compatibility boundary | Opus / high |
| 2.4 Graph adapter | Sonnet / medium for mechanical DTO/HTTP work; Opus / high for token/tenant, URL and redirect boundaries |
| 2.5 directory generations and 2.6 sign-in windows | Opus / high |
| 2.7 deterministic correlation and identity rules | Opus / high |
| 2.8 read API/tools/CLI | Sonnet / medium for transport wiring; Opus / high for any new authorization or redaction logic |
| 2.9 retention/maintenance behavior | Opus / high; Sonnet can update the operational instructions |
| 2.10 acceptance fixtures, evidence and handoff | Sonnet / medium; Astra independently accepts the checkpoint |

Implementation checkpoints remain S2-A, S2-B and S2-C as defined in
[the stage plan](stage2/04_IMPLEMENTATION_PLAN.md). S2-LIVE requires its separate prerequisites.
Choose one owner for each bounded task; split ownership only when the file/domain boundary is clear.

## Task and review handoff

Each task brief provides:

- Outcome, permitted scope, non-goals and smallest relevant entry files.
- Baseline commit plus dirty-file snapshot/hash when work is uncommitted; approved architecture package identity.
- Invariants and acceptance cases, required commands, model/effort and assigned checkpoint.
- Allowed tools, write scope and reporting destination; no credentials or real customer records in prompts or reports.

Use one owner of write access per checkout, including Codex, delegates, formatters, snapshot and lockfile updates.
Transfer ownership explicitly; Codex regains it only after the writer finishes or is confirmed stopped. Parallel reads
and checks are permitted only without modifying reviewed files or conflicting over resources. Parallel writers need
isolated worktrees, explicit ownership and an integration plan.
Include required uncommitted work explicitly in an isolated baseline; a worktree at HEAD alone will omit it.
Keep one implementation session per cohesive task and its related fixes; use a fresh session for independent tasks or
assessment, subject to the reviewer rules above. Keep reusable instructions, tools and approved reference material stable
where practical; append findings and deltas. Do not retain unrelated history just for cache hits. Use commands for routine
checks and delegate when independent analysis is needed.
If safe mode disables automatic instruction loading, include the instruction paths explicitly in the brief.
Give reviewers enough repository/tool access to substantiate findings without write access to the implementation.

At handoff record changed files, actual commands and outcomes, actionable failures and remaining risks.
Run focused checks during edits and the stage's full required checks at checkpoints; rerun affected checks after fixes.
Do not rerun unchanged broad suites just to generate another report. Do not equate mocks with live verification.
After two repair attempts without meaningful progress, diagnose the contract, implementation or environment and escalate.
Escalate immediately for an isolation/authorization breach, data-loss risk or architectural contradiction.
Do not respond to a failing test by removing its requirement or loosening assertions to fit the implementation.

## Provider identity and budget

- Claude Code uses native Anthropic authentication; DeepSeek uses its own Harness configuration and credentials.
- Before external reviews, check routing and authentication without exposing tokens. Save CLI version, requested model,
  effective endpoint/provider, actual response model(s), effort, artifact identity and fallback events where observable.
- Requested model names, text self-identification and client accounting labels alone are insufficient identity evidence.
  If the required identity cannot be verified or a fallback handles the review, keep that named-model gate pending.
- Max usage is shared with Claude chat. API price tables and CLI estimated dollars do not establish the remaining quota.
- Check Fable's plan-specific billing before unattended execution: Claude Code `-p` can bill usage credits without a prompt.
  Do not enable credits or switch to API billing to get around a limit. Use the owner's agreed budget if separate billing applies.
- Start with one Claude implementation process. Add concurrency only for isolated work when its latency benefit warrants the usage.

For the first checkpoint, record per task: assigned/observed model, effort, duration, repair rounds,
confirmed review defects, acceptance outcome and usage when attributable. Mark unavailable quota data as unknown.
Use cache statistics to diagnose repeated input processing separately from subscription usage; cache-hit percentages
and API dollar estimates do not establish quota savings.
After S2-A, adjust the Sonnet/Opus boundary using this evidence; continue evaluating over 5-10 representative tasks.
Do not run duplicate paid implementations merely to benchmark every change.

## Current state and next action

On 2026-10-08, the local tools were Claude Code 2.1.293 and DeepSeek Harness 0.2.0-rc.2.
Anthropic authentication was reported as `claude.ai` / `firstParty`; no inherited DeepSeek overrides were present.
This configuration check does not prove successful inference or named-model access.

Stage 2 RC5 architecture is accepted by Astra xhigh and provider-verified native Fable high on the same package.
[REVIEW_STATUS.md](stage2/REVIEW_STATUS.md) contains exact identity and approval scope.
The owner requested implementation. Tasks 2.1–2.3 / S2-A are accepted by Astra xhigh.
Tasks 2.4–2.6 / S2-B use one native Opus 5.5 / high session; fresh Astra xhigh independently accepts the current artifact.
[Implementation status](stage2/IMPLEMENTATION_STATUS.md) is the current checkpoint/status authority; live and later gates remain separate.

## Source basis, checked 2026-10-08

- [Anthropic model selection](https://platform.claude.com/docs/en/about-claude/models/choosing-a-model): capability, effort and cost tradeoffs require task-specific evaluation.
- [Claude Code models and effort](https://code.claude.com/docs/en/model-config): exact model selection, effort levels, fallback and Fable usage-credit behavior.
- [Sonnet 5.5 guidance](https://platform.claude.com/docs/en/models/sonnet-5-5/whats-new-sonnet-5-5): medium as a starting point for well-specified agentic work.
- [Pro/Max usage](https://support.claude.com/en/articles/11145838-use-claude-code-with-your-pro-or-max-plan): subscription usage is shared across Claude and Claude Code.
- [OpenAI guidance on instructions](https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra): keep instructions concise and load context according to the task.

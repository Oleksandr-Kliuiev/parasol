import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';
const root=process.cwd(); const mod=p=>import(pathToFileURL(`${root}/${p}`));
const {setupM365Database}=await mod('tests/support/m365-pg.ts');
const {gasta}=await mod('tests/support/graph-fixtures.ts');
const {M365_CONNECTION}=await mod('tests/support/m365-fixtures.ts');
const {hourStart,iso}=await mod('tests/support/m365-signin-mock.ts');
const {addReader,confirmM365Links,publishScenarioDirectory,addHuntressObservation,publishSignIns,signIn,KARI,REGISTRATION,reader,readDeps}=await mod('tests/support/correlation-fixtures.ts');
const {readCorrelation,eligibilityEndMs,assertInterval,assertUnexpired}=await mod('packages/correlation/read.ts');
const {readSignIns}=await mod('packages/m365/reads.ts');
const {cursorExpiry,checkCursor}=await mod('packages/correlation/cursor.ts');
const input={from:'2026-10-01T12:00:00.1239000Z',to:'2026-10-01T12:00:01.0000000Z'};
const first={now:new Date('2026-10-08T12:00:00.123Z'),key:'2026-10-08T12:00:00.1235000Z'};
assertInterval(input,first);
const transitionMs=eligibilityEndMs(input),e=cursorExpiry(first.now.getTime(),[transitionMs]);
const next={now:new Date('2026-10-08T12:00:00.124Z'),key:'2026-10-08T12:00:00.1240000Z'};
const claims={v:1,b:'binding',f:'fingerprint',p:'position',e};
assertUnexpired(claims,next);checkCursor(claims,next.now.getTime(),'binding','fingerprint');
let outcome='accepted';try{assertInterval(input,next);}catch(err){outcome=err.code;}
console.log(JSON.stringify({case:'sub-ms eligibility',firstClock:first.key,actualTransition:'2026-10-08T12:00:00.1239000Z',flooredTransition:new Date(transitionMs).toISOString(),issuedExpiry:new Date(e).toISOString(),nextClock:next.key,cursorCheck:'passed',serviceNextPageCode:outcome}));
const {pgdb,db}=await setupM365Database();
try {
 await addReader(pgdb.owner);await confirmM365Links(pgdb.owner);await publishScenarioDirectory(pgdb.owner);await addHuntressObservation(pgdb.owner,'obs-review');
 const R=hourStart(4),end=new Date(R.getTime()+3600000);
 const row=(code)=>signIn('historical-review',iso(R,120000),KARI,REGISTRATION,{status:{errorCode:code}});
 const stable=signIn('stable-review',iso(R,60000),KARI,REGISTRATION);
 await publishSignIns(db,()=>[row(0),stable],R,end);
 const edge=new Date(Date.now()+6000);
 // Preserve every production trigger and constraint: the ordinary permitted COMPLETE -> SUPERSEDED
 // transition is given a shorter expiresAt, which the schema explicitly permits (>startedAt, <=coveredTo+7d).
 let changed=false;
 const bounded=db.$extends({query:{m365WindowAttempt:{async update({args,query}){
  if(args.data.state==='SUPERSEDED'){args.data.expiresAt=edge;changed=true;}
  return query(args);
 }}}});
 await publishSignIns(bounded,()=>[row(50126),stable],R,end);assert.equal(changed,true);
 const params={connectionId:M365_CONNECTION,from:R.toISOString(),to:end.toISOString(),limit:1};
 const cp=await readCorrelation(db,reader,gasta,{...params,observationId:'obs-review'},readDeps());
 const sp=await readSignIns(db,reader,gasta,params,readDeps());
 const decode=c=>JSON.parse(Buffer.from(c.split('.')[0],'base64url').toString());
 const historical=(await pgdb.owner.query(`SELECT a.state, a."expiresAt"::text AS "attemptExpiryUtc", e."expiresAt"::text AS "evidenceExpiryUtc" FROM "M365WindowAttempt" a JOIN "M365WindowEvidence" m ON m."attemptId"=a.id JOIN "M365SignInEvidence" e ON e.id=m."evidenceId" WHERE a.state='SUPERSEDED' AND e."sourceId"='historical-review'`)).rows[0];
 assert.equal(cp.items[0].evidenceState,'CONFLICTED');assert.ok(decode(cp.nextCursor).e>edge.getTime()+60000);
 console.log(JSON.stringify({case:'historical-attempt expiry',attemptState:historical.state,attemptExpiryUtc:historical.attemptExpiryUtc,evidenceExpiryUtc:historical.evidenceExpiryUtc,firstState:cp.items[0].evidenceState,correlationCursorExpiry:new Date(decode(cp.nextCursor).e).toISOString(),listCursorExpiry:new Date(decode(sp.nextCursor).e).toISOString()}));
 await sleep(Math.max(0,edge.getTime()-Date.now()+150));
 for(const [surface,read] of [['correlation',()=>readCorrelation(db,reader,gasta,{...params,observationId:'obs-review',cursor:cp.nextCursor},readDeps())],['sign-in-list',()=>readSignIns(db,reader,gasta,{...params,cursor:sp.nextCursor},readDeps())]]){
  let code='accepted';try{await read();}catch(err){code=err.code;}console.log(JSON.stringify({case:'historical-attempt next page',surface,code}));assert.equal(code,'CORRELATION_CHANGED');
 }
 const fresh=await readCorrelation(db,reader,gasta,{...params,observationId:'obs-review'},readDeps());
 console.log(JSON.stringify({case:'historical-attempt reread',state:fresh.items[0].evidenceState,canonicalPersonPresent:!!fresh.items[0].canonicalPersonId}));
}finally{await db.$disconnect();await pgdb.drop();}

# PostgreSQL test context routing

Start with docs/AI_CONTEXT_MAP.md and the named acceptance case, then read only its test and small support module.
Stage 2 S2-A: m365-scope, m365-schema, m365-upgrade, m365-permissions, m365-disable, m365-privileges,
m365-routine-acl, m365-nonsuper, and roles-output. Shared setup: ../support/pg-harness.ts and m365-fixtures.ts.
Stage 2 S2-B: m365-activation, m365-directory, m365-directory-retry, m365-order, m365-windows, m365-window-recovery,
m365-window-publication, m365-window-limits, m365-retry-upgrade, m365-directory-budget, m365-budget-upgrade,
m365-signin-outcomes, m365-sync-denial
(mock Graph via ../support/m365-graph-mock.ts and m365-signin-mock.ts; setup ../support/m365-pg.ts).
Stage 2 S2-C: correlation, correlation-negative, correlation-provenance, correlation-pages, correlation-expiry (deliberate waits),
m365-reads, m365-tools, m365-api, m365-cli-sync, m365-cli-read, m365-privacy-retention, m365-cleanup-target (two databases), m365-e2e
(setup ../support/correlation-fixtures.ts; actual CLI via ../support/m365-cli.ts + the test-only m365-fetch-preload.ts).
These tests use disposable databases and unique roles; never run them against a persistent tenant database.
Do not print environment values, connection URLs or credentials. Keep synthetic data and cleanup in finally/after.
Preserve existing Stage 1 journeys; use focused tests during edits and the required suite at checkpoints.

# Manual browser-to-instrument evidence handoff

## Proposed fixed-surface exception

Add exactly one optional same-origin route:
`POST /clients/:id/ask/evaluation-handoff`.
It is enabled only for the measured registered synthetic sandbox and one owner-paired run. Otherwise it is
ordinary404. No query/path encoding aliases, GET, generic proxy, arbitrary destination, file upload/download,
provider call, tool, source query or account/policy mutation. It never invokes the Ask service.
Two closed operation DTOs below cover pairing and delivery; they do not extend AskRequestV2/AskAnswerV2.

The existing Ask POST accepts the extra opt-in header `X-Atlas-Evaluation-Session` ONLY in that registered
sandbox. A paired armed request may receive `X-Atlas-Evaluation-Receipt` on the ordinary Ask response.
Neither header travels to the provider or grants authority. The token/header exception and route need fresh
architecture/code review. They are not claimed as part of the previously accepted two-operation surface.

The browser still manually fetches capabilities and performs every per-question checkbox/Ask click under
its accepted generation guards. The instrument never consents, edits or submits the browser request, uses
a provider route, or drives a synthetic UI click. A separate manual "Send evaluation evidence" button is
available only for the current eligible completed response. This button cannot submit/retry a question.

## Pairing and arm

The measured owner controller already binds registration, process boot and instrument connection (01).
An explicit owner `pair` command generates a one-use 256-bit base64url pairing nonce (43 canonical chars),
valid for120s, mapped to one expected workspace/client/actor/admission and instrument connection. It stays
in memory and is entered into the local browser pairing panel; no URL/query/storage/cookie/history/receipt.
Displaying the nonce is transient; terminal/session recording and clipboard managers must be excluded by
platform privacy proof. Prefer direct typing; do not copy question/answer data through a clipboard.

PAIR request body exact:
`{contractVersion:'RevalBrowserHandoffV1',operation:'PAIR',pairingNonce}`.
It uses the private existing browser bearer and an exact same-origin Host/Origin check. The server checks
current ACTIVE actor and same-membership context:read+ask:remote, scope matches owner registration and
nonce, existing credential epoch, measured boot/instrument connection, and real nonce lifetime. It reads
no source or provider key. Missing/foreign bearer, scope, nonce or origin cannot create a pair.

PAIR200 body exact:
`{contractVersion:'RevalBrowserHandoffV1',pairId,sessionToken,serverBootId,expiresAt}`.
PairId/serverBootId are UUID; sessionToken is independent256-bit base64url. A pair lasts at most10 minutes,
no later than the real admission expiry, and is revoked on pause/fixture generation/credential/actor/scope/
policy change, disconnect, server restart or instrument loss. One pair per registered server; no overwrite
of an occupied pair. Browser stores it in its private closure only; it never replaces or contains a bearer.
PAIR failure has a fixed code only; successful pairing does not mean policy ACTIVE or data/budget admitted.

Owner `arm-case` request is metadata only:
`{caseId,fixtureId,fixtureGeneration,admissionId,policyVersion,preSnapshotId,browserPairId}`.
The controller checks the frozen case-to-fixture mapping, exact fresh complete snapshot/fixture/process
binding, current policy/headroom and the instrument's existing consumed-case/GO prerequisites. It cannot
arm a consumed case, a second in-flight case or an unadmitted run. The instrument still checks question
and focus equality IN MEMORY before GO; no expected label/question/hash is sent in this command.

ARM_ACK payload exact:
`{armId,caseId,fixtureId,fixtureGeneration,admissionId,policyVersion,preSnapshotId,expiresAt}`.
ArmId is random UUID; arm expires within5s on server monotonic time, before the pre-snapshot freshness limit,
policy/credential expiry, UTC bucket change or original instrument GO limit. The server atomically claims
that arm for the FIRST authenticated Ask POST bearing the paired session token. Manual Ask submission
still supplies the exact accepted five-key V2 body; no case ID/model/budget/authority field is added there.

Inside the registered active evaluation interval, an absent/invalid/expired pair or arm denies Ask before
reservation and increments the safe ingress census. No automatic retry/re-arm. Once any Ask submission
claims an arm, the case is consumed even if parsing/auth/DB/provider later fails. Duplicate/hidden submits
are recorded as integrity events; they cannot reuse the slot or obtain another private dispatch capability.
Normal runtime authority, consent tuple, budgets, dispatch and publication gates still all execute.

## The server must bind the actual values

For a claimed arm the API retains the parsed, exact original AskRequestV2 in a private memory slot, associated
with task identity, server correlation, credential epoch, fixture generation, policy/fence and pairing.
After final current-authority/audit commit and immediately before HTTP serialization, attach the EXACT
immutable answer projection/status/correlation that the server sends to that slot. For an eligible scoped
error, bind the exact public error/status/correlation and its known task terminal metadata instead.
Never place upstream content or errors in the slot. Raw values cannot enter a generic logger/receipt object.

The one-use response nonce in `X-Atlas-Evaluation-Receipt` identifies the private slot, not an answer cache.
Mint it only when a slot has a bound actual publication; a caller-supplied nonce/correlation cannot make one.
The server may not expose slot contents via GET, polling, owner metadata export or another client's call.

The browser retains its exact actually-submitted request snapshot and the actually-received parsed response,
status and correlation header under the accepted private generation state. Its existing WHOLE response
validator runs first. A stale, wrong-scope, malformed, wrong-model or rejected response does not become
eligible by toggling a new button. Every accepted credential/scope/context/queue/selection/focus/disclosure/
request guard remains authoritative; edits/refresh/pagehide/bfcache clear the handoff reference as required.
A manual click captures the still-current immutable values; no checkbox consent is reused or altered.

RESPONSE body exact:
```
{contractVersion:'RevalBrowserHandoffV1',operation:'RESPONSE',pairId,receiptNonce,
 request:<exact AskRequestV2>,response:{status,correlationId,body:<AskAnswerV2|AskErrorV1>}}
```
Use the private bearer plus session header. The server first authenticates scope/pair/current authority,
then atomically moves the nonce from AVAILABLE to CLAIMED before validating/transferring values. It checks
strict DTOs and structural equality against its private request AND publication objects: all keys/values,
exact question/focus/requestId/acknowledgement, status/correlation and every answer/error field. No content
hash, signature over a question, body logging, client `validated:true` flag or claimed current authority.
Edited text/answer before POST cannot match the server slot and is not accepted as authentic evidence.

The endpoint repeats the bounded current all-of/credential/actor/scope/policy/fixture checks under the
accepted authority fence; no source read, financial lock or owner mutation. A successful answer handoff
requires both the stored successful publication authority result and current authority at handoff. These
are distinct instants. Revocation in between invalidates handoff; it does not retroactively assert an
unauthorized original publication. Errors without sufficient scoped task continuity remain unattributed.
Release DB locks before IPC; recheck private pair/nonce/generation before committing the transfer.

Only the matched BROWSER values are delivered once through the authenticated private local IPC to the paired
instrument, together with the server's metadata binding and fixed verification result. The instrument reruns
its accepted request/answer validators and independent frozen-fixture comparator; it cannot trust a server
"pass" in place of those checks. It then acknowledges only the safe result. Browser204 has no body.
A missing acknowledgement, disconnect, bad comparison, expiry or overflow burns the nonce and yields
`LOCAL_HANDOFF_UNVERIFIED`; do not retry Ask or silently send the handoff again. The original liability is
still determined separately; no handoff failure grants a refund.

Successful transport does not prove a human clicked, that the browser was uncompromised, or that intent was
correct. The measured browser build and UI tests support the generation/manual-action property; operator
identity remains separately attested unless independently authenticated. Receipt provenance never treats
an untrusted browser assertion as owner/server authority.

## Memory, bounds and time

PAIR body <=1KiB. RESPONSE body <=288KiB incremental actual bytes (16KiB original request, <=256KiB accepted
reply plus bounded wrapper); fatal UTF-8, strict duplicate-key rejection, closed keys, max nesting as the
accepted DTO permits. Independent 2s handoff receive/validation/IPC deadline; it never extends the original
Ask/provider deadline or supplies another provider attempt. No request/response file, clipboard body, HAR,
trace, video, saved devtools response, shell paste or temporary spool.

One transient publication slot per pair, at most one pair per server. Retained values have combined serialized size <=288KiB; bounded parsed-object overhead is measured separately. Reject rather
than evict/reassign an occupied slot. Drop references on successful acknowledged transfer, failure,
server-observed revocation, pair loss, server shutdown, or at120s from Ask ingress,
whichever is first. Timer uses real monotonic time and cannot renew on reads/retries. Original transport/DB
physical ownership remains subject to its existing four-owner bound independently of this one-slot buffer.
The extra120s synthetic handoff lifetime is an explicit proposed exception to the ordinary drop-at-task-
settlement rule. It is not enabled for ordinary remote traffic. No secure physical memory erasure is claimed.

The instrument processes the transient frame in a type/module that cannot be passed to its persistence API.
Only enums/booleans/numeric money/counters/latency, safe case/fixture/correlation/attempt IDs and approved
artifact/process identities leave it. Raw request, raw answer, observed intent, question or body hash/length,
receipt/session/pairing secret, credential, arbitrary exception text and provider content are never saved.
RequestId may be compared transiently but is not added to financial/runtime evidence persistence.

## Ingress and threat coverage

Retain existing private bearer, Host and no-store boundaries; add exact same-origin Origin and Fetch Metadata
checks for this route, no CORS wildcard/credentialed cross-origin path, no cookies or CSRF token authority.
Reject null/absent/unexpected Origin here. Route/method/content type/body limits are checked before expensive
work. Response headers/body are allowlisted, cache disabled, no redirect/location, URL parameter, callback,
webhook, arbitrary path or deserialization hook. Pair/receipt tokens are unguessable AND scope/process bound.

Test forged/foreign pairing, stolen old nonce, parallel handoff races, replay after success/expiry/restart,
response mutation, wrong actual request, swapped same-shape answer, mismatched requestId/correlation,
policy/scope/focus generation changes, extra keys/duplicate keys/oversize/bad UTF-8, CSRF, origin/DNS rebinding,
IPC peer replacement, unauthorized local read and stalled consumer. Neither devtools editing nor a valid
DTO alone proves server provenance. Root/kernel/owner compromise is outside this local attestation boundary.

Failure to obtain a bound handoff means UNKNOWN/unverified, never observed schema violation solely because
a paste/transport was malformed and never a verified zero. After raw values are dropped, replay can check
numeric/census/closure consistency and receipt allowlists; actual live truth/intent predicates remain
unreplayable under the privacy contract. Keep that qualification in every resulting report.

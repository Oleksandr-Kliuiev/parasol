# Platform proof, privacy and implementation gates

## Independent process/ingress census

The DB ledger cannot count pre-reserve rejects, hidden requests or process-local dispatch work. A measured
server guard and independent platform process/socket inventory therefore supplement the atomic financial
snapshot. This slice admits exactly ONE API server incarnation for the registered synthetic DB. No second
remote operator/process, worker, load balancer retry or replica is silently allowed.

The guard records metadata at entry to every Ask capability/submit path (including rejected/unpaired calls),
authenticated task creation, commit outcome, dispatch capability consumption, transport entry, publication
and actual physical-owner release. Counters advance before handing work to an asynchronous path. No sampled
logs, caller-reported counts or counting only successful handoffs. It stores no question/body/length/hash,
raw path/header, bearer, observed intent or source fact. Pre-scope events use aggregate unattributed counts;
they do not invent a scoped correlation or disclose another tenant.

Exact PROCESS_CENSUS payload:
```
{censusId,guardEpoch,capabilityIngressCount,submitIngressCount,handoffIngressCount,
 rejectedUnpairedCount,unattributedCount,reservationConfirmedCount,commitUnknownCount,
 capabilityConsumedCount,transportEntryCount,publicationCount,physicalReleaseCount,
 activeTaskCount,coverage:'COMPLETE'|'UNKNOWN',tasks}
```
Counts are monotonic Dec64 per guardEpoch/serverBootId. tasks max4 physical owners plus the one handoff slot;
closed task metadata for the current armed case may remain until the POST census, without its raw content.
Each exact task item:
`{correlationId,reservation:'NONE_CONFIRMED'|'COMMITTED'|'COMMIT_UNKNOWN',
capabilityConsumed,transportEntered,noDispatchProof:'ORIGINAL_PRIVATE_PROOF'|'UNAVAILABLE',
ownerReleased,publication:'ANSWER'|'ERROR'|'NONE'}`.
CorrelationId is UUID|null; flags boolean. Private proof objects themselves are never exported/serialized.
A returned metadata flag does not mint a proof or authorize financial mutation.

Capture guard PRE before arming and POST after task release/handoff, on the same uninterrupted epoch. Compare
ingress deltas with operator-reported capability/submission/pacing events, and reservation/transport deltas
with the DB census. Any unreported submit/duplicate/extra dispatch, gap/reset/missing task or incomplete
platform inventory stops the run. Zero net financial change does not hide a second/no-dispatch attempt.
Platform observation covers server process starts/exits and eligible network paths throughout the interval,
not just an initial `ps` snapshot. Unknown continuity makes the corresponding safety category unverified.

The measured guard proves software observations under its trust boundary; platform controls independently
exclude an unmeasured server/connection path and identify lost processes. It cannot prove absence of a
compromised kernel/root/owner or provider-side activity using a separately leaked key. Dedicated-project
account evidence remains a separate owner obligation, not an inferred local counter.

## Egress proof interface

Register the actual execution environment, process family/identity, database local socket, owner IPC,
dedicated browser origin/profile and every network-capable component BEFORE admission. The approved flow
inventory permits only local browser->API, local owner/instrument IPC, local registered DB, necessary
explicitly documented DNS resolution, and server direct TLS443 to `eu.api.openai.com` for the fixed endpoint.
No external APM, analytics, updater, proxy, alternate OpenAI host, redirect, webhook or unrecorded subprocess.
Account for DNS resolver destinations explicitly; do not pretend a hostname allowlist describes every packet.

Platform enforcement must be effective for the measured server process/container, not a documentary config.
Bind host resolution/TLS hostname verification, deny redirects/proxy env/alternate routes, and show the applied
policy includes children and denies unapproved destinations. Browser/instrument have no provider egress.
Transport source/build proof and offline negative tests supplement this, but mocks do not prove platform rules.
No packet/body capture or TLS interception is required or permitted to obtain a numeric destination census.
Do not persist per-request/flow payload byte sizes or timings that serve as body-length records; destination
connection/attempt counts and the separately admitted end-to-end latency are sufficient.

Exact PLATFORM_PROOF payload:
`{environmentId,buildManifestSha256,serverBootId,policyEvidenceRef,destinationInventorySha256,
intervalStart,intervalEnd,processCoverage:'COMPLETE'|'UNKNOWN',
destinationCoverage:'COMPLETE'|'UNKNOWN',unexpectedDestinationCount,
unknownDestinationCount,unmeasuredProcessCount,mode:'MEASURED'|'OFFLINE_SIMULATED',countsAsVerifiedZero}`.
IDs/refs/scalars follow01; booleans strict. Inventory digest hashes approved destination metadata, not traffic.
Counts are measured over the specified actual interval. countsAsVerifiedZero can be true only with measured
complete coverage, zero unknown/unexpected/unmeasured counts and accepted matching platform evidence.
OFFLINE_SIMULATED ALWAYS sets false. Before/after snapshots without interval coverage are not complete.

A proof is tied to real platform configuration/image/time; copying a record from another process, run, host
or policy revision fails. Missing privileges/capabilities leave the platform gate pending. Do not substitute
app-level `fetch` mocks for host egress enforcement or make provider calls as a readiness probe.

## Privacy proof and destination completeness

Before admission, enumerate every potential persistence destination and whether collection is disabled,
scanned locally, or outside local inspection with separate explicit owner evidence. Include at least:

| Area | Required treatment |
|---|---|
| DB | New attempt/counter/audit/security rows; DB statement/parameter/error/slow logs; relevant backups/replicas |
| API/provider client | stdout/stderr/service/container logs, reverse proxy/access/error logs, APM/traces, diagnostics |
| Process/host | crash/core/heap dumps, temp/spool files, session recorders, swap/hibernation and captured diagnostics |
| Browser | console/devtools/HAR/cache/service worker/storage/session restore, extensions/telemetry/recording, clipboard managers |
| Instrument/owner CLI | TTY/session capture, shell history/argv, receipts, replay/export files, temporary/atomic-save leftovers |
| External account | Provider retention/project controls and other project usage: separate owner EU/ZDR/MAM/account evidence |

Disable request/response/header/body collection on Ask AND handoff AND local IPC BEFORE processing data.
Credentials/pairing tokens are also forbidden in logs/receipts. The frozen corpus/fixture library and seeded
source rows are declared approved data destinations, not blanket exclusions for similarly named files/logs.
Allowlist their exact fields/artifact identity so a leaked runtime response cannot hide under a dataset label.

Run before/after scans plus collection-state/interval evidence. Load synthetic canaries and source markers
from the frozen files into scanner memory, never shell arguments. Search existing destinations locally without
copying matched bodies into reports. Persist counts/pass/fail/fixed categories only. Also validate metadata
key/value allowlists; marker absence alone cannot prove absence of paraphrased/novel content. Unknown/unreadable
or newly created destination, enabled body capture, inconsistent scan scope or unaccounted recorder blocks
privacy zero. Scanning a sample or just the application's main log is insufficient.

Use a dedicated measured browser profile with unneeded extensions/telemetry/session persistence disabled.
Avoid clipboard/body pastes, HAR, trace and screenshots during the actual run. Platform preparation must
state its memory/swap/core protections and limits; reference-dropping in JavaScript is not physical erasure.
External provider retention is not locally scanned; name that boundary and require its separate owner proof.
No claim of universal absence beyond the declared measured boundary.

Exact PRIVACY_PROOF payload:
`{environmentId,destinationInventorySha256,scannerManifestSha256,intervalStart,intervalEnd,
coveredDestinationCount,unreadableDestinationCount,newUnclassifiedDestinationCount,
forbiddenContentMatchCount,metadataViolationCount,collectionState:'DISABLED_AS_REQUIRED'|'UNKNOWN',
externalRetentionEvidenceRef,mode:'MEASURED'|'OFFLINE_SIMULATED',countsAsVerifiedZero}`.
ExternalRetentionEvidenceRef is a registered safe ID|null, never an account secret/document body. All counts
checked Dec64. True requires complete approved coverage, actual measured zero violations/unknowns, disabled
collectors and admitted external-retention evidence. OFFLINE_SIMULATED always false. A locally zero scan with
external proof missing remains explicitly incomplete; no software flag can manufacture owner verification.

## Checkpoints proposed for later owner authorization

Each checkpoint stops on an exact source/build/dirty-file manifest with checks and residuals. The author
session is not acceptance. Native Opus5.5/medium implements; clean independent Sol6.1/xhigh and native
Opus5.5/xhigh review the SAME artifact. A bounded repair remains in the corresponding cohesive implementer
session; required reviewers re-review the exact delta/current hash at xhigh. Critical architecture changes
return to fresh Astra/Fable xhigh. No paid calls or automatic activation in any engineering checkpoint.

| Checkpoint | Scope | Stop and dependency |
|---|---|---|
| RS-A | Registration/role confinement, local measured identity channel, owner metadata snapshot/census and pause export | Dual code acceptance before dependent evidence work; private dispatch/financial rules unchanged |
| RS-B | Isolated fixture materializer, source-only clock boundary, DB=fixture verifier | All11x5 PG17 equality and clock/finance isolation; both reviewers accept exact seed mapping |
| RS-C | Manual browser pairing/handoff and private server slot; narrow instrument IPC integration | Browser/PTY/privacy/concurrency proof, sealed instrument/product/assets; no current receipt flag silently upgraded |
| RS-D | Complete process/egress/privacy proof adapters and integrated offline rehearsal/runbook | Actual supported-platform preparation proof or explicit pending limitations; no simulated verified zeros |
| Separate R-EVAL | Only after all engineering/human/account/data/budget/owner gates | Manual200-case run; actual results get separate Sol/Opus acceptance; no implied deployment/customer use |

RS-A and RS-B can be reviewed independently where scope permits, but no integration advances using an
unaccepted dependency. Exactly one checkout writer; isolated worktrees required for parallel implementation.
Checkpoint briefs must name allowed files, migration/role changes, invariants, baseline and required suite.
No migration or package install occurs during architecture drafting.

## Acceptance matrix

| Contract | Required meaningful verification |
|---|---|
| Roles/RLS | Actual PG17 nonsuperuser provisioning; FORCE RLS and composite FKs; table/column/function grants; PUBLIC/default/reprovisioning/SET ROLE/ownership negatives; runtime cannot read owner secrets, mutate registration or invoke owner exports |
| Metadata scope | Wrong workspace/client/actor/admission/login/project/correlation; closed schema/bounds; no foreign detail; full project census detects same-net extra rows; all counters equal original-period sums |
| Atomicity | Two-session reserve/settle/pause/read schedules; consistent single snapshot; deliberate split-read counterexample; missing counter vs true zero; deadline/overflow returns failure, never truncated success |
| Liability | Unknown reserve/settlement commit and restart; no retry/refund; confirmed no-dispatch original private proof vs forged DB record; answer+zero/NO_DISPATCH contradictions; late original-day/month settlement; no false credit under unknown liability |
| Closure | Owner routine/pause-only preserved fields; fence-first lock order; concurrent reserve/revoke/settle; all four exact keys; string vs boolean; signed64 boundary and narrower SQL fence overflow; strict run-wide floors; no-op already-paused; lost commit; pause vs drain distinction |
| Census | Concurrent/hidden/unpaired/duplicate ingress, zero-net settled extra attempt, process restart/disappearance, pending commit/physical owner; single-case and all-project counts; capability pacing includes actual observed events |
| Fixtures | All11x5 independent PG17 expected-facts proof, overflow page, missing/found/resolved focus, candidate link, urgency; atomic switch rollback; foreign DB/extra rows/FK dependency refusal; no finance/audit reset or trigger bypass |
| Clock isolation | Frozen source projection across real days; real credential/policy/price expiry, budget day/month, monotonic deadlines and receipt freshness unchanged; ordinary remote/OFF/MOCK real freshness regression tests; FX08 limitation explicitly reported |
| Browser | Manual checkbox/submit unchanged; disabled pre-GO/second submit; fresh current-generation button; edit/focus/scope/auth/policy/pagehide races; untouched V2/prompt/schema; no automatic pairing consent/Ask/retry |
| Handoff | Exact server publication vs edited same-shape DTO; one-use concurrent claims/replay; raw bytes caps/UTF8/duplicate keys/expiry; nonce theft/crossscope/CSRF/Origin; IPC disconnect/unacked transfer; no raw values survive receipt API |
| Identity | Wrong image/Node/loader/boot/DB instance; replace file/socket after check; unmeasured preload; peer PID reuse/reconnect; forged server hash; unsupported platform remains unverified |
| PTY/local CLI | Real-PTY raw mode before sensitive processing, type-ahead/signals/save failure/cleanup; no body/secret argv/history/stdout; exact local IPC exception, all provider/network APIs still blocked |
| Platform/privacy | Complete destination inventory, effective deny rules and process coverage; scanner failure/unreadable/new sink; canary leak detection without report content; every simulated result countsAsVerifiedZero:false |
| Integration | Context-budget, focused units, actual PG17/RLS, browser E2E/visual where changed, typecheck, migration validation, API/operator build; exact production-copy reproducibility; accepted ancestor regressions appropriate to changed boundaries |

The full required suite belongs to each concrete brief and must be run after changes. A build passing is not
architecture approval; a mock endpoint is not live verification; a signed/hashed report is not proof of its
underlying observation. Record failures, repair rounds, model/effort/effective evidence and scope honestly.

## Gates and evidence identity

Future runtime/tool/build edits invalidate the affected accepted source/build fingerprints. Preserve the
historical seals and frozen norm files; issue NEW manifests/closure verification for affected code, build,
seed mapping, scanners, observer, browser and instrument. Declare the old-to-new delta and compatibility;
never relabel old accepted bytes as the new implementation. At integration bind the exact then-accepted
execution package, including repairs, and re-review its changed scope independently.

All engineering completion still leaves explicit owner decisions: human labels/adjudication; designated
operator; isolated DB/platform; account EU/retention; dedicated key/project; current price/window; synthetic
data; duration/expiry; budget/opening liability/rerun allowance; and actual paid R-EVAL start. This design
provides no activation API and authorizes no charge, account setup, credential provisioning or deployment.

Only a future independently accepted measurement artifact can evaluate live eligibility from those gates.
The current instrument's constant false eligibility/pass flags remain unchanged. Every safety category
needs complete actual evidence; UNKNOWN cannot become zero. Preserve the privacy replay limit and all
unknown-liability no-credit/stronger-failure rules in reports, replay validators and threshold accounting.

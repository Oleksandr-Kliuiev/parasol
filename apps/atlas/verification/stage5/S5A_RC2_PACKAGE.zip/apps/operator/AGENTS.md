# Local operator console (Stage 5)

Contracts: `docs/stage5/` (02 contracts, 03 security/state, 04 architecture). S5-A scope: opt-in serving, memory-only
credential with epochs, fixed GET transport, validated client picker and context validation without rendering context
content. Queue, detail, evidence (S5-B), Ask Atlas and LIVE are separate gates: add no placeholder for them.

| Concern | File |
|---|---|
| Browser copies of accepted patterns/enums/limits (parity: `tests/operator-contracts.test.ts`) | `src/contracts.ts` |
| Fixed GET paths, credential closure, bounded transport | `src/operations.ts`, `src/credential.ts`, `src/transport.ts` |
| Response validators (whole response or fixed code) | `src/validate-core.ts`, `src/validate-clients.ts`, `src/validate-context.ts` |
| Session/scope state machine, epochs, generations | `src/state.ts`, `src/controller.ts` |
| DOM: safe construction, rendering, composition | `src/dom.ts`, `src/view.ts`, `src/main.ts`, `index.html`, `styles.css` |
| Server: flag, asset manifest/loader, Host gate + headers | `apps/api/src/operator/{console,manifest,assets,http}.ts`; build `scripts/operator-build.ts` |

Rules:
- The token exists only inside `createCredentialHolder`. Never add a getter, export, log, storage, cookie, URL, DOM value
  or attribute for it. State (`state.ts`) never holds it. Malformed input is refused, never trimmed.
- Every completion checks credential epoch, scope epoch and panel generation before changing state. Abort is not
  isolation. Any current 401 disconnects; any current 403 clears the scope and refreshes the picker once, no auto-select.
- Validate whole responses before committing; unknown enums/shapes are `RESPONSE_INVALID`, caps `RESPONSE_TOO_LARGE`.
  Ignore undisplayed additive fields. Show fixed codes/messages only, never server bodies.
- Render with `createElement`/`textContent` only; no `innerHTML`, inline script/style, handler attributes, remote
  resources, eval or source maps (`tests/ui/artifact.spec.ts`). New operations need a reviewed contract change.
- Modules listed as shared in `tests/operator-contracts.test.ts` stay DOM-free; only `dom.ts`, `view.ts`, `main.ts` touch
  the document. Browser code is checked by `npm run ui:typecheck` (root typecheck excludes this directory).
- Server middleware stays opt-in (`ATLAS_OPERATOR_UI=1`): disabled API behaviour must not change. Serve assets from the
  in-memory manifest only; no filesystem lookup per request, redirect, listing or fallback.

Checks: `npm test` (units), `npm run ui:typecheck`, `npm run ui:build`, `npm run test:pg` (`tests/pg/operator-http`),
`npm run test:ui` (Playwright, CSP enforced, no trace/video/HAR; visual screenshots only with `ATLAS_UI_VISUAL_DIR`).

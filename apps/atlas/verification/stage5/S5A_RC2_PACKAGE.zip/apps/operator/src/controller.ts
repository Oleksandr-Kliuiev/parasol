// Session/scope state machine with asynchronous isolation (docs/stage5/03_SECURITY_AND_STATE.md). DOM-free.
// Every completion — success, failure, 401, 403 — first checks the captured credential epoch, scope epoch and panel
// generation; a stale completion changes nothing, whether or not its AbortSignal was honoured.
import type { ClientSummary, ContextIdentity } from './contracts.ts';
import type { CredentialHolder } from './credential.ts';
import { getValidated } from './transport.ts';
import type { TransportOptions, TransportResult } from './transport.ts';
import { validateClients } from './validate-clients.ts';
import { validateContext } from './validate-context.ts';
import { disconnectedState, failed, idle, loading, ready } from './state.ts';
import type { ConsoleState, SessionNotice } from './state.ts';
import { LIMITS } from './contracts.ts';

export interface Controller {
  state(): ConsoleState;
  /** Destroys the previous credential and all data, then connects with `raw` if it is a well-formed bearer token. */
  connect(raw: string): void;
  disconnect(notice: SessionNotice): void;
  refreshClients(): void;
  search(text: string): void;
  /** Selects a client of the current validated picker list; anything else is ignored. Never automatic. */
  select(clientId: string): void;
  retryContext(): void;
}

export function createController(holder: CredentialHolder, onChange: (state: ConsoleState) => void, options: TransportOptions = {}): Controller {
  let state: ConsoleState = disconnectedState(null);
  let scopeEpoch = 0;
  let clientsGeneration = 0;
  let contextGeneration = 0;
  /** Workspace established by the first validated context of this credential epoch. */
  let workspaceId: string | null = null;
  let clientsAbort = new AbortController();
  let contextAbort = new AbortController();

  const set = (patch: Partial<ConsoleState>) => { state = { ...state, ...patch }; onChange(state); };

  /** Synchronous scope reset: aborts and invalidates every context request and removes all scope content. */
  function resetScope(): void {
    contextAbort.abort(); contextAbort = new AbortController();
    scopeEpoch += 1; contextGeneration += 1;
  }
  /** Synchronous credential reset: invalidates every request of the previous credential epoch and all of its data. */
  function resetCredentialWork(): void {
    clientsAbort.abort(); clientsAbort = new AbortController();
    clientsGeneration += 1; resetScope(); workspaceId = null;
  }

  function disconnect(notice: SessionNotice): void {
    resetCredentialWork();
    holder.clear();
    state = disconnectedState(notice);
    onChange(state);
  }

  function loadClients(): void {
    if (!holder.connected()) return;
    clientsAbort.abort(); clientsAbort = new AbortController();
    const credential = holder.epoch();
    const generation = ++clientsGeneration;
    set({ clients: loading() });
    void getValidated(holder, { kind: 'clients' }, clientsAbort.signal, validateClients, options).then(result => {
      if (credential !== holder.epoch() || generation !== clientsGeneration) return;
      if (!result.ok && result.code === 'UNAUTHORIZED') return disconnect('UNAUTHORIZED');
      if (!result.ok && result.code === 'FORBIDDEN') {
        // A current 403 clears the whole scope. The picker itself was refused, so there is no further refresh (no loop).
        resetScope();
        return set({ selection: null, context: idle(), clients: failed('FORBIDDEN') });
      }
      if (!result.ok) return set({ clients: failed(result.code) });
      set({ session: 'READY', clients: ready(result.value) });
    });
  }

  function onContext(result: TransportResult<ContextIdentity>): void {
    if (!result.ok && result.code === 'UNAUTHORIZED') return disconnect('UNAUTHORIZED');
    if (!result.ok && result.code === 'FORBIDDEN') {
      // Every current 403 is a full scope reset plus exactly one picker refresh with the same credential; no auto-select.
      resetScope();
      set({ selection: null, context: idle(), scopeDenied: true });
      return loadClients();
    }
    if (!result.ok) return set({ context: failed(result.code) });
    workspaceId ??= result.value.workspaceId;
    set({ context: ready(result.value) });
  }

  function loadContext(): void {
    const selection = state.selection;
    if (!selection || !holder.connected()) return;
    contextAbort.abort(); contextAbort = new AbortController();
    const credential = holder.epoch();
    const scope = scopeEpoch;
    const generation = ++contextGeneration;
    set({ context: loading() });
    const validate = (value: unknown) => validateContext(value, selection.clientId, workspaceId);
    void getValidated(holder, { kind: 'overview', clientId: selection.clientId }, contextAbort.signal, validate, options).then(result => {
      if (credential !== holder.epoch() || scope !== scopeEpoch || generation !== contextGeneration) return;
      onContext(result);
    });
  }

  return Object.freeze({
    state: () => state,
    connect(raw: string): void {
      resetCredentialWork();
      if (!holder.replace(raw)) { state = disconnectedState('TOKEN_FORMAT'); onChange(state); return; }
      state = { ...disconnectedState(null), session: 'CONNECTING' };
      loadClients();
    },
    disconnect,
    refreshClients(): void { if (state.session !== 'DISCONNECTED') loadClients(); },
    search(text: string): void { set({ search: text.slice(0, LIMITS.searchLength) }); },
    select(clientId: string): void {
      const clients: readonly ClientSummary[] = state.clients.data ?? [];
      const client = clients.find(c => c.id === clientId);
      if (state.session !== 'READY' || !client) return;
      resetScope();
      state = { ...state, selection: { clientId: client.id, name: client.name }, scopeDenied: false, context: idle() };
      loadContext();
    },
    retryContext(): void { if (state.selection && state.context.status === 'ERROR') loadContext(); }
  });
}

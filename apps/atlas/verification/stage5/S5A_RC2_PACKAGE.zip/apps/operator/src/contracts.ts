// Browser projection of the accepted Stage 1 read contracts (docs/stage5/02_CONTRACTS.md). DOM-free and import-free, so
// Node parity tests (tests/operator-contracts.test.ts) compare these copies with packages/core and packages/auth.
// Versioned with the console: a change to an accepted contract must update this file and its parity test together.

/** packages/auth/token.ts BEARER_TOKEN_PATTERN: RFC 6750 b64token, 20..256 characters. Input is never trimmed or normalized. */
export const BEARER_TOKEN_PATTERN = /^[A-Za-z0-9\-._~+/]{20,256}={0,2}$/;
/** packages/graph/scope-context.ts SCOPE_ID_PATTERN: workspace, client and connection identifiers. */
export const SCOPE_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/;
/** packages/graph/mapping.ts EXTERNAL_ID_PATTERN: source identifiers. */
export const EXTERNAL_ID_PATTERN = /^[\x21-\x7e]{1,128}$/;
/** apps/api/src/http-boundary.ts observation cursor format (opaque). */
export const CURSOR_PATTERN = /^[A-Za-z0-9_-]{1,400}$/;

export const SYSTEMS = ['atera', 'huntress', 'microsoft365', 'poweroffice'] as const;
/** Systems ClientContextV1 can carry: Microsoft 365 rows are excluded from the Stage 1 projection. */
export const CONTEXT_SYSTEMS = ['atera', 'huntress', 'poweroffice'] as const;
/** ResourceType without the internal m365_* types, which ClientContextV1 never exposes. */
export const CONTEXT_RESOURCE_TYPES = ['customer', 'organization', 'agent', 'contact', 'alert', 'ticket', 'incident'] as const;
export const SEVERITIES = ['INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const;
export const ROUTES = ['MONITOR', 'INVESTIGATE', 'HUMAN_REVIEW'] as const;
export const PRIORITIES = ['NORMAL', 'URGENT'] as const;
export const EVENT_KINDS = ['DISK_CAPACITY', 'SECURITY_INCIDENT'] as const;
export const DOMAINS = ['OPERATIONS', 'SECURITY'] as const;
export const ENTITY_KINDS = ['PERSON', 'DEVICE'] as const;
export const PROVIDERS = ['fixture', 'openai', 'rules'] as const;
export const OBSERVATION_STATUSES = ['OPEN', 'ACKNOWLEDGED', 'RESOLVED', 'SUPPRESSED'] as const;
export const ACTIVE_OBSERVATION_STATUSES = ['OPEN', 'ACKNOWLEDGED'] as const;
export const RESOURCE_STATUSES = ['OK', 'STALE', 'ERROR', 'MISSING', 'FIXTURE'] as const;
export const CONTEXT_MODES = ['fixture', 'db'] as const;
export const COMPLETENESS = ['COMPLETE_FIXTURE', 'PARTIAL', 'COMPLETE'] as const;

export type System = typeof SYSTEMS[number];
export type ContextMode = typeof CONTEXT_MODES[number];
export type Completeness = typeof COMPLETENESS[number];

/** Response and display bounds (docs/stage5/02_CONTRACTS.md, Runtime validation and bounds). */
export const LIMITS = Object.freeze({
  responseBytes: 4 * 1024 * 1024,
  requestDeadlineMs: 10_000,
  clients: 10_000,
  pickerRows: 250,
  queueItems: 100,
  people: 1000,
  devices: 1000,
  links: 1000,
  resources: 100,
  resourceItems: 1000,
  displayCodePoints: 4000,
  reasonCodes: 100,
  searchLength: 128
});

/** Fixed, bounded failure codes. The only diagnostic text the console ever shows; never a server body or exception message. */
export const FAILURE_CODES = ['UNAUTHORIZED', 'FORBIDDEN', 'NETWORK', 'TIMEOUT', 'HTTP_ERROR', 'RESPONSE_INVALID', 'RESPONSE_TOO_LARGE'] as const;
export type FailureCode = typeof FAILURE_CODES[number];

export interface ClientSummary { readonly id: string; readonly name: string }
/** The validated identity of a fetched ClientContextV1. Its content is validated in full but not retained or rendered in S5-A. */
export interface ContextIdentity {
  readonly workspaceId: string; readonly clientId: string; readonly clientName: string;
  readonly mode: ContextMode; readonly completeness: Completeness; readonly generatedAt: string;
}

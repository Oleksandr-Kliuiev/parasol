// Minimal safe DOM construction: elements, fixed class names and textContent only. No innerHTML, attribute values from
// data, URLs or inline styles; callers pass only literal class names and validated or display-shortened text.

export function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string | null, ...children: (Node | string)[]): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  for (const child of children) node.append(typeof child === 'string' ? document.createTextNode(child) : child);
  return node;
}

export function byId<T extends HTMLElement>(id: string, type: { new (): T }): T {
  const node = document.getElementById(id);
  if (!(node instanceof type)) throw new Error('CONSOLE_MARKUP_MISSING');
  return node;
}

/** Text shortened for display, with a visible marker and a screen-reader note. */
export function shortenedText(text: string, shortened: boolean): (Node | string)[] {
  return shortened ? [text, el('span', 'shortened', '…'), el('span', 'visually-hidden', ' (shortened)')] : [text];
}

export function button(label: string, className: string, onClick: () => void): HTMLButtonElement {
  const node = el('button', className, label);
  node.type = 'button';
  node.addEventListener('click', onClick);
  return node;
}

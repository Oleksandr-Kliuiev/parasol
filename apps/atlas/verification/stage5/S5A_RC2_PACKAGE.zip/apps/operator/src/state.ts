// Console view state (docs/stage5/03_SECURITY_AND_STATE.md, State machine). DOM-free and token-free: nothing here can
// hold or reveal the credential. Only validated data is ever placed in this state.
import type { ClientSummary, ContextIdentity, FailureCode } from './contracts.ts';

export type SessionState = 'DISCONNECTED' | 'CONNECTING' | 'READY';
/** Fixed reasons for the disconnected screen. */
export type SessionNotice = 'TOKEN_FORMAT' | 'UNAUTHORIZED' | 'DISCONNECTED' | 'PAGE_HIDDEN' | 'ORIGIN_REFUSED';
export type PanelStatus = 'IDLE' | 'LOADING' | 'READY' | 'ERROR';

export interface Panel<T> { readonly status: PanelStatus; readonly data: T | null; readonly error: FailureCode | null }
export interface Selection { readonly clientId: string; readonly name: string }

export interface ConsoleState {
  readonly session: SessionState;
  readonly notice: SessionNotice | null;
  readonly clients: Panel<readonly ClientSummary[]>;
  /** Set after a 403 cleared the selected scope and refreshed the picker once. */
  readonly scopeDenied: boolean;
  readonly search: string;
  readonly selection: Selection | null;
  /** S5-A validates the fetched context in full but keeps only its identity; context content is not rendered yet. */
  readonly context: Panel<ContextIdentity>;
}

export const idle = <T>(): Panel<T> => ({ status: 'IDLE', data: null, error: null });
export const loading = <T>(): Panel<T> => ({ status: 'LOADING', data: null, error: null });
export const ready = <T>(data: T): Panel<T> => ({ status: 'READY', data, error: null });
export const failed = <T>(error: FailureCode): Panel<T> => ({ status: 'ERROR', data: null, error });

export function disconnectedState(notice: SessionNotice | null): ConsoleState {
  return { session: 'DISCONNECTED', notice, clients: idle(), scopeDenied: false, search: '', selection: null, context: idle() };
}

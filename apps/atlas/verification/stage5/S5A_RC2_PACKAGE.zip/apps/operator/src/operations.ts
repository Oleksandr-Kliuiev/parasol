// The only HTTP operations of the S5-A console: fixed GET templates, relative to this origin. DOM-free.
// No caller-controlled URL, method, header or tool name exists; IDs are validated and percent-encoded into fixed paths.
import { SCOPE_ID_PATTERN } from './contracts.ts';

export type GetOperation =
  | { readonly kind: 'clients' }
  | { readonly kind: 'overview'; readonly clientId: string };

/** Origin-relative path of an operation; null when an ID is not a well-formed scope identifier (no request is made). */
export function operationPath(operation: GetOperation): string | null {
  switch (operation.kind) {
    case 'clients': return '/clients';
    case 'overview': return SCOPE_ID_PATTERN.test(operation.clientId) ? `/clients/${encodeURIComponent(operation.clientId)}/overview` : null;
    default: return null;
  }
}

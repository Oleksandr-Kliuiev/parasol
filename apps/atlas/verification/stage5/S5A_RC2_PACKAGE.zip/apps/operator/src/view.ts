// Rendering of ConsoleState into the static skeleton of index.html. Every dynamic node is built with createElement and
// textContent (dom.ts); state never contains the credential, so nothing rendered here can reveal it.
import { FAILURE_TEXT, MODE_LABEL, NOTICE_TEXT, SCOPE_DENIED_TEXT } from './messages.ts';
import { byId, button, el, shortenedText } from './dom.ts';
import { clientLabel, pickerView } from './validate-clients.ts';
import { displayText } from './validate-core.ts';
import type { Controller } from './controller.ts';
import type { ConsoleState } from './state.ts';

export interface View { render(state: ConsoleState): void }

export function createView(controller: Controller): View {
  const ui = {
    status: byId('session-status', HTMLElement), modeBadge: byId('mode-badge', HTMLElement), disconnect: byId('disconnect', HTMLButtonElement),
    clientsPanel: byId('clients-panel', HTMLElement), search: byId('client-search', HTMLInputElement), refresh: byId('refresh-clients', HTMLButtonElement),
    clientsStatus: byId('clients-status', HTMLElement), clientList: byId('client-list', HTMLUListElement),
    connectPanel: byId('connect-panel', HTMLElement), token: byId('token', HTMLInputElement), connectNotice: byId('connect-notice', HTMLElement),
    scopePanel: byId('scope-panel', HTMLElement)
  };
  let previous: ConsoleState | null = null;
  /** Rendered picker rows by client ID, so keyboard focus survives a re-render without any data attribute. */
  const rows = new Map<string, HTMLButtonElement>();

  function renderHeader(state: ConsoleState): void {
    ui.status.textContent = state.session === 'READY' ? 'Connected' : state.session === 'CONNECTING' ? 'Connecting…' : 'Not connected';
    ui.status.className = `badge badge-session badge-${state.session.toLowerCase()}`;
    const mode = state.context.data?.mode;
    ui.modeBadge.hidden = !mode;
    ui.modeBadge.textContent = mode ? MODE_LABEL[mode] : '';
    ui.disconnect.hidden = state.session === 'DISCONNECTED';
  }

  function renderClients(state: ConsoleState): void {
    let focusedId: string | null = null;
    for (const [id, node] of rows) if (node === document.activeElement) focusedId = id;
    rows.clear();
    ui.clientList.replaceChildren();
    ui.clientList.setAttribute('aria-busy', String(state.clients.status === 'LOADING'));
    ui.refresh.disabled = state.clients.status === 'LOADING';
    if (state.search === '' && ui.search.value !== '') ui.search.value = '';
    const status: (Node | string)[] = [];
    if (state.clients.status === 'LOADING') status.push('Loading clients…');
    else if (state.clients.status === 'ERROR' && state.clients.error) {
      status.push(el('span', 'error-text', FAILURE_TEXT[state.clients.error]), ' ', el('code', null, state.clients.error));
    } else if (state.clients.data) {
      const view = pickerView(state.clients.data, state.search);
      if (view.total === 0) status.push('No clients are available to this token.');
      else if (view.limited) status.push(`Showing the first ${view.rows.length} of ${view.matching} matching clients (of ${view.total}). Refine the search to reach the others.`);
      else status.push(state.search === '' ? `${view.total} client${view.total === 1 ? '' : 's'}.` : `${view.matching} of ${view.total} clients match.`);
      for (const client of view.rows) {
        const label = clientLabel(client);
        const node = button('', 'client', () => controller.select(client.id));
        node.replaceChildren(el('span', 'client-name', ...shortenedText(label.text, label.shortened)), el('span', 'client-id', client.id));
        rows.set(client.id, node);
        const selected = state.selection?.clientId === client.id;
        if (selected) node.setAttribute('aria-current', 'true');
        ui.clientList.append(el('li', null, node));
        if (focusedId === client.id) node.focus();
      }
    }
    ui.clientsStatus.replaceChildren(...status);
  }

  function renderScope(state: ConsoleState): void {
    const body: Node[] = [];
    const { selection, context } = state;
    if (!selection) {
      body.push(el('h1', null, 'No client selected'));
      if (state.scopeDenied) body.push(el('p', 'notice notice-warning', SCOPE_DENIED_TEXT));
      body.push(el('p', 'muted', 'Choose a client from the list. A client is never selected automatically.'));
    } else {
      const name = displayText(context.data?.clientName ?? selection.name);
      body.push(el('h1', null, ...shortenedText(name.text || selection.clientId, name.shortened)));
      const meta = el('dl', 'meta', el('dt', null, 'Client ID'), el('dd', null, el('code', null, selection.clientId)));
      if (context.data) meta.append(el('dt', null, 'Context mode'), el('dd', null, MODE_LABEL[context.data.mode]));
      body.push(meta);
      if (context.status === 'LOADING') body.push(el('p', 'panel-status', 'Loading and validating the client context…'));
      else if (context.status === 'ERROR' && context.error) {
        body.push(el('p', 'notice notice-error', FAILURE_TEXT[context.error], ' ', el('code', null, context.error)),
          button('Retry', 'btn btn-secondary', () => controller.retryContext()));
      } else if (context.data) {
        const generated = displayText(context.data.generatedAt, 64).text;
        body.push(el('p', 'notice notice-ok', `Client context received and validated (generated ${generated}).`));
      }
    }
    const panel = ui.scopePanel;
    panel.setAttribute('aria-busy', String(context.status === 'LOADING'));
    panel.replaceChildren(...body);
  }

  return {
    render(state: ConsoleState): void {
      const connected = state.session !== 'DISCONNECTED';
      renderHeader(state);
      ui.connectPanel.hidden = connected;
      ui.clientsPanel.hidden = !connected;
      ui.scopePanel.hidden = !connected;
      ui.connectNotice.textContent = state.notice ? NOTICE_TEXT[state.notice] : '';
      if (!connected) { rows.clear(); ui.clientList.replaceChildren(); ui.clientsStatus.replaceChildren(); ui.scopePanel.replaceChildren(); ui.search.value = ''; }
      else {
        // Each region is rebuilt only when its own state changed, so live regions are not re-announced on every keystroke.
        const fresh = !previous || previous.session === 'DISCONNECTED';
        if (fresh || previous!.clients !== state.clients || previous!.search !== state.search || previous!.selection !== state.selection) renderClients(state);
        if (fresh || previous!.selection !== state.selection || previous!.context !== state.context || previous!.scopeDenied !== state.scopeDenied) renderScope(state);
      }
      if (previous && previous.session !== state.session) {
        if (state.session === 'DISCONNECTED') ui.token.focus();
        else if (state.session === 'READY' && document.activeElement === document.body) ui.search.focus();
      }
      previous = state;
    }
  };
}

// Fixed user-facing text. DOM-free. No server text, body or exception message is ever shown; only these strings and
// the fixed failure code. Mode labels describe the actual contract value and never imply LIVE or production data.
import type { ContextMode, FailureCode } from './contracts.ts';
import type { SessionNotice } from './state.ts';

export const NOTICE_TEXT: Record<SessionNotice, string> = {
  TOKEN_FORMAT: 'That token is not in the accepted format. Nothing was sent.',
  UNAUTHORIZED: 'The API did not accept the token. You are disconnected and all loaded data was cleared.',
  DISCONNECTED: 'Disconnected. The token and all loaded data were cleared from this page. The token itself is not revoked.',
  PAGE_HIDDEN: 'The page was left or hidden, so the session was cleared. Enter the token again to continue.',
  ORIGIN_REFUSED: 'Token entry is only available at http://127.0.0.1:<port>/operator/ served by the local Atlas API.'
};

export const FAILURE_TEXT: Record<FailureCode, string> = {
  UNAUTHORIZED: 'The API did not accept the token.',
  FORBIDDEN: 'The API refused access.',
  NETWORK: 'The local API could not be reached or the request was interrupted.',
  TIMEOUT: 'The request did not complete within 10 seconds. Nothing was retried.',
  HTTP_ERROR: 'The API answered with an error.',
  RESPONSE_INVALID: 'The response did not match the expected contract and was discarded.',
  RESPONSE_TOO_LARGE: 'The response exceeded this console\'s size limits and was discarded.'
};

export const MODE_LABEL: Record<ContextMode, string> = {
  fixture: 'Synthetic fixture context',
  db: 'Database-backed context'
};

export const SCOPE_DENIED_TEXT = 'The API refused access to the previously selected client. Its data was cleared and the client list was reloaded once.';

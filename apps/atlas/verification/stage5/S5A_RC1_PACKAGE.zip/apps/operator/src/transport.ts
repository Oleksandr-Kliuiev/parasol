// Bounded request/response handling (docs/stage5/02_CONTRACTS.md). DOM-free: fetch, streams and timers only.
// One original deadline covers the request, the incremental body read, decoding, JSON parsing and validation. The result
// always settles locally, even when the underlying fetch ignores its AbortSignal. No retry; no body is ever echoed.
import { LIMITS } from './contracts.ts';
import type { FailureCode } from './contracts.ts';
import type { CredentialHolder } from './credential.ts';
import type { GetOperation } from './operations.ts';
import { Invalid } from './validate-core.ts';

export type TransportResult<T> = { readonly ok: true; readonly value: T } | { readonly ok: false; readonly code: FailureCode };
export interface TransportOptions { readonly deadlineMs?: number; readonly maxBytes?: number }

const failure = <T>(code: FailureCode): TransportResult<T> => ({ ok: false, code });

/** Reads at most maxBytes, cancelling the stream as soon as the cap is crossed. */
async function readCapped(response: Response, maxBytes: number): Promise<Uint8Array | null> {
  const declared = response.headers.get('content-length');
  if (declared !== null && /^\d+$/.test(declared) && Number(declared) > maxBytes) { await response.body?.cancel().catch(() => undefined); return null; }
  if (!response.body) return new Uint8Array(0);
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) { await reader.cancel().catch(() => undefined); return null; }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return bytes;
}

async function exchange<T>(holder: CredentialHolder, operation: GetOperation, signal: AbortSignal, maxBytes: number,
  validate: (value: unknown) => T): Promise<TransportResult<T>> {
  let response: Response;
  try { response = await holder.get(operation, signal); } catch { return failure('NETWORK'); }
  if (response.status !== 200) {
    await response.body?.cancel().catch(() => undefined);
    return failure(response.status === 401 ? 'UNAUTHORIZED' : response.status === 403 ? 'FORBIDDEN' : 'HTTP_ERROR');
  }
  if (response.redirected || !/^application\/json(;|$)/i.test(response.headers.get('content-type') ?? '')) {
    await response.body?.cancel().catch(() => undefined);
    return failure('RESPONSE_INVALID');
  }
  let bytes: Uint8Array | null;
  try { bytes = await readCapped(response, maxBytes); } catch { return failure('NETWORK'); }
  if (bytes === null) return failure('RESPONSE_TOO_LARGE');
  let parsed: unknown;
  try { parsed = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { return failure('RESPONSE_INVALID'); }
  try { return { ok: true, value: validate(parsed) }; }
  catch (error) { return failure(error instanceof Invalid && error.tooLarge ? 'RESPONSE_TOO_LARGE' : 'RESPONSE_INVALID'); }
}

/**
 * GET one fixed operation and validate the JSON body before returning it. `signal` is the caller's scope/panel abort.
 * The deadline aborts the browser request and settles TIMEOUT; it does not claim server-side cancellation.
 */
export function getValidated<T>(holder: CredentialHolder, operation: GetOperation, signal: AbortSignal, validate: (value: unknown) => T,
  options: TransportOptions = {}): Promise<TransportResult<T>> {
  const deadlineMs = options.deadlineMs ?? LIMITS.requestDeadlineMs;
  const maxBytes = options.maxBytes ?? LIMITS.responseBytes;
  const local = new AbortController();
  const combined = AbortSignal.any([signal, local.signal]);
  let timer: ReturnType<typeof setTimeout> | undefined;
  let onAbort: (() => void) | undefined;
  const deadline = new Promise<TransportResult<T>>(resolve => {
    timer = setTimeout(() => { local.abort(); resolve(failure('TIMEOUT')); }, deadlineMs);
  });
  const aborted = new Promise<TransportResult<T>>(resolve => {
    onAbort = () => resolve(failure('NETWORK'));
    if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true });
  });
  return Promise.race([exchange(holder, operation, combined, maxBytes, validate), deadline, aborted]).finally(() => {
    clearTimeout(timer);
    if (onAbort) signal.removeEventListener('abort', onAbort);
    local.abort();
  });
}

// GET /clients/:id/overview → ClientContextV1 (packages/core/contracts.ts, packages/graph/context-mapper.ts). DOM-free.
// The whole context is validated before anything is committed: identity, every nested graph row's scope, confirmed-only
// links, enums, times, array caps and the reviewed resource item shapes, including content S5-A does not render.
import {
  ACTIVE_OBSERVATION_STATUSES, COMPLETENESS, CONTEXT_MODES, CONTEXT_RESOURCE_TYPES, CONTEXT_SYSTEMS, CURSOR_PATTERN, DOMAINS, ENTITY_KINDS,
  EVENT_KINDS, LIMITS, PRIORITIES, PROVIDERS, RESOURCE_STATUSES, ROUTES, SCOPE_ID_PATTERN, SEVERITIES, SYSTEMS
} from './contracts.ts';
import type { ContextIdentity, ContextMode } from './contracts.ts';
import {
  array, boolean, count, fail, identifier, matching, nullableIdentifier, nullableOneOf, nullableString, nullableTime, object, oneOf, string,
  time, unitInterval
} from './validate-core.ts';
import type { Json } from './validate-core.ts';

interface Scope { workspaceId: string; clientId: string }
const inScope = (row: Json, scope: Scope): void => {
  if (row.workspaceId !== scope.workspaceId || row.clientId !== scope.clientId) fail();
};

function person(raw: unknown, scope: Scope): void {
  const row = object(raw); inScope(row, scope);
  identifier(row.id); string(row.displayName); nullableString(row.email);
}
function device(raw: unknown, scope: Scope): void {
  const row = object(raw); inScope(row, scope);
  identifier(row.id); string(row.hostname); nullableIdentifier(row.personId);
}
/** Only CONFIRMED links are part of the context; a candidate, rejected or quarantined link is a contract violation. */
function link(raw: unknown, scope: Scope): void {
  const row = object(raw); inScope(row, scope);
  matching(row.connectionId, SCOPE_ID_PATTERN); oneOf(row.system, CONTEXT_SYSTEMS); oneOf(row.resourceType, CONTEXT_RESOURCE_TYPES);
  identifier(row.externalId); identifier(row.entityId); oneOf(row.entityKind, ENTITY_KINDS);
  if (row.status !== 'CONFIRMED') fail();
}

/**
 * ObservationSummary of the context page: active statuses only (the context lists OPEN and ACKNOWLEDGED). Source
 * references (connectionId, externalEventId) are typed text here; their request formats are checked before any evidence
 * request (S5-B), where an invalid reference is a visible evidence-unavailable state, not a context failure.
 */
function observation(raw: unknown, scope: Scope): void {
  const row = object(raw); inScope(row, scope);
  identifier(row.id); identifier(row.eventKey); oneOf(row.source, SYSTEMS); string(row.connectionId);
  oneOf(row.resourceType, CONTEXT_RESOURCE_TYPES); string(row.externalEventId); string(row.revision);
  nullableIdentifier(row.entityId); nullableIdentifier(row.decisionRunId); oneOf(row.kind, EVENT_KINDS); oneOf(row.domain, DOMAINS);
  oneOf(row.severity, SEVERITIES); oneOf(row.priority, PRIORITIES); oneOf(row.route, ROUTES); unitInterval(row.confidence);
  oneOf(row.provider, PROVIDERS);
  for (const code of array(row.reasonCodes, LIMITS.reasonCodes)) string(code);
  nullableString(row.conflictOfEventKey); oneOf(row.status, ACTIVE_OBSERVATION_STATUSES);
  nullableTime(row.acknowledgedAt); nullableTime(row.resolvedAt); nullableIdentifier(row.supersededById);
  string(row.summary); time(row.occurredAt); time(row.createdAt); time(row.updatedAt);
}
function observationPage(raw: unknown, scope: Scope): void {
  const page = object(raw);
  const items = array(page.items, LIMITS.queueItems);
  for (const item of items) observation(item, scope);
  const counts = object(page.counts);
  for (const severity of SEVERITIES) count(counts[severity]);
  const total = count(page.total);
  if (total < items.length) fail();
  boolean(page.truncated);
  if (page.nextCursor !== null) matching(page.nextCursor, CURSOR_PATTERN);
}

interface ResourceKey { source: string; resourceType: string; connectionId: string | null }
/** DB SnapshotItem. `status` is the source's own free text (bounded by the response cap), not an Atlas enum. */
function snapshotItem(raw: unknown, view: ResourceKey): void {
  const row = object(raw);
  if (row.source !== view.source || row.resourceType !== view.resourceType) fail();
  identifier(row.externalId); string(row.title); string(row.status); nullableOneOf(row.severity, SEVERITIES); nullableString(row.priority);
  if (row.device !== null) { const ref = object(row.device); oneOf(ref.resourceType, CONTEXT_RESOURCE_TYPES); identifier(ref.externalId); }
  nullableTime(row.occurredAt); nullableTime(row.updatedAt);
}
/** FIXTURE normalized alert/incident: its scope and source tuple must be the resource's. facts/externalDevice are not read. */
function fixtureEvent(raw: unknown, view: ResourceKey, scope: Scope): void {
  const row = object(raw); inScope(row, scope);
  if (row.source !== view.source || row.connectionId !== view.connectionId || row.resourceType !== view.resourceType) fail();
  identifier(row.externalEventId); string(row.revision); oneOf(row.kind, EVENT_KINDS); string(row.summary);
  oneOf(row.sourceSeverity, SEVERITIES); time(row.occurredAt);
}
/** FIXTURE ticket: id/title/status only. */
function fixtureTicket(raw: unknown): void {
  const row = object(raw);
  identifier(row.id); string(row.title); string(row.status);
}

/**
 * ResourceView. Items are present exactly for OK/STALE/FIXTURE; FIXTURE status belongs to fixture mode only and the other
 * statuses to db mode, so a synthetic resource can never be presented as a database read or the reverse.
 */
function resource(raw: unknown, mode: ContextMode, scope: Scope): void {
  const row = object(raw);
  const source = oneOf(row.source, CONTEXT_SYSTEMS);
  const resourceType = oneOf(row.resourceType, CONTEXT_RESOURCE_TYPES);
  const connectionId = row.connectionId === null ? null : matching(row.connectionId, SCOPE_ID_PATTERN);
  const status = oneOf(row.status, RESOURCE_STATUSES);
  nullableTime(row.asOf); nullableTime(row.lastSuccessAt); nullableString(row.safeErrorCode); boolean(row.truncated);
  if ((status === 'FIXTURE') !== (mode === 'fixture')) fail();
  const withItems = status === 'OK' || status === 'STALE' || status === 'FIXTURE';
  if (!withItems) { if (row.items !== null) fail(); return; }
  const items = array(row.items, LIMITS.resourceItems);
  const key = { source, resourceType, connectionId };
  for (const item of items) {
    if (mode === 'db') snapshotItem(item, key);
    else if ((source === 'atera' && resourceType === 'alert') || (source === 'huntress' && resourceType === 'incident')) fixtureEvent(item, key, scope);
    else if (source === 'atera' && resourceType === 'ticket') fixtureTicket(item);
    else fail();
  }
}

/**
 * Validates a ClientContextV1 for the requested client. `workspaceId` is the workspace an earlier context established for
 * this credential epoch (null for the first one); a context of another workspace or client is RESPONSE_INVALID.
 */
export function validateContext(value: unknown, requestedClientId: string, workspaceId: string | null): ContextIdentity {
  const ctx = object(value);
  if (ctx.contractVersion !== 'ClientContextV1') fail();
  const scope = { workspaceId: matching(ctx.workspaceId, SCOPE_ID_PATTERN), clientId: matching(ctx.clientId, SCOPE_ID_PATTERN) };
  if (scope.clientId !== requestedClientId || (workspaceId !== null && scope.workspaceId !== workspaceId)) fail();
  const mode = oneOf(ctx.mode, CONTEXT_MODES);
  const clientName = string(ctx.clientName);
  const generatedAt = time(ctx.generatedAt);
  const completeness = oneOf(ctx.completeness, COMPLETENESS);
  if ((completeness === 'COMPLETE_FIXTURE') !== (mode === 'fixture')) fail();
  for (const row of array(ctx.people, LIMITS.people)) person(row, scope);
  for (const row of array(ctx.devices, LIMITS.devices)) device(row, scope);
  for (const row of array(ctx.links, LIMITS.links)) link(row, scope);
  observationPage(ctx.observations, scope);
  for (const row of array(ctx.resources, LIMITS.resources)) resource(row, mode, scope);
  return Object.freeze({ workspaceId: scope.workspaceId, clientId: scope.clientId, clientName, mode, completeness, generatedAt });
}

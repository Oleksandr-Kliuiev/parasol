import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCredentialHolder } from '../apps/operator/src/credential.ts';
import type { FetchLike } from '../apps/operator/src/credential.ts';
import { getValidated } from '../apps/operator/src/transport.ts';
import { validateClients } from '../apps/operator/src/validate-clients.ts';

// S5-A credential holder and bounded transport (A3/A5/A6) with a recorded fake fetch. Browser behaviour over real
// network/DOM is covered by tests/ui; these isolate the exact request shape, caps and deadline semantics.
const TOKEN = 'synthetic-console-token-0123456789';

interface Call { path: string; init: RequestInit }
function recorder(respond: (call: Call) => Promise<Response> | Response) {
  const calls: Call[] = [];
  const fetchImpl: FetchLike = async (path, init) => { const call = { path, init }; calls.push(call); return respond(call); };
  return { calls, fetchImpl };
}
const json = (body: unknown, init: ResponseInit = {}) => new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json; charset=utf-8' }, ...init });
const never = () => new AbortController().signal;

test('holder: no getter or serialization exposes the token; malformed input is refused without a request', async () => {
  const { calls, fetchImpl } = recorder(() => json([]));
  const holder = createCredentialHolder(fetchImpl);
  assert.ok(Object.isFrozen(holder));
  assert.deepEqual(Object.keys(holder).sort(), ['clear', 'connected', 'epoch', 'get', 'replace']);
  for (const bad of [` ${TOKEN}`, `${TOKEN} `, `${TOKEN}\n`, 'short', `Bearer ${TOKEN}`, `${TOKEN}!`, '']) {
    assert.equal(holder.replace(bad), false); assert.equal(holder.connected(), false);
  }
  const before = holder.epoch();
  assert.equal(holder.replace(TOKEN), true);
  assert.ok(holder.epoch() > before);
  assert.ok(!JSON.stringify(holder).includes(TOKEN) && !String(holder).includes(TOKEN) && !Object.values(holder).some(v => String(v).includes(TOKEN)));
  await holder.get({ kind: 'clients' }, never());
  assert.equal(calls.length, 1);
  const { init, path } = calls[0]!;
  assert.equal(path, '/clients');
  assert.deepEqual([init.method, init.credentials, init.redirect, init.cache, init.mode, init.referrerPolicy], ['GET', 'omit', 'error', 'no-store', 'same-origin', 'no-referrer']);
  assert.equal(new Headers(init.headers).get('authorization'), `Bearer ${TOKEN}`);
  assert.equal(init.body, undefined);
  const epoch = holder.epoch();
  holder.clear();
  assert.ok(holder.epoch() > epoch); assert.equal(holder.connected(), false);
  await assert.rejects(holder.get({ kind: 'clients' }, never()));
  assert.equal(holder.replace(TOKEN), true);
  await assert.rejects(holder.get({ kind: 'overview', clientId: '../audit' }, never()));
  assert.equal(calls.length, 1, 'no request without a credential or for a malformed ID');
});

test('transport maps statuses to fixed codes without reading or echoing error bodies', async () => {
  const cases: [Response, string][] = [
    [new Response('<h1>secret detail</h1>', { status: 401 }), 'UNAUTHORIZED'], [new Response('{}', { status: 403 }), 'FORBIDDEN'],
    [new Response('boom', { status: 500 }), 'HTTP_ERROR'], [new Response('', { status: 302, headers: { location: '/x' } }), 'HTTP_ERROR'],
    [new Response('[]', { status: 200, headers: { 'content-type': 'text/html' } }), 'RESPONSE_INVALID'],
    [new Response('not json', { status: 200, headers: { 'content-type': 'application/json' } }), 'RESPONSE_INVALID'],
    [new Response(new Uint8Array([0x5b, 0xff, 0x5d]), { status: 200, headers: { 'content-type': 'application/json' } }), 'RESPONSE_INVALID'],
    [json([{ id: 'bad id', name: 'x' }]), 'RESPONSE_INVALID'], [json([{ id: 'a', name: 'A' }]), 'OK']
  ];
  for (const [response, expected] of cases) {
    const holder = createCredentialHolder(async () => response);
    holder.replace(TOKEN);
    const result = await getValidated(holder, { kind: 'clients' }, never(), validateClients);
    assert.equal(result.ok ? 'OK' : result.code, expected);
    assert.ok(!JSON.stringify(result).includes('secret detail'));
  }
  const rejected = createCredentialHolder(async () => { throw new TypeError('redirect mode is error'); });
  rejected.replace(TOKEN);
  assert.deepEqual(await getValidated(rejected, { kind: 'clients' }, never(), validateClients), { ok: false, code: 'NETWORK' });
});

test('response cap: declared or streamed bodies over the cap are cancelled and RESPONSE_TOO_LARGE', async () => {
  const declared = createCredentialHolder(async () => new Response('[]', { status: 200, headers: { 'content-type': 'application/json', 'content-length': '5000' } }));
  declared.replace(TOKEN);
  assert.deepEqual(await getValidated(declared, { kind: 'clients' }, never(), validateClients, { maxBytes: 4096 }), { ok: false, code: 'RESPONSE_TOO_LARGE' });
  let pulled = 0; let cancelled = false;
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) { pulled += 1; controller.enqueue(new Uint8Array(1024).fill(0x20)); },
    cancel() { cancelled = true; }
  });
  const streamed = createCredentialHolder(async () => new Response(stream, { status: 200, headers: { 'content-type': 'application/json' } }));
  streamed.replace(TOKEN);
  assert.deepEqual(await getValidated(streamed, { kind: 'clients' }, never(), validateClients, { maxBytes: 4096 }), { ok: false, code: 'RESPONSE_TOO_LARGE' });
  assert.ok(cancelled, 'the stream is cancelled at the cap'); assert.ok(pulled <= 8, `read stopped early (${pulled} chunks)`);
  const exact = createCredentialHolder(async () => new Response(`[${' '.repeat(4094)}]`, { status: 200, headers: { 'content-type': 'application/json' } }));
  exact.replace(TOKEN);
  assert.deepEqual(await getValidated(exact, { kind: 'clients' }, never(), validateClients, { maxBytes: 4096 }), { ok: true, value: [] });
});

test('one original deadline covers headers and body, and settles even when fetch ignores its signal', async () => {
  // Headers arrive in time, the body never completes: TIMEOUT from the original deadline, not a fresh one per phase.
  const slowBody = createCredentialHolder(async () => new Response(new ReadableStream({ start() { /* never enqueues */ } }),
    { status: 200, headers: { 'content-type': 'application/json' } }));
  slowBody.replace(TOKEN);
  const started = Date.now();
  assert.deepEqual(await getValidated(slowBody, { kind: 'clients' }, never(), validateClients, { deadlineMs: 150 }), { ok: false, code: 'TIMEOUT' });
  assert.ok(Date.now() - started < 1000);
  // A fetch that ignores AbortSignal entirely: the transport still settles locally (caller abort → NETWORK, deadline → TIMEOUT).
  let calls = 0;
  const deaf = createCredentialHolder(() => { calls += 1; return new Promise<Response>(() => undefined); });
  deaf.replace(TOKEN);
  const abort = new AbortController();
  const pending = getValidated(deaf, { kind: 'clients' }, abort.signal, validateClients, { deadlineMs: 5000 });
  abort.abort();
  assert.deepEqual(await pending, { ok: false, code: 'NETWORK' });
  assert.deepEqual(await getValidated(deaf, { kind: 'clients' }, never(), validateClients, { deadlineMs: 50 }), { ok: false, code: 'TIMEOUT' });
  assert.equal(calls, 2, 'no automatic retry');
});

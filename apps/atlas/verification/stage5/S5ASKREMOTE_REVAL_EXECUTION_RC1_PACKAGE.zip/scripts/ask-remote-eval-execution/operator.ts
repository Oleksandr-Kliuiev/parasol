// Interactive operator session (UNADMITTED LOCAL OBSERVATION). Requires an interactive TTY on stdin AND stdout: a pipe
// cannot drive it, and consent needs a fresh per-case challenge shown only at that moment. A TTY is a guard against casual
// automation, NOT proof of who is typing: operator identity stays ATTESTED_UNVERIFIED. Pasted transient values (question,
// request/response bodies) are read with echo OFF in raw mode, end with Ctrl-D, stay in memory for one call and are never
// written anywhere. Output is fixed codes, case/fixture IDs and counts only. The tool never sends anything: every request
// is made by the operator in the accepted browser console.
import { statSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { randomBytes } from 'node:crypto';
import { admissionBlockers, verifyArtifact } from './artifact.ts';
import { loadContext } from './corpus.ts';
import { buildReceipt, lockRun, writeReceipt } from './receipt.ts';
import { ExecutionSession } from './session.ts';
import type { OutcomeInput } from './session.ts';
import { codeOf } from './validate.ts';

const out = (line: string): void => { process.stdout.write(`${line}\n`); };
const BANNER = [
  'R-EVAL EXECUTION INSTRUMENT — UNADMITTED LOCAL OBSERVATION. Live admission: BLOCKED. No paid call path exists in this tool.',
  'It sends nothing: you act in the accepted browser console; this tool only checks and records safe codes/numbers.',
  'Pasted values are read with echo OFF (end with Ctrl-D; do not press Enter before it). They are NOT hidden from the',
  'clipboard, browser devtools or screen recording. Never put questions or bodies in shell commands/history, files or logs.',
  'Values you type (admission, counters, ledger, closure) are ATTESTED, not verified. Type "help" for commands.'
];
const HELP = [
  'admission              enter owner admission values (once; creates an exclusive run lock in the receipt dir)',
  'confirm <adm> <ver>    confirm the disclosed admissionId/policyVersion tuple',
  'counters               current DAY/MONTH accounted micro-USD before THIS submission',
  'capability             paste the capability reply (status, correlation header, body) = preflight',
  'next | status          next case ID / fixture / requested focus; run state',
  'stage                  requested focus (syn-obs-… or none) + paste the question (echo off) — strict equality',
  'consent                tick the browser checkbox, then type the shown challenge',
  'submit <caseId>        press Enter at the moment you click Ask (consumes the case; a repeat is an integrity failure)',
  'arrived                press Enter when the reply/error becomes visible (latency end)',
  'outcome                paste request body, reply, then ledger metadata',
  'deviation <caseId>     report that the submitted text differed (consumed CASE_FAIL)',
  'closure | pause | resume-day | resume-pause | export | quit'
];

/** Raw-mode reader: visible single line (Enter) or hidden paste (Ctrl-D). Ctrl-C ends the session safely. */
function readInput(prompt: string, hidden: boolean): Promise<string> {
  return new Promise(resolve => {
    process.stdout.write(prompt);
    const stdin = process.stdin; let buffer = '';
    const done = (value: string): void => { stdin.off('data', onData); stdin.setRawMode(false); stdin.pause(); process.stdout.write('\n'); resolve(value); };
    const onData = (chunk: Buffer): void => {
      const text = chunk.toString('utf8').replace(/\x1b\[20[01]~/g, '');
      for (const ch of text) {
        if (ch === '\u0003') { process.stdout.write('\nINTERRUPTED (nothing was sent by this tool)\n'); process.exit(130); }
        if (hidden && ch === '\u0004') return done(buffer);
        if (!hidden && (ch === '\r' || ch === '\n')) return done(buffer);
        if (ch === '\u007f' || ch === '\b') { if (buffer.length > 0) { buffer = Array.from(buffer).slice(0, -1).join(''); if (!hidden) process.stdout.write('\b \b'); } continue; }
        const normalized = ch === '\r' ? '\n' : ch;
        if (normalized !== '\n' && normalized.charCodeAt(0) < 0x20 && normalized !== '\t') continue;
        if (buffer.length > 300_000) continue;
        buffer += normalized;
        if (!hidden) process.stdout.write(normalized);
      }
    };
    stdin.setRawMode(true); stdin.resume(); stdin.on('data', onData);
  });
}
const line = (p: string): Promise<string> => readInput(p, false);
const paste = (p: string): Promise<string> => readInput(`${p} (echo off; end with Ctrl-D): `, true);

export async function runOperatorSession(receiptDir: string): Promise<number> {
  if (!process.stdin.isTTY || !process.stdout.isTTY) { process.stderr.write('SESSION_REQUIRES_INTERACTIVE_TTY\n'); return 2; }
  try { if (!statSync(receiptDir).isDirectory()) throw new Error(); } catch { process.stderr.write('RECEIPT_DIR_INVALID\n'); return 2; }
  BANNER.forEach(out);
  const ctx = loadContext();
  const start = verifyArtifact();
  out(`ARTIFACT ${start.ok ? 'VERIFIED' : 'DRIFT'} files=${start.filesChecked} drift=${start.drift.join(',') || 'none'}`);
  out(`LIVE_ADMISSION BLOCKED: ${admissionBlockers(start).join(',')}`);
  if (!start.ok) return 1;
  let session: ExecutionSession | null = null; let receiptName = '';
  const save = (): void => { if (session) { try { out(`RECEIPT ${writeReceipt(receiptDir, buildReceipt(session, ctx.cases), ctx.cases, receiptName) ? 'WRITTEN' : ''}`); } catch (e) { out(codeOf(e)); } } };
  const need = (): ExecutionSession => session ?? (() => { throw new Error('NO_SESSION'); })();
  const http = async () => ({ status: await line('HTTP status: '), correlationHeader: await line('x-atlas-correlation-id: '), body: await paste('Body') });

  for (;;) {
    const [cmd, ...args] = (await line('reval> ')).trim().split(/\s+/);
    try {
      if (cmd === 'help') HELP.forEach(out);
      else if (cmd === 'admission') {
        if (session) { out('ADMISSION_ALREADY_SET'); continue; }
        const input = { admissionId: await line('admissionId: '), startUtc: await line('start UTC (YYYY-MM-DDTHH:MM:SSZ): '), expiryUtc: await line('expiry UTC: '),
          dayCapMicro: await line('DAY cap micro-USD: '), monthCapMicro: await line('MONTH cap micro-USD: '), openingFenceEpoch: await line('opening fence epoch: '),
          pacingMax: await line('pacing max per 60 s (≤10): ') };
        const created = new ExecutionSession({ runClass: 'UNADMITTED_LOCAL_OBSERVATION', clock: () => ({ utcMs: Date.now(), monoMs: performance.now() }),
          verify: verifyArtifact, nonce: () => randomBytes(4).toString('hex'), corpus: ctx.corpus }, input);
        lockRun(receiptDir, created.admission.admissionId);
        session = created; receiptName = `REVAL_EXECUTION_${created.admission.admissionId}.json`;
        out('ADMISSION_RECORDED_ATTESTED'); save();
      } else if (cmd === 'confirm') out(need().confirmTuple(args[0], args[1]));
      else if (cmd === 'counters') out(need().counters({ dayChargedMicro: await line('DAY charged micro-USD: '), monthChargedMicro: await line('MONTH charged micro-USD: ') }));
      else if (cmd === 'capability') out(need().capability(await http()));
      else if (cmd === 'next' || cmd === 'status') {
        const s = need(); const n = s.nextSetup();
        out(`STATE ${s.state} CLOSURE ${s.closureState} VOLUNTARY ${s.voluntary} IN_FLIGHT ${s.inFlight ?? 'none'}`);
        out(n ? `NEXT ${n.caseId} FIXTURE ${n.fixtureId} FOCUS ${n.requestedFocus ?? 'none'}` : 'NEXT none');
      } else if (cmd === 'stage') {
        const s = need(); const id = s.nextCaseId ?? '';
        out(s.stage(id, await line(`requested focus for ${id}: `), await paste('Question exactly as pasted into the browser')));
      } else if (cmd === 'consent') {
        const s = need(); const id = s.nextCaseId ?? '';
        const nonce = s.consentChallenge(id);
        out(`Tick the browser consent checkbox for THIS question now. Then type: ${id} ${nonce}`);
        const [typedId, typedNonce] = (await line('> ')).trim().split(/\s+/);
        const ticked = (await line('Checkbox ticked manually for this question? (type YES): ')) === 'YES';
        out(typedId === id ? s.consent(id, typedNonce, ticked) : 'BLOCKED');
      } else if (cmd === 'submit') out(need().submit(args[0]));
      else if (cmd === 'arrived') out(need().arrived(need().inFlight));
      else if (cmd === 'outcome') {
        const s = need(); const id = s.inFlight;
        if (id === null) { out('BLOCKED_NOT_IN_FLIGHT'); continue; }
        const request = await paste('Request body (AskRequestV2 as sent)');
        const kind = await line('reply: response | timeout | unparseable: ');
        let input: OutcomeInput;
        const ledger = (await line('ledger metadata available from owner read? (yes/no): ')) === 'yes' ? {
          correlationId: await line('ledger correlationId: '), attempts: await line('attempts: '), settlement: await line('settlement enum: '),
          chargedMicro: await line('charged micro-USD: '), dayChargedMicro: await line('DAY charged after: '), monthChargedMicro: await line('MONTH charged after: ') } : null;
        if (kind === 'timeout') input = { request, reply: 'TIMEOUT', ledger };
        else {
          const reply = kind === 'unparseable' ? { status: await line('HTTP status: '), correlationHeader: '', body: '' } : await http();
          const configFaultAttested = (await line('owner-confirmed configuration/circuit fault? (yes/no): ')) === 'yes';
          input = { request, reply, replyUnparseable: kind === 'unparseable', ledger, configFaultAttested };
        }
        out(String(s.outcome(id, input))); save();
      } else if (cmd === 'deviation') { out(need().deviation(args[0])); save(); }
      else if (cmd === 'closure') {
        out(need().closure({ admissionId: await line('admissionId: '), paused: await line('paused (true/false): '), policyVersion: await line('policyVersion: '),
          fenceEpoch: await line('fenceEpoch: ') })); save();
      } else if (cmd === 'pause') { out(need().voluntaryPause()); save(); }
      else if (cmd === 'resume-day') out(need().resumeDay());
      else if (cmd === 'resume-pause') out(need().resumeVoluntary());
      else if (cmd === 'export') save();
      else if (cmd === 'quit') {
        if (session) { save(); if (session.inFlight !== null || session.closureState === 'PENDING' || session.voluntary === 'PENDING') out('WARNING_OPEN_CASE_OR_CLOSURE_PENDING'); }
        return 0;
      } else if (cmd !== '') out('UNKNOWN_COMMAND');
    } catch (e) { out(codeOf(e, e instanceof Error && e.message === 'NO_SESSION' ? 'NO_ADMISSION_YET' : 'INPUT_REJECTED')); }
  }
}

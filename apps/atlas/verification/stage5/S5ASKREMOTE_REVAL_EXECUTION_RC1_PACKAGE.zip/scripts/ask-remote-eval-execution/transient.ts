// Transient V2 evidence of ONE case: the AskRequestV2 that was actually sent and the server reply, each pasted by the
// operator (or produced by the offline fake V2). Both are parsed with the accepted strict JSON parser and validated with
// the ACCEPTED validators (server request parser; browser V2 answer/error validators) BEFORE any boolean is derived. A
// validated answer is then judged by the accepted independent comparator against the frozen fixture expectation for the
// OBSERVED intent, regardless of the expected label. Only fixed enums/booleans and the validated correlation UUID leave
// this module; question, bodies, answer and observed intent stay in locals of the caller and are dropped.
import { validateAskError, validateRemoteAnswer, validateRemoteCapability } from '../../apps/operator/src/validate-ask.ts';
import { askRemoteRequest } from '../../packages/ask/remote/input.ts';
import { parseStrictJson } from '../../packages/ask/remote/json.ts';
import type { EvalCase, Intent } from '../ask-remote-eval/dataset.ts';
import type { FixtureFile } from '../ask-remote-eval/fixtures.ts';
import type { PreparedFixture } from '../ask-remote-eval/harness.ts';
import { checkAnswer } from '../ask-remote-eval/predicates.ts';
import type { TruthFailure } from '../ask-remote-eval/predicates.ts';
import { httpStatus, reject, transientText } from './validate.ts';

export interface CaseContext { readonly frozen: EvalCase; readonly fixture: PreparedFixture; readonly scope: FixtureFile['scope'] }
export interface Tuple { readonly admissionId: string; readonly policyVersion: string }

/** Strict JSON of a pasted value. A paste that is not JSON is re-promptable (PASTE_REJECTED) and derives nothing. */
export function strictJson(text: unknown): unknown {
  const value = transientText(text, 'PASTE_REJECTED');
  try { return parseStrictJson(value); } catch { return reject('PASTE_REJECTED'); }
}

export type RequestCheck = { readonly requestId: string | null; readonly deviation: boolean };
/**
 * The request actually sent. An AskRequestV2 rejected by the accepted parser, or one whose question, requested focus or
 * acknowledgement tuple differs from the frozen case / captured tuple, is a POST-SUBMISSION deviation (consumed CASE_FAIL).
 */
export function checkRequest(text: unknown, ctx: CaseContext, tuple: Tuple): RequestCheck {
  const body = strictJson(text);
  try {
    const r = askRemoteRequest(body);
    const deviation = r.question !== ctx.frozen.question || r.observationId !== ctx.fixture.spec.requestedFocus
      || r.acknowledgement.admissionId !== tuple.admissionId || r.acknowledgement.policyVersion !== tuple.policyVersion;
    return { requestId: r.requestId, deviation };
  } catch { return { requestId: null, deviation: true }; }
}

export interface TransientHttp { readonly status: unknown; readonly correlationHeader: unknown; readonly body: unknown }
/** Truth categories of the plan's safety table, split from the comparator's fixed failure codes. */
export type TruthCategory = 'SCHEMA' | 'CLAIMS' | 'COVERAGE' | 'URGENCY';
const CATEGORY: Readonly<Record<TruthFailure, TruthCategory>> = {
  SHAPE: 'SCHEMA', PROVENANCE: 'SCHEMA', FOCUS: 'CLAIMS', INTENT_ECHO: 'CLAIMS', STATUS: 'CLAIMS', EVIDENCE: 'CLAIMS', REFS: 'CLAIMS', CLAIMS: 'CLAIMS',
  OBSERVATION_DATA: 'CLAIMS', RESOURCE_DATA: 'CLAIMS', RESOURCE_STATUS: 'CLAIMS', ENTITY: 'CLAIMS', URGENCY: 'URGENCY', COVERAGE: 'COVERAGE'
};
export interface Truth { readonly pass: boolean; readonly claims: boolean; readonly coverage: boolean; readonly urgency: boolean; readonly schema: boolean }
export type Observed =
  /** observedIntent is TRANSIENT: the caller passes it to the in-memory supervisor and never persists it. */
  | { readonly kind: 'ANSWER'; readonly observedIntent: Intent; readonly truth: Truth; readonly correlationId: string }
  | { readonly kind: 'ERROR'; readonly code: string; readonly correlationId: string }
  /** The reply failed the accepted browser validator (it would be discarded whole): a schema/envelope violation. */
  | { readonly kind: 'LOCAL_INVALID'; readonly outcome: 'LOCAL_V2_ANSWER_INVALID' | 'LOCAL_ERROR_ENVELOPE_INVALID' | 'LOCAL_REPLY_UNPARSEABLE' };

export function truthOf(failures: readonly TruthFailure[]): Truth {
  const hit = new Set(failures.map(f => CATEGORY[f]));
  return { pass: failures.length === 0, claims: !hit.has('CLAIMS'), coverage: !hit.has('COVERAGE'), urgency: !hit.has('URGENCY'), schema: !hit.has('SCHEMA') };
}

function headersOf(value: unknown): Headers | null {
  if (typeof value !== 'string' || value.length > 64) return null;
  try { return new Headers({ 'x-atlas-correlation-id': value }); } catch { return null; }
}

/**
 * The server reply for the request with `requestId`. `unparseable: true` is the operator's explicit statement that the
 * real body was not JSON (a schema violation); otherwise a non-JSON paste is re-promptable.
 */
export function checkResponse(http: TransientHttp, ctx: CaseContext, requestId: string | null, unparseable = false): Observed {
  const status = httpStatus(typeof http.status === 'number' ? String(http.status) : http.status);
  if (unparseable) return { kind: 'LOCAL_INVALID', outcome: 'LOCAL_REPLY_UNPARSEABLE' };
  const body = strictJson(http.body);
  const headers = headersOf(http.correlationHeader);
  if (status === 200) {
    if (headers === null || requestId === null) return { kind: 'LOCAL_INVALID', outcome: 'LOCAL_V2_ANSWER_INVALID' };
    try {
      const view = validateRemoteAnswer(body, headers, { requestId, workspaceId: ctx.scope.workspaceId, clientId: ctx.scope.clientId, sourceMode: 'db',
        focusObservationId: ctx.fixture.spec.requestedFocus });
      const observedIntent = view.intent as Intent;
      const result = checkAnswer(body, ctx.fixture.spec.expected, observedIntent, ctx.fixture.spec.requestedFocus, ctx.scope, ctx.fixture.facts);
      return { kind: 'ANSWER', observedIntent, truth: truthOf(result.failures), correlationId: view.correlationId };
    } catch { return { kind: 'LOCAL_INVALID', outcome: 'LOCAL_V2_ANSWER_INVALID' }; }
  }
  if (headers === null) return { kind: 'LOCAL_INVALID', outcome: 'LOCAL_ERROR_ENVELOPE_INVALID' };
  try {
    const error = validateAskError(body, headers, status, true);
    return { kind: 'ERROR', code: error.code, correlationId: error.correlationId };
  } catch { return { kind: 'LOCAL_INVALID', outcome: 'LOCAL_ERROR_ENVELOPE_INVALID' }; }
}

/** Capability observation (read-only preflight): exact AskCapabilityV2 → tuple; 503 ASK_REMOTE_NOT_ADMITTED → inactive. */
export type CapabilityCheck = { readonly kind: 'ACTIVE'; readonly tuple: Tuple } | { readonly kind: 'INACTIVE' } | { readonly kind: 'UNAVAILABLE' };
export function checkCapability(http: TransientHttp): CapabilityCheck {
  const status = httpStatus(typeof http.status === 'number' ? String(http.status) : http.status);
  const body = strictJson(http.body);
  const headers = headersOf(http.correlationHeader);
  if (headers === null) return { kind: 'UNAVAILABLE' };
  try {
    if (status === 200) { const d = validateRemoteCapability(body, headers); return { kind: 'ACTIVE', tuple: { admissionId: d.admissionId, policyVersion: d.policyVersion } }; }
    return validateAskError(body, headers, status, true).code === 'ASK_REMOTE_NOT_ADMITTED' ? { kind: 'INACTIVE' } : { kind: 'UNAVAILABLE' };
  } catch { return { kind: 'UNAVAILABLE' }; }
}

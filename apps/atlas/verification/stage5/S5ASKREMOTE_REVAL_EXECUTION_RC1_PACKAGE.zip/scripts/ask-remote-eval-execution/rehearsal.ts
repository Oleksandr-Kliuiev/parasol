// OFFLINE fake-V2 REHEARSAL of the execution instrument (SIMULATED; not a live journey and not an operator session).
// A scripted driver plays each case through the SAME ExecutionSession the operator uses, with a fake clock, the fake V2
// server/ledger and deterministic consent challenges. Each scenario has a plan-derived expectation; the whole set runs
// twice with fresh state and must reproduce byte-identical safe results (deterministic replay). The fake returns the
// DRAFT label by default, so nothing here measures classification quality or provider behaviour.
import type { EvalCase, Intent } from '../ask-remote-eval/dataset.ts';
import type { Snapshot } from './artifact.ts';
import { loadContext } from './corpus.ts';
import type { Ctx } from './corpus.ts';
import { fakeRequest, fakeUuid, FakeV2 } from './fake-v2.ts';
import type { FakeScript } from './fake-v2.ts';
import { buildReceipt } from './receipt.ts';
import { ExecutionSession } from './session.ts';

export { loadContext };
export const ADMISSION_ID = fakeUuid('reval-execution-rehearsal-admission');
export const START = Date.UTC(2026, 9, 12, 6, 0, 0);
const HOUR = 3_600_000;
const iso = (ms: number): string => new Date(ms).toISOString();

export interface Rig { readonly session: ExecutionSession; readonly fake: FakeV2; readonly clock: { utcMs: number; monoMs: number }; readonly ctx: Ctx; drift: boolean; steps: string[] }
export function rig(ctx: Ctx, o: { dayCap?: number; monthCap?: number; expiryMs?: number; pacingMax?: number } = {}): Rig {
  const dayCap = o.dayCap ?? 2_000_000; const monthCap = o.monthCap ?? 10_000_000;
  const fake = new FakeV2(ctx.corpus.fixtures, ctx.corpus.scope, { admissionId: ADMISSION_ID, version: '7', fence: '40', dayCap, monthCap });
  const clock = { utcMs: START, monoMs: 1_000 }; let nonce = 0;
  const r: Rig = { session: null as unknown as ExecutionSession, fake, clock, ctx, drift: false, steps: [] };
  const drifted: Snapshot = { ...ctx.snapshot, identity: ctx.snapshot.identity && { ...ctx.snapshot.identity, datasetCorpusSha256: '0'.repeat(64) } };
  (r as { session: ExecutionSession }).session = new ExecutionSession({ runClass: 'OFFLINE_FAKE_V2_REHEARSAL', clock: () => ({ ...clock }),
    verify: () => r.drift ? drifted : ctx.snapshot, nonce: () => `n${(nonce += 1).toString(36).padStart(5, '0')}`, corpus: ctx.corpus },
  { admissionId: ADMISSION_ID, startUtc: iso(START), expiryUtc: iso(o.expiryMs ?? START + 6 * 24 * HOUR), dayCapMicro: String(dayCap), monthCapMicro: String(monthCap),
    openingFenceEpoch: '40', pacingMax: String(o.pacingMax ?? 10) });
  r.steps.push(`confirm:${r.session.confirmTuple(fake.tuple.admissionId, fake.tuple.policyVersion)}`);
  return r;
}
export const advance = (r: Rig, ms: number): void => { r.clock.utcMs += ms; r.clock.monoMs += ms; };

export interface Play {
  readonly script?: (c: EvalCase) => FakeScript; readonly edited?: boolean; readonly ledger?: 'FAKE' | 'MISSING' | 'WRONG_CORRELATION';
  readonly configFault?: boolean; readonly latencyMs?: number; readonly gapMs?: number;
}
const caseOf = (r: Rig, id: string): EvalCase => r.ctx.corpus.cases.get(id)!;
const focusOf = (r: Rig, c: EvalCase): string | null => r.ctx.corpus.fixtures.get(c.fixtureId)!.spec.requestedFocus;

/** Every manual step of ONE case, scripted: counters → capability → stage → challenge+consent → submit → reply → outcome. */
export function playNext(r: Rig, p: Play = {}): string {
  const s = r.session; const log = (x: string): string => { r.steps.push(x); return x; };
  advance(r, p.gapMs ?? 13_000);
  const id = s.nextCaseId; if (id === null) return log('NO_NEXT_CASE');
  const c = caseOf(r, id); const focus = focusOf(r, c);
  s.counters(r.fake.counters(r.clock.utcMs));
  const pre = s.capability(r.fake.capability().http);
  if (pre !== 'OK') return log(`preflight:${pre}`);
  const staged = s.stage(id, focus ?? 'none', c.question);
  if (staged !== 'STAGED') return log(`stage:${staged}`);
  const tuple = r.fake.tuple;
  s.consent(id, s.consentChallenge(id), true);
  const sub = s.submit(id);
  if (sub !== 'DISPATCH') return log(`submit:${sub}`);
  const request = fakeRequest(`${id}:${r.clock.monoMs}`, p.edited ? `${c.question} (edited)` : c.question, focus, tuple);
  const reply = r.fake.ask(request, c.fixtureId, p.script ? p.script(c) : { kind: 'INTENT', intent: c.expectedIntent }, r.clock.utcMs);
  advance(r, p.latencyMs ?? 700 + (id.charCodeAt(id.length - 1) % 7) * 100);
  if (reply.http !== 'TIMEOUT') s.arrived(id);
  const fakeLedger = r.fake.ledgerFor(reply.correlationId);
  const ledger = p.ledger === 'MISSING' || fakeLedger === null ? null
    : p.ledger === 'WRONG_CORRELATION' ? { ...fakeLedger, correlationId: fakeUuid('unrelated-correlation') } : fakeLedger;
  return log(`outcome:${s.outcome(id, { request, reply: reply.http, ledger, configFaultAttested: p.configFault === true })}`);
}
/** Play correct cases until the NEXT case satisfies `want` (or the run stops). */
export function playUntil(r: Rig, want: (c: EvalCase) => boolean): void {
  while (r.session.state === 'ACTIVE' && r.session.nextCaseId !== null && !want(caseOf(r, r.session.nextCaseId))) playNext(r);
}
const supported = (c: EvalCase): boolean => c.group.startsWith('SUPPORTED_');
const OTHER: Readonly<Record<string, Intent>> = { SUMMARY: 'ENTITY', WHY_URGENT: 'SUMMARY', SOURCE_STATE: 'SUMMARY', ENTITY: 'SUMMARY', UNSUPPORTED: 'SUMMARY' };

/** Safe observation of a rig: fixed enums, counts and step codes only. */
export function observe(r: Rig): Record<string, unknown> {
  const f = r.session.facts(); const rep = f.report as Record<string, any>;
  const last = (rep.records as Record<string, unknown>[]).at(-1);
  const local = last ? f.evidence.get(last.caseId as string)?.localOutcome : null;
  return { state: rep.state, reason: rep.reason, closure: rep.closure, voluntary: f.voluntary, consumed: rep.consumed,
    safety: Object.fromEntries([...f.safety].filter(([, n]) => n > 0)), integrity: f.integrity, lastOutcome: local && last?.outcome === 'ASK_REMOTE_INVALID' ? local : last?.outcome ?? null, lastPass: last?.casePass ?? null,
    lastSemantic: last?.semantic ?? null, steps: r.steps.slice(-4) };
}

interface Scenario { readonly id: string; readonly expected: Record<string, unknown>; readonly run: (ctx: Ctx) => Rig }
const closeWith = (r: Rig, receipt: { admissionId: string; paused: string; policyVersion: string; fenceEpoch: string }): void => { r.steps.push(`closure:${r.session.closure(receipt)}`); };
export const SCENARIOS: readonly Scenario[] = [
  { id: 'X01_FULL_200_THEN_CLOSURE', expected: { state: 'COMPLETE_PENDING_REVIEW', reason: 'ALL_CASES_CONSUMED', closure: 'CONFIRMED', consumed: 200, safety: {} },
    run: ctx => { const r = rig(ctx); for (let i = 0; i < 200; i += 1) playNext(r); closeWith(r, r.fake.pause()); return r; } },
  { id: 'X02_PRESUBMIT_TEXT_AND_FOCUS_BLOCKED_UNCONSUMED', expected: { state: 'ACTIVE', consumed: 1, lastPass: true },
    run: ctx => { const r = rig(ctx); const id = r.session.nextCaseId!; const c = caseOf(r, id); const focus = focusOf(r, c);
      r.steps.push(`stage:${r.session.stage(id, focus ?? 'none', `${c.question} `)}`, `stage:${r.session.stage(id, focus === null ? 'syn-obs-wrong' : 'none', c.question)}`,
        `submit:${r.session.submit(id)}`);
      playNext(r); return r; } },
  { id: 'X03_POSTSUBMIT_DEVIATION_CONSUMED_FAIL', expected: { state: 'ACTIVE', lastOutcome: 'SUBMITTED_TEXT_DEVIATION', lastPass: false },
    run: ctx => { const r = rig(ctx); playUntil(r, supported); playNext(r, { edited: true }); return r; } },
  { id: 'X04_DUPLICATE_SUBMISSION_INTEGRITY', expected: { state: 'TERMINAL_FAILED', reason: 'DUPLICATE_DISPATCH', integrity: ['DUPLICATE_SUBMISSION'] },
    run: ctx => { const r = rig(ctx); const id = r.session.nextCaseId!; playNext(r); r.steps.push(`submit:${r.session.submit(id)}`); return r; } },
  { id: 'X05_DAY_CAP_RESUME_NEXT_UTC_DAY', expected: { state: 'ACTIVE', consumed: 3, closure: 'NOT_REQUIRED' },
    run: ctx => { const r = rig(ctx, { dayCap: 600_000 });
      const retained = { script: (c: EvalCase): FakeScript => ({ kind: 'INTENT', intent: c.expectedIntent, settlement: 'RETAINED_KNOWN' }) };
      playNext(r, retained); playNext(r, retained); playNext(r);
      r.steps.push(`resume-same-day-closed:${r.session.resumeDay()}`);
      closeWith(r, r.fake.pause()); r.steps.push(`resume-same-day:${r.session.resumeDay()}`);
      advance(r, 24 * HOUR); r.steps.push(`resume:${r.session.resumeDay()}`);
      r.fake.reactivate(); r.steps.push(`confirm:${r.session.confirmTuple(ADMISSION_ID, r.fake.tuple.policyVersion)}`);
      playNext(r); return r; } },
  { id: 'X06_MONTH_CAP_TERMINAL', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'MONTH_CAP', consumed: 2 },
    run: ctx => { const r = rig(ctx, { dayCap: 600_000, monthCap: 600_000 });
      const retained = { script: (c: EvalCase): FakeScript => ({ kind: 'INTENT', intent: c.expectedIntent, settlement: 'RETAINED_KNOWN' }) };
      playNext(r, retained); playNext(r, retained); playNext(r); return r; } },
  { id: 'X07_UNAVAILABLE_INCOMPLETE', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'UNAVAILABLE', lastOutcome: 'ASK_REMOTE_UNAVAILABLE' },
    run: ctx => { const r = rig(ctx); playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_REMOTE_UNAVAILABLE', settlement: 'RETAINED_KNOWN' }) }); return r; } },
  { id: 'X08_UNAVAILABLE_CONFIG_FAULT_FAILED', expected: { state: 'TERMINAL_FAILED', reason: 'UNAVAILABLE_CONFIG_FAULT', safety: { CONFIG: 1 } },
    run: ctx => { const r = rig(ctx); playNext(r, { configFault: true, script: () => ({ kind: 'ERROR', code: 'ASK_REMOTE_UNAVAILABLE', settlement: 'RETAINED_KNOWN' }) }); return r; } },
  { id: 'X09_REMOTE_INVALID_FAILED_SCHEMA', expected: { state: 'TERMINAL_FAILED', reason: 'ASK_REMOTE_INVALID', safety: { SCHEMA: 1 } },
    run: ctx => { const r = rig(ctx); playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_REMOTE_INVALID', settlement: 'RETAINED_KNOWN' }) }); return r; } },
  { id: 'X10_MODEL_MISMATCH_FAILED', expected: { state: 'TERMINAL_FAILED', reason: 'ASK_REMOTE_MODEL_MISMATCH', safety: { MODEL_TIER: 1 } },
    run: ctx => { const r = rig(ctx); playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_REMOTE_MODEL_MISMATCH', settlement: 'RETAINED_KNOWN' }) }); return r; } },
  { id: 'X11_USAGE_INVALID_FAILED', expected: { state: 'TERMINAL_FAILED', reason: 'ASK_REMOTE_USAGE_INVALID', safety: { USAGE: 1 } },
    run: ctx => { const r = rig(ctx); playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_REMOTE_USAGE_INVALID', settlement: 'RETAINED_KNOWN' }) }); return r; } },
  { id: 'X12_ALTERED_FACT_CLAIM_SAFETY', expected: { state: 'TERMINAL_FAILED', reason: 'SAFETY_VIOLATION', safety: { CLAIMS: 1 }, lastOutcome: 'ANSWER' },
    run: ctx => { const r = rig(ctx); while (r.session.state === 'ACTIVE') playNext(r, { script: c => ({ kind: 'INTENT', intent: c.expectedIntent, tamper: 'OBSERVATION_SUMMARY' }) }); return r; } },
  { id: 'X13_V2_VALIDATOR_REJECT_SCHEMA', expected: { state: 'TERMINAL_FAILED', reason: 'ASK_REMOTE_INVALID', safety: { SCHEMA: 1 }, lastOutcome: 'LOCAL_V2_ANSWER_INVALID' },
    run: ctx => { const r = rig(ctx); playNext(r, { script: c => ({ kind: 'INTENT', intent: c.expectedIntent, tamper: 'DROP_PROVENANCE' }) }); return r; } },
  { id: 'X14_GROUNDED_WRONG_INTENT_SEMANTIC_ONLY', expected: { state: 'TERMINAL_FAILED', reason: 'THRESHOLD_UNREACHABLE', safety: {}, lastSemantic: 'MISMATCH' },
    run: ctx => { const r = rig(ctx); while (r.session.state === 'ACTIVE') playNext(r, { script: c => ({ kind: 'INTENT', intent: supported(c) ? OTHER[c.expectedIntent]! : c.expectedIntent }) }); return r; } },
  { id: 'X15_REFUSAL_ANSWERED_TRUTHFULLY_STILL_FAILS', expected: { state: 'TERMINAL_FAILED', reason: 'THRESHOLD_UNREACHABLE', safety: {}, lastSemantic: 'MISMATCH', lastPass: false },
    run: ctx => { const r = rig(ctx); playUntil(r, c => !supported(c)); playNext(r, { script: () => ({ kind: 'INTENT', intent: 'SUMMARY' }) }); return r; } },
  { id: 'X16_MISSING_LEDGER_UNKNOWN_COMMIT', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'UNKNOWN_SETTLEMENT_COMMIT' },
    run: ctx => { const r = rig(ctx); playNext(r, { ledger: 'MISSING' }); return r; } },
  { id: 'X17_UNBOUND_LEDGER_UNKNOWN_COMMIT', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'UNKNOWN_SETTLEMENT_COMMIT' },
    run: ctx => { const r = rig(ctx); playNext(r, { ledger: 'WRONG_CORRELATION' }); return r; } },
  { id: 'X18_DEADLINE_KNOWN_COMMIT_AND_BUSY_CONTINUE', expected: { state: 'ACTIVE', lastOutcome: 'ASK_BUSY', lastPass: false, safety: {} },
    run: ctx => { const r = rig(ctx); playUntil(r, supported); const group = caseOf(r, r.session.nextCaseId!).group;
      playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_DEADLINE', settlement: 'RETAINED_KNOWN' }) });
      playUntil(r, c => supported(c) && c.group !== group);
      playNext(r, { script: () => ({ kind: 'ERROR', code: 'ASK_BUSY', settlement: 'NO_RESERVATION' }) }); return r; } },
  { id: 'X19_TIMEOUT_CENSORED_INCOMPLETE', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'UNKNOWN_COMMIT', lastOutcome: 'SUPERVISOR_TIMEOUT' },
    run: ctx => { const r = rig(ctx); playNext(r, { script: () => ({ kind: 'TIMEOUT' }), latencyMs: 10_000 }); return r; } },
  { id: 'X20_CONCURRENT_REVISION_409_CONSUMED', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'LOSS_OF_AUTHORITY', consumed: 1, lastOutcome: 'ASK_REMOTE_POLICY_CHANGED' },
    run: ctx => { const r = rig(ctx); const realAsk = r.fake.ask.bind(r.fake);
      r.fake.ask = (req, fx, script, utc) => { r.fake.revise(); return realAsk(req, fx, script, utc); }; playNext(r); return r; } },
  { id: 'X21_INACTIVE_PREFLIGHT_TERMINAL_UNCONSUMED', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'LOSS_OF_AUTHORITY_INACTIVE_POLICY', consumed: 0 },
    run: ctx => { const r = rig(ctx); r.fake.pause(); playNext(r); return r; } },
  { id: 'X22_VERSION_CHANGED_RECONFIRM', expected: { state: 'ACTIVE', consumed: 1 },
    run: ctx => { const r = rig(ctx); r.fake.revise(); playNext(r); r.steps.push(`confirm:${r.session.confirmTuple(ADMISSION_ID, r.fake.tuple.policyVersion)}`); playNext(r); return r; } },
  { id: 'X23_STALE_CLOSURE_CONTAINMENT_UNCONFIRMED', expected: { state: 'TERMINAL_INCOMPLETE', closure: 'CONTAINMENT_UNCONFIRMED' },
    run: ctx => { const r = rig(ctx); playNext(r, { ledger: 'MISSING' }); closeWith(r, { admissionId: ADMISSION_ID, paused: 'true', policyVersion: '99', fenceEpoch: '40' }); return r; } },
  { id: 'X24_VOLUNTARY_PAUSE_CLOSURE_RESUME', expected: { state: 'ACTIVE', voluntary: 'NONE', consumed: 2 },
    run: ctx => { const r = rig(ctx); playNext(r); r.steps.push(`pause:${r.session.voluntaryPause()}`, `resume-unclosed:${r.session.resumeVoluntary()}`);
      closeWith(r, r.fake.pause()); r.steps.push(`resume:${r.session.resumeVoluntary()}`, `confirm-old:${r.session.confirmTuple(ADMISSION_ID, '7')}`);
      r.fake.reactivate(); r.steps.push(`confirm:${r.session.confirmTuple(ADMISSION_ID, r.fake.tuple.policyVersion)}`); playNext(r); return r; } },
  { id: 'X25_ARTIFACT_DRIFT_BEFORE_SUBMIT', expected: { state: 'TERMINAL_FAILED', reason: 'ARTIFACT_DRIFT', consumed: 0, integrity: ['ARTIFACT_DRIFT'] },
    run: ctx => { const r = rig(ctx); r.drift = true; playNext(r); return r; } },
  { id: 'X26_DUPLICATE_DISPATCH_IN_LEDGER', expected: { state: 'TERMINAL_FAILED', reason: 'DUPLICATE_DISPATCH', integrity: ['DUPLICATE_DISPATCH'] },
    run: ctx => { const r = rig(ctx); playNext(r, { script: c => ({ kind: 'INTENT', intent: c.expectedIntent, attempts: 2 }) }); return r; } },
  { id: 'X27_PACING_BLOCKS_UNCONSUMED', expected: { state: 'ACTIVE', consumed: 1, steps: ['confirm:CONFIRMED', 'outcome:ACTIVE', 'preflight:BLOCKED_PACING'] },
    run: ctx => { const r = rig(ctx, { pacingMax: 2 }); playNext(r); playNext(r, { gapMs: 1_000 }); return r; } },
  { id: 'X28_CONSENT_REQUIRES_CHALLENGE_AND_CHECKBOX', expected: { state: 'ACTIVE', consumed: 0, steps: ['consent:BLOCKED', 'consent:BLOCKED', 'consent-replay:BLOCKED', 'submit:BLOCKED_NO_CONSENT'] },
    run: ctx => { const r = rig(ctx); const s = r.session; const id = s.nextCaseId!; const c = caseOf(r, id);
      s.counters(r.fake.counters(r.clock.utcMs)); s.capability(r.fake.capability().http); s.stage(id, focusOf(r, c) ?? 'none', c.question);
      const n1 = s.consentChallenge(id); r.steps.push(`consent:${s.consent(id, 'wrong', true)}`);
      const n2 = s.consentChallenge(id); r.steps.push(`consent:${s.consent(id, n2, false)}`, `consent-replay:${s.consent(id, n1, true)}`, `submit:${s.submit(id)}`); return r; } },
  { id: 'X29_SETTLEMENT_KNOWN_CONTINUE_UNKNOWN_TERMINAL', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'UNKNOWN_SETTLEMENT_COMMIT', consumed: 2 },
    run: ctx => { const r = rig(ctx); playNext(r, { script: c => ({ kind: 'INTENT', intent: c.expectedIntent, settlement: 'RETAINED_KNOWN' }) });
      playNext(r, { script: c => ({ kind: 'INTENT', intent: c.expectedIntent, settlement: 'RETAINED_UNKNOWN_COMMIT' }) }); return r; } },
  { id: 'X30_EXPIRY_BEFORE_SUBMIT', expected: { state: 'TERMINAL_INCOMPLETE', reason: 'ADMISSION_EXPIRED', consumed: 0 },
    run: ctx => { const r = rig(ctx, { expiryMs: START + HOUR }); advance(r, 2 * HOUR); playNext(r); return r; } }
];

/** Run every scenario once; `pass` compares only the expected keys (JSON equality). */
export function runScenarios(ctx: Ctx): { id: string; pass: boolean; observed: Record<string, unknown> }[] {
  return SCENARIOS.map(s => {
    const observed = observe(s.run(ctx));
    return { id: s.id, pass: Object.entries(s.expected).every(([k, v]) => JSON.stringify(observed[k]) === JSON.stringify(v)), observed };
  });
}
/** Rehearsal: all scenarios twice with fresh fakes/sessions + the full-run safe receipt; replay must be byte-identical. */
export function rehearse(): Record<string, unknown> {
  const ctx = loadContext();
  const once = () => { const results = runScenarios(ctx); const full = rig(ctx); for (let i = 0; i < 200; i += 1) playNext(full); closeWith(full, full.fake.pause());
    return { results, receipt: buildReceipt(full.session, ctx.cases) }; };
  const first = once(); const second = once();
  const replay = JSON.stringify(first) === JSON.stringify(second) ? 'DETERMINISTIC_REHEARSAL_REPLAY_VERIFIED' : 'REPLAY_MISMATCH';
  const ok = ctx.snapshot.ok && first.results.every(r => r.pass) && replay === 'DETERMINISTIC_REHEARSAL_REPLAY_VERIFIED';
  return { command: 'rehearse', ok, runClass: 'OFFLINE_FAKE_V2_REHEARSAL', semanticEvaluation: false, providerSemantics: 'NOT_TESTED',
    liveAcceptanceEligible: false, note: 'SIMULATED fake V2/ledger/clock; proves instrument measurement/assertion integration, not provider, server authority or ledger.',
    scenarios: { total: first.results.length, pass: first.results.filter(r => r.pass).length, results: first.results }, replay, fullRunReceipt: first.receipt };
}

# R-EVAL execution instrument — context routing

LOCAL ONLY, not admitted. Docs: `docs/stage5/ask/remote/execution/README.md`, `IMPLEMENTATION_REPORT.md`. Plan RC6
`docs/stage5/ask/remote/S5ASKREMOTE_REVAL_PLAN.md`. No live/paid mode, key, env input, DB, provider, network, child process,
worker, schedule, auto-consent/submit or HAR/trace capture may be added. The tool never sends a request: the operator acts
in the accepted browser V2 console. Never load the dataset into context (`docs/stage5/ask/remote/eval/data/AGENTS.md`).
The accepted offline package `scripts/ask-remote-eval/` is immutable and only imported (pure modules; guard installed first).

Modules (one concern each, ≤500 lines):
- `cli.ts` entry: installs the accepted net guard, then dynamic imports; `artifact-check | rehearse [--write-receipt] | session --receipt-dir <dir> | help`.
- `artifact.ts` pinned manifest anchors (offline RC3, R-C RC1), file/build/dataset/order/tool identity, live-admission blockers.
- `validate.ts` fixed-code (`ExecError`) validators: IDs, decimals, safe integers, UTC instants, admission/counters/ledger.
- `transient.ts` accepted strict JSON + server request parser + browser V2 answer/error/capability validators, then the
  accepted independent comparator for the OBSERVED intent; returns enums/booleans only.
- `session.ts` `ExecutionSession`: wraps the accepted SIMULATED supervisor (unchanged) with attested inputs, consent challenge,
  per-submission artifact re-check, duplicate integrity, ledger binding/reconciliation, voluntary pause, safety rows.
- `receipt.ts` safe receipt + exact allowlist schema + accepted offline scan; run lock; atomic receipt write.
- `corpus.ts` frozen corpus/fixtures in memory. `operator.ts` interactive TTY session (echo-off pastes; UNADMITTED).
- `fake-v2.ts` + `rehearsal.ts` OFFLINE fake V2/ledger and scripted scenarios (SIMULATED; never imported by `operator.ts`).

Tests: `tests/ask-remote-eval-execution-{session,receipt,cli}.test.ts`. Any tool edit changes `executionToolSha256`:
regenerate `docs/stage5/ask/remote/execution/rehearsal/EXECUTION_REHEARSAL_RECEIPT.json` with `rehearse --write-receipt`.

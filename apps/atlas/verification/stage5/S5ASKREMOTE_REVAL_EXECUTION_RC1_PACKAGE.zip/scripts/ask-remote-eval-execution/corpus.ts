// Frozen corpus/fixtures in memory for the execution instrument (shared by the operator session and the rehearsal).
// Questions, rationales and labels live only in this in-process map; nothing here writes or prints them.
import { flattenCorpus, loadCorpusFiles, stableOrder } from '../ask-remote-eval/dataset.ts';
import type { EvalCase } from '../ask-remote-eval/dataset.ts';
import { loadFixtureFile } from '../ask-remote-eval/fixtures.ts';
import { prepareFixtures } from '../ask-remote-eval/harness.ts';
import { verifyArtifact } from './artifact.ts';
import type { Snapshot } from './artifact.ts';
import type { Corpus } from './session.ts';

export interface Ctx { readonly corpus: Corpus; readonly cases: readonly EvalCase[]; readonly snapshot: Snapshot }
let cached: Ctx | null = null;
/** Frozen corpus (seeded order of all 200), prepared fixtures and ONE artifact snapshot taken at load time. */
export function loadContext(): Ctx {
  if (cached) return cached;
  const file = loadFixtureFile(); const cases = flattenCorpus(loadCorpusFiles()) as EvalCase[];
  const corpus: Corpus = { cases: new Map(cases.map(c => [c.caseId, c])), order: stableOrder(cases.map(c => c.caseId)).order, fixtures: prepareFixtures(file), scope: file.scope };
  cached = { corpus, cases, snapshot: verifyArtifact() };
  return cached;
}

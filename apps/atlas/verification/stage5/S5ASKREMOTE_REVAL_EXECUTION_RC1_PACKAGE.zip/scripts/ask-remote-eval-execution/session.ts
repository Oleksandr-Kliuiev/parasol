// One R-EVAL execution session: the ACCEPTED supervisor model (scripts/ask-remote-eval/supervisor.ts, unchanged and
// still not product authority) wrapped with the inputs a manual run actually has: operator-entered admission/counters/
// ledger/closure values (ATTESTED), transient V2 request/reply pastes validated by the accepted validators, artifact
// identity re-checked before every submission, a per-case consent challenge, voluntary pause and safety evidence with
// provenance. Every method returns a fixed result code or throws ExecError(code) WITHOUT changing state. Nothing here
// sends a request, consents, submits, retries or schedules: each step is an explicit call made by the operator (TTY) or,
// in the offline rehearsal only, by a scripted driver whose receipts are labelled SIMULATED.
import { Supervisor } from '../ask-remote-eval/supervisor.ts';
import type { Admission, Clock, FrozenCase, Outcome, RunState, Settlement } from '../ask-remote-eval/supervisor.ts';
import type { EvalCase } from '../ask-remote-eval/dataset.ts';
import type { FixtureFile } from '../ask-remote-eval/fixtures.ts';
import type { PreparedFixture } from '../ask-remote-eval/harness.ts';
import { sameIdentity } from './artifact.ts';
import type { Snapshot } from './artifact.ts';
import { checkCapability, checkRequest, checkResponse } from './transient.ts';
import type { CaseContext, Truth, TransientHttp, Tuple } from './transient.ts';
import { admissionValues, caseId as validCaseId, counterValues, decimal, ExecError, focusId, ledgerValues, reject, transientText, uuid } from './validate.ts';
import type { AdmissionInput, ClosureInput, CountersInput, Ledger, LedgerInput } from './validate.ts';

export type RunClass = 'OFFLINE_FAKE_V2_REHEARSAL' | 'UNADMITTED_LOCAL_OBSERVATION';
export interface Corpus {
  readonly cases: ReadonlyMap<string, EvalCase>; readonly order: readonly string[]; readonly fixtures: ReadonlyMap<string, PreparedFixture>;
  readonly scope: FixtureFile['scope'];
}
export interface SessionDeps { readonly runClass: RunClass; readonly clock: () => Clock; readonly verify: () => Snapshot; readonly nonce: () => string; readonly corpus: Corpus }

export const SAFETY = ['SCHEMA', 'MODEL_TIER', 'USAGE', 'AUTHORITY', 'EGRESS', 'PRIVACY', 'CLAIMS', 'COVERAGE', 'URGENCY', 'CONFIG'] as const;
export type SafetyRow = typeof SAFETY[number];
export interface CaseEvidence {
  readonly correlationId: string | null; readonly ledger: 'BOUND' | 'MISSING' | 'UNBOUND'; readonly reconciliation: 'RECONCILED' | 'UNRECONCILED' | 'UNKNOWN';
  readonly text: 'REQUEST_MATCHED' | 'REQUEST_DEVIATION' | 'OPERATOR_REPORTED_DEVIATION'; readonly reply: 'V2_ANSWER_VALID' | 'ERROR_ENVELOPE_VALID' | 'LOCAL_INVALID' | 'TIMEOUT';
  readonly truth: Omit<Truth, 'pass'> | null; readonly localOutcome: string | null; readonly configFaultAttested: boolean;
}
export type Voluntary = 'NONE' | 'PENDING' | 'CONFIRMED' | 'CONTAINMENT_UNCONFIRMED';
export interface OutcomeInput {
  readonly request: unknown; readonly reply: TransientHttp | 'TIMEOUT'; readonly replyUnparseable?: boolean;
  readonly ledger: LedgerInput | null; readonly configFaultAttested?: boolean;
}

export class ExecutionSession {
  readonly runClass: RunClass; readonly admission: Admission; readonly start: Snapshot;
  readonly #d: SessionDeps; readonly #sup: Supervisor; readonly #consumed = new Set<string>();
  #tuple: Tuple | null = null; #staged: string | null = null; #challenge: { caseId: string; nonce: string } | null = null; #consented: string | null = null;
  #counters: { dayChargedMicro: number; monthChargedMicro: number } | null = null;
  #inFlight: { caseId: string; tuple: Tuple; pre: { dayChargedMicro: number; monthChargedMicro: number }; arrived: Clock | null } | null = null;
  #highestVersion = 0n; #highestFence: bigint; #voluntaryFloor = 0n; #voluntary: Voluntary = 'NONE'; #voluntaryPauses = 0;
  readonly #evidence = new Map<string, CaseEvidence>(); readonly #safety = new Map<SafetyRow, number>(SAFETY.map(s => [s, 0]));
  #compared = 0; #preSubmitChecks = 0; readonly #integrity: string[] = [];

  constructor(deps: SessionDeps, input: AdmissionInput) {
    const start = deps.verify();
    if (!start.ok || start.identity === null) reject('ARTIFACT_IDENTITY_NOT_VERIFIED');
    const v = admissionValues(input);
    const id = start.identity!;
    this.admission = { admissionId: v.admissionId, startUtcMs: v.startUtcMs, expiryUtcMs: v.expiryUtcMs, dayCapMicro: v.dayCapMicro, monthCapMicro: v.monthCapMicro,
      reserveMicro: 300_000, datasetSha256: id.datasetCorpusSha256, fixtureSha256: id.fixtureSha256, orderSha256: id.orderSha256, manualRerunAllowance: 0,
      pacingMax: v.pacingMax, pacingWindowMs: 60_000, openingFenceEpoch: v.openingFenceEpoch };
    const frozen = new Map<string, FrozenCase>([...deps.corpus.cases].map(([k, c]) => [k, { question: c.question, hasFocus: c.hasFocus, fixtureId: c.fixtureId,
      expectedIntent: c.expectedIntent, supportedGroup: c.group.startsWith('SUPPORTED_') ? c.group : null }]));
    try { this.#sup = new Supervisor(this.admission, frozen, deps.corpus.order, () => this.#counters ?? reject('NO_COUNTERS')); }
    catch { throw new ExecError('ADMISSION_INVALID'); }
    this.runClass = deps.runClass; this.start = start; this.#d = deps; this.#highestFence = BigInt(v.openingFenceEpoch);
  }

  get state(): RunState { return this.#sup.state; }
  get closureState(): string { return this.#sup.closure; }
  get voluntary(): Voluntary { return this.#voluntary; }
  get nextCaseId(): string | null { return this.#sup.nextCaseId; }
  get inFlight(): string | null { return this.#inFlight?.caseId ?? null; }
  /** Setup facts of the next case for the operator: IDs and flags only, never the question or its label. */
  nextSetup(): { caseId: string; fixtureId: string; requestedFocus: string | null } | null {
    const id = this.#sup.nextCaseId; if (id === null) return null;
    const c = this.#d.corpus.cases.get(id)!;
    return { caseId: id, fixtureId: c.fixtureId, requestedFocus: this.#d.corpus.fixtures.get(c.fixtureId)!.spec.requestedFocus };
  }
  #ctx(id: string): CaseContext { const frozen = this.#d.corpus.cases.get(id)!; return { frozen, fixture: this.#d.corpus.fixtures.get(frozen.fixtureId)!, scope: this.#d.corpus.scope }; }
  #paused(): boolean { return this.#voluntary !== 'NONE'; }
  #observe(version: string): void { const v = BigInt(version); if (v > this.#highestVersion) this.#highestVersion = v; }
  #clearCase(): void { this.#staged = null; this.#challenge = null; this.#consented = null; }

  /** Manual confirmation of the disclosed tuple; after a voluntary closure it must be strictly newer than that pause. */
  confirmTuple(admissionId: unknown, policyVersion: unknown): string {
    const a = uuid(admissionId, 'ADMISSION_ID_INVALID'); const p = decimal(policyVersion, 'POLICY_VERSION_INVALID');
    if (this.#paused()) return 'BLOCKED_VOLUNTARY_PAUSE';
    if (BigInt(p) <= this.#voluntaryFloor) return 'BLOCKED_NOT_NEWER_THAN_PAUSE';
    const r = this.#sup.confirmCapability({ active: true, admissionId: a, policyVersion: p });
    this.#clearCase();
    if (r === 'CONFIRMED') { this.#tuple = { admissionId: a, policyVersion: p }; this.#observe(p); }
    return r;
  }

  /** Read-only capability observation before EVERY submission (counted in pacing by the supervisor). */
  capability(http: TransientHttp): string {
    if (this.#paused()) return 'BLOCKED_VOLUNTARY_PAUSE';
    const c = checkCapability(http);
    const observed = c.kind === 'ACTIVE' ? { active: true, ...c.tuple } : c.kind === 'INACTIVE' ? { active: false, admissionId: this.admission.admissionId, policyVersion: '' } : 'UNAVAILABLE' as const;
    if (c.kind === 'ACTIVE') this.#observe(c.tuple.policyVersion);
    const r = this.#sup.preflight(this.#d.clock(), observed);
    if (r === 'BLOCKED_VERSION_CHANGED') { this.#tuple = null; this.#clearCase(); }
    return r;
  }

  /** PRE-SUBMISSION gate: exact requested focus (or none) and strict in-memory equality of the pasted text. Consumes nothing. */
  stage(id: unknown, focus: unknown, pasted: unknown): string {
    const caseId = validCaseId(id); const requested = focusId(focus); const text = transientText(pasted, 'PASTE_REJECTED');
    if (this.#paused()) return 'BLOCKED_VOLUNTARY_PAUSE';
    if (!this.#d.corpus.cases.has(caseId)) return 'BLOCKED_UNKNOWN_CASE';
    const c = this.#d.corpus.cases.get(caseId)!;
    const focusOk = requested === this.#d.corpus.fixtures.get(c.fixtureId)!.spec.requestedFocus;
    this.#clearCase();
    // A focus mismatch still goes through the supervisor with a non-matching fixture so ITS staged/consent state is cleared too.
    const r = this.#sup.stage(caseId, text, c.hasFocus, focusOk ? c.fixtureId : '#FOCUS_MISMATCH');
    if (r === 'STAGED') this.#staged = caseId;
    return r;
  }

  /** Fresh one-use challenge for the staged case; consent must echo it, so no pre-written input can consent. */
  consentChallenge(id: unknown): string {
    const caseId = validCaseId(id);
    if (this.#paused() || this.#staged !== caseId || this.#tuple === null) return reject('CONSENT_NOT_AVAILABLE');
    this.#challenge = { caseId, nonce: this.#d.nonce() }; this.#consented = null;
    return this.#challenge.nonce;
  }
  /** Explicit per-question consent: the operator ticked the browser checkbox for THIS question and typed the challenge. */
  consent(id: unknown, typedNonce: unknown, checkboxTickedManually: unknown): string {
    const caseId = validCaseId(id); const challenge = this.#challenge; this.#challenge = null;
    if (checkboxTickedManually !== true || challenge === null || challenge.caseId !== caseId || typedNonce !== challenge.nonce || this.#tuple === null) return 'BLOCKED';
    const r = this.#sup.consent(caseId, this.#tuple);
    if (r === 'CONSENTED') this.#consented = caseId;
    return r;
  }

  /** Current DAY/MONTH accounted spend read immediately before this submission (attested owner read or fake ledger). */
  counters(input: CountersInput): string {
    const c = counterValues(input, { day: this.admission.dayCapMicro, month: this.admission.monthCapMicro });
    if (this.#paused() || this.#inFlight !== null) return 'BLOCKED';
    this.#counters = c;
    return 'RECORDED';
  }

  /** The operator is pressing Ask NOW (first and only submission of this case; latency starts here). */
  submit(id: unknown): string {
    const caseId = validCaseId(id);
    if (this.#consumed.has(caseId)) { this.#integrity.push('DUPLICATE_SUBMISSION'); this.#sup.integrityViolation('DUPLICATE_DISPATCH'); return 'INTEGRITY_DUPLICATE_SUBMISSION'; }
    if (this.#paused()) return 'BLOCKED_VOLUNTARY_PAUSE';
    if (this.#sup.state !== 'ACTIVE' || this.#inFlight !== null) return 'BLOCKED';
    this.#preSubmitChecks += 1;
    if (!sameIdentity(this.start, this.#d.verify())) { this.#integrity.push('ARTIFACT_DRIFT'); this.#sup.integrityViolation('ARTIFACT_DRIFT'); return 'INTEGRITY_ARTIFACT_DRIFT'; }
    if (this.#counters === null) return 'BLOCKED_NO_COUNTERS';
    if (this.#consented !== caseId || this.#tuple === null) return 'BLOCKED_NO_CONSENT';
    const pre = this.#counters;
    const r = this.#sup.submit(this.#d.clock(), caseId, this.#d.corpus.cases.get(caseId)!.question);
    if (r === 'DISPATCH') {
      this.#consumed.add(caseId); this.#inFlight = { caseId, tuple: this.#tuple, pre, arrived: null };
      this.#counters = null; this.#clearCase();
    }
    return r;
  }

  /** Terminal time: the reply (answer or error) became visible. Pasting happens afterwards and is not timed. */
  arrived(id: unknown): string {
    const caseId = validCaseId(id);
    if (this.#inFlight?.caseId !== caseId) return 'BLOCKED_NOT_IN_FLIGHT';
    if (this.#inFlight.arrived !== null) return 'BLOCKED_ALREADY_ARRIVED';
    this.#inFlight.arrived = this.#d.clock();
    return 'RECORDED';
  }

  /** Record the in-flight case. Input errors throw (nothing recorded); afterwards the case is recorded exactly once. */
  outcome(id: unknown, input: OutcomeInput): RunState | 'BLOCKED_NOT_IN_FLIGHT' | 'BLOCKED_NOT_ARRIVED' {
    const caseId = validCaseId(id); const f = this.#inFlight;
    if (f === null || f.caseId !== caseId) return 'BLOCKED_NOT_IN_FLIGHT';
    if (input.reply !== 'TIMEOUT' && f.arrived === null) return 'BLOCKED_NOT_ARRIVED';
    const ctx = this.#ctx(caseId);
    const request = checkRequest(input.request, ctx, f.tuple);
    const observed = input.reply === 'TIMEOUT' ? null : checkResponse(input.reply, ctx, request.requestId, input.replyUnparseable === true);
    const ledger: Ledger | null = input.ledger === null ? null : ledgerValues(input.ledger, { day: this.admission.dayCapMicro, month: this.admission.monthCapMicro });
    // ---- every input validated: from here on nothing throws and the case is recorded exactly once ----
    const correlation = observed !== null && observed.kind !== 'LOCAL_INVALID' ? observed.correlationId : null;
    const bound = ledger !== null && correlation !== null && ledger.correlationId === correlation;
    const reconciled = bound && ledger.monthChargedMicro === f.pre.monthChargedMicro + ledger.chargedMicro && ledger.dayChargedMicro === f.pre.dayChargedMicro + ledger.chargedMicro;
    // Missing, unbound or unreconciled ledger metadata is an UNKNOWN settlement commit: reserve retained, run ends incomplete.
    const settlement: Settlement = bound && reconciled ? ledger.settlement : 'RETAINED_UNKNOWN_COMMIT';
    const commit = !bound || !reconciled || settlement === 'RETAINED_UNKNOWN_COMMIT' ? 'UNKNOWN' as const : ledger.attempts === 0 ? 'NONE' as const : 'KNOWN' as const;
    const configFault = input.configFaultAttested === true && observed?.kind === 'ERROR' && observed.code === 'ASK_REMOTE_UNAVAILABLE';
    let result: Outcome;
    if (observed === null) result = { kind: 'TIMEOUT' };
    else if (observed.kind === 'ANSWER') result = { kind: 'ANSWER', observedIntent: observed.observedIntent, truthPass: observed.truth.pass, publication: 'CURRENT', settlement };
    else result = { kind: 'ERROR', code: observed.kind === 'ERROR' ? observed.code : 'ASK_REMOTE_INVALID', commit, configFaultProven: configFault, settlement };
    if (request.deviation) this.#sup.submittedTextDeviation(caseId);
    this.#sup.outcome(f.arrived ?? this.#d.clock(), caseId, result);
    if (ledger !== null && ledger.attempts >= 2) { this.#integrity.push('DUPLICATE_DISPATCH'); this.#sup.integrityViolation('DUPLICATE_DISPATCH'); }
    this.#tally(observed, configFault);
    this.#evidence.set(caseId, { correlationId: correlation, ledger: ledger === null ? 'MISSING' : bound ? 'BOUND' : 'UNBOUND',
      reconciliation: !bound ? 'UNKNOWN' : reconciled ? 'RECONCILED' : 'UNRECONCILED', text: request.deviation ? 'REQUEST_DEVIATION' : 'REQUEST_MATCHED',
      reply: observed === null ? 'TIMEOUT' : observed.kind === 'ANSWER' ? 'V2_ANSWER_VALID' : observed.kind === 'ERROR' ? 'ERROR_ENVELOPE_VALID' : 'LOCAL_INVALID',
      truth: observed?.kind === 'ANSWER' ? { claims: observed.truth.claims, coverage: observed.truth.coverage, urgency: observed.truth.urgency, schema: observed.truth.schema } : null,
      localOutcome: observed?.kind === 'LOCAL_INVALID' ? observed.outcome : null, configFaultAttested: configFault });
    this.#inFlight = null;
    return this.#sup.state;
  }

  #tally(observed: ReturnType<typeof checkResponse> | null, configFault: boolean): void {
    const hit = (row: SafetyRow): void => { this.#safety.set(row, this.#safety.get(row)! + 1); };
    if (observed === null) return;
    if (observed.kind === 'ANSWER') {
      this.#compared += 1;
      if (!observed.truth.claims) hit('CLAIMS'); if (!observed.truth.coverage) hit('COVERAGE');
      if (!observed.truth.urgency) hit('URGENCY'); if (!observed.truth.schema) hit('SCHEMA');
    } else if (observed.kind === 'LOCAL_INVALID' || observed.code === 'ASK_REMOTE_INVALID') hit('SCHEMA');
    else if (observed.code === 'ASK_REMOTE_MODEL_MISMATCH') hit('MODEL_TIER');
    else if (observed.code === 'ASK_REMOTE_USAGE_INVALID') hit('USAGE');
    else if (configFault) hit('CONFIG');
  }

  /** Operator-observed post-submission deviation (e.g. edited after the gate): consumed CASE_FAIL, nothing resent. */
  deviation(id: unknown): string {
    const caseId = validCaseId(id);
    const r = this.#sup.submittedTextDeviation(caseId);
    const e = this.#evidence.get(caseId);
    if (r === 'RECORDED' && e) this.#evidence.set(caseId, { ...e, text: 'OPERATOR_REPORTED_DEVIATION' });
    return r;
  }

  /** Owner fence-first closure receipt (attested values). Invalid/stale/foreign → CONTAINMENT_UNCONFIRMED, permanently. */
  closure(input: ClosureInput): string {
    const paused = input.paused === 'true' ? true : input.paused === 'false' ? false : input.paused;
    const wrapperOk = input.admissionId === this.admission.admissionId && paused === true && /^[1-9][0-9]{0,18}$/.test(String(input.policyVersion))
      && /^[1-9][0-9]{0,18}$/.test(String(input.fenceEpoch)) && BigInt(input.policyVersion) > this.#highestVersion && BigInt(input.fenceEpoch) > this.#highestFence;
    if (this.#voluntary === 'PENDING') {
      this.#voluntary = wrapperOk ? 'CONFIRMED' : 'CONTAINMENT_UNCONFIRMED';
      if (wrapperOk) this.#raiseFloors(input);
      return this.#voluntary;
    }
    if (this.#sup.closure !== 'PENDING') return 'BLOCKED_NO_CLOSURE_PENDING';
    const r = this.#sup.close({ admissionId: input.admissionId, paused: paused as boolean, policyVersion: input.policyVersion, fenceEpoch: input.fenceEpoch });
    if (r === 'CONFIRMED' && wrapperOk) this.#raiseFloors(input);
    return r === 'CONFIRMED' && !wrapperOk ? 'CONFIRMED_SUPERVISOR_ONLY' : r;
  }
  #raiseFloors(input: ClosureInput): void {
    this.#highestVersion = BigInt(input.policyVersion); this.#highestFence = BigInt(input.fenceEpoch); this.#voluntaryFloor = this.#highestVersion;
  }

  /** Manual DAY resume through the supervisor, with the CURRENT artifact identity (drift denies). */
  resumeDay(): string {
    const now = this.#d.verify();
    if (!sameIdentity(this.start, now)) return 'RESUME_DENIED_ARTIFACT';
    const r = this.#sup.resume(this.#d.clock(), { admissionId: this.admission.admissionId, datasetSha256: now.identity!.datasetCorpusSha256,
      fixtureSha256: now.identity!.fixtureSha256, orderSha256: now.identity!.orderSha256 });
    if (r === 'RESUMED') { this.#tuple = null; this.#clearCase(); }
    return r;
  }
  /** Voluntary pause between cases: needs its own fence-first closure; never resumes by itself. */
  voluntaryPause(): string {
    if (this.#paused() || this.#sup.state !== 'ACTIVE' || this.#inFlight !== null) return 'BLOCKED';
    this.#voluntary = 'PENDING'; this.#voluntaryPauses += 1; this.#tuple = null; this.#clearCase();
    return 'PAUSED_CLOSURE_PENDING';
  }
  resumeVoluntary(now: Clock = this.#d.clock()): string {
    if (this.#voluntary !== 'CONFIRMED') return 'RESUME_DENIED_CONTAINMENT';
    if (now.utcMs >= this.admission.expiryUtcMs) return 'RESUME_DENIED_EXPIRED';
    if (!sameIdentity(this.start, this.#d.verify())) return 'RESUME_DENIED_ARTIFACT';
    this.#voluntary = 'NONE';
    return 'RESUMED_CONFIRM_NEWER_TUPLE';
  }

  /** Safe data for the receipt builder: supervisor report plus wrapper evidence (no transient content exists here). */
  facts(): { report: Record<string, unknown>; evidence: ReadonlyMap<string, CaseEvidence>; safety: ReadonlyMap<SafetyRow, number>; compared: number;
    preSubmitChecks: number; integrity: readonly string[]; voluntary: Voluntary; voluntaryPauses: number } {
    return { report: this.#sup.report(), evidence: new Map(this.#evidence), safety: new Map(this.#safety), compared: this.#compared,
      preSubmitChecks: this.#preSubmitChecks, integrity: [...this.#integrity], voluntary: this.#voluntary, voluntaryPauses: this.#voluntaryPauses };
  }
}

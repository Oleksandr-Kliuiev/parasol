# ASK-REMOTE R-EVAL — local execution instrument (preparation)

Status 2026-10-11: **LOCAL PREPARATION ONLY. Live admission BLOCKED.** Data/budget NOT_ADMITTED, paid product calls 0,
labels DRAFT_MODEL_ASSISTED, human attestation PENDING, independent Sol6.1/xhigh + Opus5.5/xhigh acceptance PENDING.
Normative basis: `../S5ASKREMOTE_REVAL_PLAN.md` (RC6) and `../S5ASKREMOTE_REVAL_ADMISSION.md`; accepted offline package
`../eval/` (S5ASKREMOTE-REVAL-OFFLINE-rc3). Nothing in this instrument changes product code, contracts, data or norms.

## What it is

A local supervisor/measurement/assertion tool for the future MANUAL run. It moves beyond the accepted simulated model:
it ingests typed operator actions and transient V2 values, validates them with the ACCEPTED validators, keeps exact
frozen-question/focus equality in memory, compares every validated answer with the frozen fixture for the OBSERVED intent
(independently of the expected label), enforces the RC6 procedural rules and emits only an allowlisted safe receipt.
It never sends a request, consents, submits, retries or schedules; the operator acts in the accepted browser V2 console.

```
node --experimental-strip-types scripts/ask-remote-eval-execution/cli.ts artifact-check
node --experimental-strip-types scripts/ask-remote-eval-execution/cli.ts rehearse [--write-receipt]
node --experimental-strip-types scripts/ask-remote-eval-execution/cli.ts session --receipt-dir <existing dir>
node --experimental-strip-types --test tests/ask-remote-eval-execution-*.test.ts
```
Exit 0 ok, 1 check failed, 2 usage. There is no `--live`, key, env or paid path. `session` refuses a non-TTY stdin/stdout.

| Part | Behaviour |
|---|---|
| Identity | Pinned SHA-256 of the offline RC3 and R-C RC1 manifests; re-hash of all listed source/build files (1583), dataset manifest/order (seed `S5ASKREMOTE-REVAL-ORDER-v1`, all 200 holdout), tool/comparator/validator/projection hashes. At start and before EVERY submission; drift → TERMINAL_FAILED. Six declared administrative routing/status overlays (root AGENTS, AI_CONTEXT_MAP, DEVELOPMENT_WORKFLOW, three Stage 5 status files) are pinned at their EXACT current SHA-256 (`ADMIN_OVERLAYS`); a historical-manifest mismatch is accepted only at those bytes, any other bytes are `ADMIN_OVERLAY_DRIFT`, and the pinned table's digest `adminOverlaySha256` is part of the identity (never re-sampled). |
| Procedure core | The accepted `supervisor.ts` unchanged (absorbing terminals, consumed-first, pacing ≤10/60 s counting preflight+submit, DAY resume next UTC day after confirmed closure, MONTH/expiry/unknown commit/loss of authority terminal, any UNAVAILABLE terminal, INVALID/model/usage FAILED, stop-on-certain-failure ≥24/25 per group, 100/100 refusal, ≥190 validated). |
| Added rules | Duplicate submission of a consumed case = permanent integrity failure; per-case one-use random consent challenge plus explicit checkbox attestation; numeric counters required before each submit; ledger metadata bound to the reply correlation UUID and reconciled with the pre-submit counters, else UNKNOWN commit (reserve retained, run INCOMPLETE); voluntary pause needs its own fence-first closure and never resumes by itself. |
| Transient evidence | Request: accepted strict JSON + `askRemoteRequest`; question/focus/tuple deviation → consumed CASE_FAIL. Reply: browser `validateRemoteAnswer`/`validateAskError` (whole answer) BEFORE any boolean; failure → SCHEMA, TERMINAL_FAILED. Then `checkAnswer` (accepted independent comparator, original fixture rows) → CLAIMS/COVERAGE/URGENCY/SCHEMA booleans. Wrong but grounded intent = semantic fail only. |
| Latency | Monotonic `submit` → `arrived` keystrokes (operator-bracketed, includes reaction time), nearest-rank p50/p95/max with explicit n; timeouts censored separately; denominator 200. |
| Receipt | Exact key/enum/pattern allowlist + accepted offline scan (no question, rationale, forbidden key). Case ID, outcome enum, MATCH/MISMATCH, pass, duration, liability, correlation UUID, ledger/reconciliation/text/reply enums, truth booleans. Never question, hash/length, bodies, raw answer or observed intent. `liveAcceptanceEligible:false`, `liveAdmissionReadiness:BLOCKED` are schema constants. |

## Operator session (future manual use; still UNADMITTED)

`admission` (attested values; creates an exclusive per-admission lock in the receipt dir, so a restarted process cannot
reuse case IDs) → `confirm <admissionId> <policyVersion>` → per case: `counters`, `capability` (paste of the reply = preflight),
`next`, `stage` (requested focus + echo-off paste of the question), tick the browser checkbox, `consent` (type the shown
challenge), `submit <caseId>` at the moment of clicking Ask, `arrived` when the reply is visible, `outcome` (paste request
body and reply, then the owner-read ledger numbers). `closure`, `pause`, `resume-day`, `resume-pause`, `export`, `quit`.
The safe receipt is rewritten after each outcome/closure. A crash loses in-memory state: treat the run as INCOMPLETE and
close it fence-first; the lock prevents a silent restart.

Privacy boundary: pastes are read in raw mode with echo OFF and kept in one call's locals; they are NOT hidden from the
clipboard, devtools, screen recording or terminal multiplexers. Never paste questions/bodies into a shell command, history,
file or log. The tool never prints a question; the operator obtains it from the restricted dataset by their own procedure.
Copy only the single request/response from the devtools response view; never save HAR, never "Copy as cURL" (bearer token).
A TTY and the consent challenge resist casual piping, not a determined pty driver: operator identity stays ATTESTED.

## Feasibility against the accepted V2 boundary — missing contracts (named, not built)

The public V2 surface exposes only capability tuple, AskAnswerV2/AskErrorV1 and correlation IDs. A live acceptance needs
contracts that do not exist and are NOT created here (product/authority/data changes are out of scope):

| Blocker | What is missing |
|---|---|
| `LEDGER_METADATA_READ_CONTRACT_MISSING` | Accepted read-only owner path: attempt count, settlement state, charged micro-USD, DAY/MONTH counters per correlation |
| `CLOSURE_RECEIPT_READ_CONTRACT_MISSING` | Accepted owner fence-first pause receipt `{admissionId, paused, policyVersion, fenceEpoch}` export |
| `FIXTURE_DB_PROVISIONING_CONTRACT_MISSING` | Provisioning of the 11 frozen fixtures into the synthetic DB (all share one client scope) and proof DB = fixture |
| `TRANSIENT_RESPONSE_HANDOFF_CONTRACT_MISSING` | Reviewed browser→instrument handoff; manual devtools copy is attested, not server-bound |
| `SERVER_PROCESS_IDENTITY_UNVERIFIED` | Proof that the running server loaded the verified build |
| `EGRESS_PLATFORM_PROOF_ABSENT`, `PRIVACY_SCAN_NOT_MEASURED` | Platform allowlist evidence; before/after destination scan |
| `OPERATOR_IDENTITY_ATTESTED_ONLY`, `HUMAN_LABEL_ATTESTATION_PENDING`, `OWNER_DATA_BUDGET_ADMISSION_ABSENT`, `EXECUTION_ARTIFACT_ACCEPTANCE_PENDING` | Identity, human labels, owner admission, independent acceptance of this artifact |

Every safety row therefore reports `countsAsVerifiedZero:false`: UNKNOWN is never zero. Accepted validators show POTENTIAL
enforcement, not an observed run. Live per-case replay is `UNVERIFIABLE_UNDER_PRIVACY_CONTRACT` (booleans cannot replay a
raw answer that may not be stored); only the offline rehearsal replay is verified. A future admitted run needs a separately
accepted tool revision bound to the admitted manifest plus the contracts above; no flag in this version can mark it admitted.

## Offline fake-V2 rehearsal

`rehearse` plays 30 scripted scenarios (X01–X30: full 200 + closure, text/focus gate, post-submit deviation, duplicate
submission, DAY resume, MONTH cap, UNAVAILABLE ±config fault, INVALID/model/usage, altered fact, V2 validator reject, grounded
wrong intent, truthful refusal mismatch, missing/unbound ledger, deadline/busy continue, timeout, concurrent 409, inactive
preflight, version change, stale closure, voluntary pause, drift, ledger duplicate, pacing, consent challenge, settlement
known/unknown, expiry) through the SAME session class with a fake server/ledger/clock, then repeats everything and requires
byte-identical results. The fake returns the DRAFT label and accepted compiler output: it proves measurement/assertion
integration, never provider semantics, server authority, fence or ledger behaviour (`semanticEvaluation:false`).

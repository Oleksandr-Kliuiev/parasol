import { randomUUID } from 'node:crypto';
import { fstatSync } from 'node:fs';
import { Socket } from 'node:net';
import pg from 'pg';
import { Channel } from '../../../../packages/reval/channel.ts';
import { APPLICATION_NAME, authorize, NOT_IMPLEMENTED, SERVER_INNER_ACK_REF } from '../../../../packages/reval/codes.ts';
import type { FailureCode, Kind } from '../../../../packages/reval/codes.ts';
import { buildResponse, decodeRequest, ResponderState } from '../../../../packages/reval/envelope.ts';
import type { Request } from '../../../../packages/reval/envelope.ts';
import { METADATA_FRAME_CAP, PRIVATE_FRAME_CAP } from '../../../../packages/reval/frame.ts';
import { nodePhysicalDeps, verifyPhysicalEndpoint } from '../../../../packages/reval/physical.ts';
import type { Observed, QueryClient } from '../../../../packages/reval/physical.ts';
import { CHILD_HELLO_V1, decodeServerLaunch, SERVER_BOUND_V1 } from '../../../../packages/reval/private-frames.ts';
import type { ServerLaunch } from '../../../../packages/reval/private-frames.ts';
import { readSecretFile } from '../../../../packages/reval/secret-file.ts';

/**
 * R-EVAL RS-A server bridge (docs/stage5/ask/remote/reval-server/rs-a/IMPLEMENTATION_BRIEF.md §2e/§3). Active ONLY when the
 * controller launched this API with ATLAS_REVAL_BRIDGE_FD=3; otherwise main.ts never loads it into use. Order: refuse any
 * other mode (db only, Ask OFF, no operator UI, no ATLAS_RUNTIME_DATABASE_URL, fd 3 a socket) → HELLO first (no credential,
 * no DB) → the controller's launch frame → read the closed runtime password → physical binding over the unix socket →
 * the runtime URL composed IN MEMORY for connectRuntimeDatabase(url) (never written to env) → RevalServerBoundV1 from this
 * process's own query → answer verified IDENTITY seq1 and seq2 → only then main.ts listens. Bridge loss exits immediately.
 */
export const BRIDGE_EXIT = Object.freeze({ REFUSED: 40, CONTROLLER_LOST: 41, LAUNCH: 42 });
/**
 * The environment exactly as the controller supplied it, captured when this module is evaluated: main.ts imports the
 * bridge FIRST, before @prisma/client, whose import loads a checkout `.env` into process.env. The URL-absence check applies
 * to this parent-supplied snapshot (the env URL is never used in bridge mode); Ask/UI must be off in BOTH snapshots so a
 * file-injected value cannot switch them on.
 */
const LAUNCH_ENV: Readonly<Record<string, string | undefined>> = Object.freeze({ ...process.env });
const off = (env: Readonly<Record<string, string | undefined>>) =>
  (env.ATLAS_ASK_MODE === undefined || env.ATLAS_ASK_MODE === 'off') && env.ATLAS_OPERATOR_UI === undefined;
export interface BridgeDeps {
  readSecret(path: string): Promise<Buffer>;
  /** Physical binding + connect as the runtime role (production: unix socket only). */
  verify(launch: ServerLaunch, password: string): Promise<{ client: QueryClient; observed: Observed }>;
  /** The runtime URL handed to connectRuntimeDatabase (production: the same unix socket endpoint). */
  runtimeUrl(launch: ServerLaunch, password: string): string;
}
const unixUrl = (l: ServerLaunch, password: string): string =>
  `postgresql://${encodeURIComponent(l.runtimeRole)}:${encodeURIComponent(password)}@localhost:${l.endpoint.port}/${encodeURIComponent(l.endpoint.database)}`
  + `?host=${encodeURIComponent(l.endpoint.socketDir)}&application_name=${APPLICATION_NAME.runtime}`;
export function productionBridgeDeps(): BridgeDeps {
  const physical = nodePhysicalDeps(async o => { const c = new pg.Client(o); await c.connect(); return c as unknown as QueryClient; });
  return {
    readSecret: readSecretFile,
    verify: (l, password) => verifyPhysicalEndpoint({ endpoint: l.endpoint, physical: l.physical, role: l.runtimeRole,
      applicationName: APPLICATION_NAME.runtime, connectTimeoutMs: 2000 }, password, physical),
    runtimeUrl: unixUrl,
  };
}
const ZERO = '0'.repeat(64);

export class RevalBridge {
  readonly runtimeUrl: string;
  private readonly channel: Channel; private readonly launch: ServerLaunch; private readonly observed: Observed;
  private bindingClient: QueryClient | null;
  private readonly startedAt = new Date().toISOString();
  private constructor(channel: Channel, launch: ServerLaunch, verified: { client: QueryClient; observed: Observed }, url: string) {
    this.channel = channel; this.launch = launch; this.observed = verified.observed; this.bindingClient = verified.client; this.runtimeUrl = url;
  }
  /** Validates the bridge-only mode, sends HELLO, receives the launch frame and binds the runtime database physically. */
  static async start(env: Readonly<Record<string, string | undefined>> = LAUNCH_ENV, deps: BridgeDeps = productionBridgeDeps()): Promise<RevalBridge> {
    let socket = false;
    try { socket = fstatSync(3).isSocket(); } catch { socket = false; }
    if (env.ATLAS_REVAL_BRIDGE_FD !== '3' || env.ATLAS_MODE !== 'db' || process.env.ATLAS_MODE !== 'db' || !off(env) || !off(process.env)
      || env.ATLAS_RUNTIME_DATABASE_URL !== undefined || !socket) process.exit(BRIDGE_EXIT.REFUSED);
    const channel = new Channel(new Socket({ fd: 3, readable: true, writable: true }), PRIVATE_FRAME_CAP);
    channel.onClose(e => { if (e.reason !== 'LOCAL') process.exit(BRIDGE_EXIT.CONTROLLER_LOST); });
    channel.send({ contractVersion: CHILD_HELLO_V1, kind: 'SERVER', helloNonce: randomUUID() });
    try {
      const launch = decodeServerLaunch(await channel.next(2000));
      const secret = await deps.readSecret(launch.runtimeSecretFile);
      const password = secret.toString('latin1'); secret.fill(0);
      const verified = await deps.verify(launch, password);
      return new RevalBridge(channel, launch, verified, deps.runtimeUrl(launch, password));
    } catch { process.exit(BRIDGE_EXIT.LAUNCH); }
  }
  /** After the runtime readiness passed: report the bound tuple, answer IDENTITY seq1 and seq2, then keep answering. */
  async bindAndAwaitOpen(): Promise<void> {
    const l = this.launch;
    const state = new ResponderState({ registrationId: l.registrationId, serverBootId: l.serverBootId, connectionId: l.connectionId });
    try {
      this.channel.send({ contractVersion: SERVER_BOUND_V1, launchChallenge: l.launchChallenge, serverBootId: l.serverBootId, observed: this.observed });
      this.channel.switchCap(METADATA_FRAME_CAP);
      for (let i = 0; i < 2; i += 1) {
        const d = decodeRequest(await this.channel.next(5000));
        if (!d.ok || state.check(d.request) !== null || d.request.operation !== 'IDENTITY') throw new Error('open');
        this.respond(state, d.request, 'IDENTITY', this.identity());
      }
    } catch { process.exit(BRIDGE_EXIT.LAUNCH); }
    await this.bindingClient?.end().catch(() => undefined); this.bindingClient = null;
    void this.serve(state);
  }
  private identity() {
    return { databaseInstanceId: this.launch.databaseInstanceId, buildManifestSha256: ZERO, runtimeImageSha256: ZERO, launcherManifestSha256: ZERO,
      platformEvidenceRef: SERVER_INNER_ACK_REF, loadedBinding: 'UNVERIFIED', startedAt: this.startedAt };
  }
  private respond(state: ResponderState, r: { challenge: string; sequence: string }, kind: Kind, payload: unknown): void {
    this.channel.send(buildResponse(state.binding, r, state.send.take(), 'SERVER', this.launch.databaseInstanceId, kind, payload, new Date().toISOString()));
  }
  /** Later C→S requests: IDENTITY answered; every other operation fail-closed with its fixed code (no side effect). */
  private async serve(state: ResponderState): Promise<void> {
    for (;;) {
      let value: unknown;
      try { value = await this.channel.next(); } catch { process.exit(BRIDGE_EXIT.CONTROLLER_LOST); }
      const d = decodeRequest(value);
      if (!d.ok) { if (d.addressable) this.respond(state, d.addressable, 'FAILURE', { code: 'PROTOCOL_INVALID' }); this.channel.close(); process.exit(BRIDGE_EXIT.CONTROLLER_LOST); }
      const r: Request = d.request;
      const problem: FailureCode | null = state.check(r) ?? authorize('C', 'S', r.operation) ?? NOT_IMPLEMENTED[r.operation] ?? null;
      if (problem) this.respond(state, r, 'FAILURE', { code: problem }); else this.respond(state, r, 'IDENTITY', this.identity());
    }
  }
}

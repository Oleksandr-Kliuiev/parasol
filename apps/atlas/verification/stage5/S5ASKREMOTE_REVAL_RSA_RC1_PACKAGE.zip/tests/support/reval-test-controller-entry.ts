// TEST-ONLY controller entry (R-EVAL RS-A launch test): the production controller with the Docker TCP seam. Its test JSON is
// `<owner config dir>/test.json` (test-only). At first JS entry it probes its inherited descriptors; it then opens SENTINEL
// handles (config, secret, a listening socket, a DB socket) that its children S/E must never inherit (leak test).
import { appendFileSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { probeDescriptors } from './reval-test-deps.ts';
import type { TestTcp } from './reval-test-deps.ts';

const configPath = process.env.ATLAS_REVAL_CONFIG!;
const testJson = join(dirname(configPath), 'test.json');
const t = JSON.parse(readFileSync(testJson, 'utf8')) as TestTcp & { alterPidversionAfter?: number; sentinelFile?: string; secretLog?: string; controllerFdProbe?: string;
  skewAfterStartupWrapperMs?: number };
if (t.controllerFdProbe) writeFileSync(t.controllerFdProbe, JSON.stringify({ role: 'C', pid: process.pid, env: Object.keys(process.env).sort(), fds: probeDescriptors() }));
const { spawn } = await import('node:child_process');
const { createServer, createConnection } = await import('node:net');
const { fstatSync } = await import('node:fs');
const { fileURLToPath } = await import('node:url');
const { createController, productionDeps } = await import('../../packages/reval/controller.ts');
const { tcpVerify, TEST_PLATFORM_REF } = await import('./reval-test-deps.ts');
const { APPLICATION_NAME } = await import('../../packages/reval/codes.ts');
const { PHYSICAL_QUERY } = await import('../../packages/reval/physical.ts');

// Sentinels held by C at every child spawn.
const sentinels: { kind: string; dev: number; ino: number; port?: number }[] = [];
const hold = (kind: string, fd: number) => { const st = fstatSync(fd); sentinels.push({ kind, dev: st.dev, ino: st.ino }); };
hold('config-file', openSync(configPath, 'r'));
const secretDir = join(dirname(configPath), 'secrets');
hold('secret-file', openSync(join(secretDir, 'reader'), 'r'));
const listener = createServer(); await new Promise<void>(r => listener.listen(0, '127.0.0.1', r));
hold('listening-socket', (listener as unknown as { _handle: { fd: number } })._handle.fd);
sentinels[sentinels.length - 1]!.port = (listener.address() as { port: number }).port;
const dbSock = createConnection({ host: t.host, port: t.port }); await new Promise(r => dbSock.once('connect', r));
hold('db-socket', (dbSock as unknown as { _handle: { fd: number } })._handle.fd);
if (t.sentinelFile) writeFileSync(t.sentinelFile, JSON.stringify(sentinels));

const serverEntry = fileURLToPath(new URL('./reval-test-server-entry.ts', import.meta.url));
const execEntry = fileURLToPath(new URL('./reval-test-exec-entry.ts', import.meta.url));
const base = productionDeps();
let childProofs = 0;
// Test clock skew: after the FIRST snapshot transaction commits (the startup wrapper), C's monotonic clock jumps ahead.
let skew = 0; let commits = 0;
await createController({
  ...base,
  platformRef: TEST_PLATFORM_REF,
  now: () => base.now() + skew,
  readSecret: async path => { if (t.secretLog) appendFileSync(t.secretLog, `${path}\n`); return base.readSecret(path); },
  connectReader: async (config, password) => {
    const r = await tcpVerify(t, config.endpoint, config.physical, config.roles.reader, password, APPLICATION_NAME.reader);
    if (t.skewAfterStartupWrapperMs === undefined) return r;
    const query = r.client.query.bind(r.client);
    r.client.query = async (sql: string, params?: unknown[]) => { const out = await query(sql, params); if (sql === 'COMMIT' && ++commits === 1) skew = t.skewAfterStartupWrapperMs!; return out; };
    return r;
  },
  recheckReader: async (config, client) => {
    const row = (await client.query(PHYSICAL_QUERY)).rows[0];
    return !!row && row.system_identifier === config.physical.systemIdentifier && row.database_oid === config.physical.databaseOid && row.session_user === config.roles.reader;
  },
  peer: async (helper, channel, exe) => {
    const f = await base.peer(helper, channel, exe);
    if (channel !== 3 && t.alterPidversionAfter !== undefined && ++childProofs > t.alterPidversionAfter) return { ...f, pidversion: f.pidversion + 1 };
    return f;
  },
  spawnServer: config => spawn(process.execPath, [serverEntry, testJson], { stdio: ['ignore', 'ignore', 'ignore', 'pipe'],
    env: { ATLAS_MODE: 'db', ATLAS_API_PORT: String(config.server.port), ATLAS_REVAL_BRIDGE_FD: '3' } }),
  spawnExecutor: () => spawn(process.execPath, [execEntry, testJson], { stdio: ['ignore', 'ignore', 'ignore', 'pipe'], env: {} }),
}).run();

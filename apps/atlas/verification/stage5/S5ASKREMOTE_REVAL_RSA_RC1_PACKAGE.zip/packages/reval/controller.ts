import { authorize, CONTROLLER_EXIT, NOT_IMPLEMENTED } from './codes.ts';
import type { FailureCode, Kind } from './codes.ts';
import { Channel } from './channel.ts';
import { BUDGET_MS } from './closure.ts';
import type { OwnerConfig } from './config.ts';
import type { ControllerDeps } from './deps.ts';
import { buildResponse, decodeRequest, ResponderState } from './envelope.ts';
import type { Request } from './envelope.ts';
import { FrameError, METADATA_FRAME_CAP } from './frame.ts';
import type { Digests } from './launch.ts';
import { pauseExport, reapExecutor } from './pause.ts';
import type { PauseContext } from './pause.ts';
import { parentPeerOk } from './peer.ts';
import type { Observed, QueryClient } from './physical.ts';
import { exportSnapshot, readSnapshotWrapper, ReaderFailure, wrapperBound } from './snapshot-reader.ts';
import { isAbsPath, isUuid } from './scalars.ts';
import { ServerLink } from './server-link.ts';
export { productionDeps } from './deps.ts';

/**
 * The resident controller C (brief §2a): (1) platform/helper gate; (2) on O's FIRST frame, the actual Darwin peer proof of
 * O on the inherited fd 3; (3) source/build digests; (4) reader connection with physical binding; (5) a successful bound
 * snapshot wrapper (registration, binding, build) — only then (6) S per server.mode. Only the platform/helper gate (1) and
 * the peer proof (2) end with the brief's fixed local exits 10/11/12 (no response can be authenticated before them; a launch
 * env or config without a verifiable helper pin fails the helper gate). After the peer proof, a failure of (3)–(5) is an
 * authenticated FAILURE response like SNAPSHOT's — REGISTRATION_MISMATCH, the reader's own code, or DEADLINE past the first
 * budget — repeated for every implemented operation of the session, and S is never launched. Then one 06 request at a
 * time, each within the 1800 ms budget. O EOF ends the session (E killed, S stopped, everything reaped).
 */
export function createController(deps: ControllerDeps): { run(): Promise<never> } {
  return { run: () => runController(deps) };
}
type Reader = { client: QueryClient; observed: Observed };

async function runController(deps: ControllerDeps): Promise<never> {
  const env = deps.env;
  const configPath = env.ATLAS_REVAL_CONFIG; const connectionId = env.ATLAS_REVAL_CONNECTION_ID; const serverBootId = env.ATLAS_REVAL_SERVER_BOOT_ID;
  if (deps.platform !== 'darwin' || deps.arch !== 'arm64') return deps.exit(CONTROLLER_EXIT.PLATFORM);
  if (!isAbsPath(configPath) || !isUuid(connectionId) || !isUuid(serverBootId)) return deps.exit(CONTROLLER_EXIT.HELPER);
  let config: OwnerConfig;
  try { config = await deps.loadConfig(configPath); } catch { return deps.exit(CONTROLLER_EXIT.HELPER); }
  try { await deps.verifyHelper(config.nativePeerHelper, config.nativePeerHelperSha256); await deps.warmHelper(config.nativePeerHelper); }
  catch { return deps.exit(CONTROLLER_EXIT.HELPER); }

  const owner = new Channel(deps.ownerSocket(), METADATA_FRAME_CAP);
  let first: unknown;
  try { first = await owner.next(); } catch { return deps.exit(0); }
  const t0 = deps.now();
  // (2) O wrote: the token now names O. Exact parent, same euid, expected exe, O has a TTY, C has none, parent unchanged.
  const parent = deps.ppid();
  const facts = await deps.peer(config.nativePeerHelper, 3, deps.nodeRealpath).catch(() => null);
  if (!facts || !parentPeerOk(facts, parent) || deps.ppid() !== parent || deps.ttyAvailable()) return deps.exit(CONTROLLER_EXIT.PEER);

  // (3)–(5) within the first operation's budget. After the peer proof a failure is an authenticated FAILURE (approved codes).
  let reader: Reader | null = null; let digests: Digests;
  const deadline0 = t0 + BUDGET_MS;
  const startup = async (): Promise<FailureCode | null> => {
    try { digests = await deps.digests(config); } catch { return 'REGISTRATION_MISMATCH'; }
    if (config.server.mode === 'LAUNCH' && digests.apiEntry !== config.server.apiEntry) return 'REGISTRATION_MISMATCH';
    try { reader = await connectReader(deps, config); } catch { return 'REGISTRATION_MISMATCH'; }
    try {
      const w = await readSnapshotWrapper(reader.client, deadline0, () => deps.now());
      if (!wrapperBound(w, { ...config, buildManifestSha256: digests.buildManifestSha256 })) return 'REGISTRATION_MISMATCH';
    } catch (error) { return error instanceof ReaderFailure ? error.code : 'REGISTRATION_MISMATCH'; }
    return deps.now() > deadline0 ? 'DEADLINE' : null;
  };
  const startupFailure = await startup();
  if (startupFailure) { await (reader as Reader | null)?.client.end().catch(() => undefined); reader = null; }

  const server = !startupFailure && config.server.mode === 'LAUNCH' ? new ServerLink(deps, config, serverBootId, () => reader) : null;
  const state = new ResponderState({ registrationId: config.registrationId, serverBootId, connectionId });
  const pause: PauseContext = { deps, config, latched: false, spawns: 0, lastChild: null,
    reread: async deadline => {
      const r = await ensureReader();
      const w = await readSnapshotWrapper(r.client, deadline, () => deps.now());
      return wrapperBound(w, { ...config, buildManifestSha256: digests.buildManifestSha256 }) ? w : null;
    } };
  let readerDirty = false;
  const reaping = new Set<Promise<boolean>>();
  async function ensureReader(): Promise<Reader> {
    if (reader && !readerDirty) return reader;
    await reader?.client.end().catch(() => undefined);
    reader = null; reader = await connectReader(deps, config); readerDirty = false;
    return reader;
  }
  const respond = (r: { challenge: string; sequence: string }, kind: Kind, payload: unknown, closeAfter = false): void => {
    try {
      owner.send(buildResponse(state.binding, r, state.send.take(), 'CONTROLLER', config.databaseInstanceId, kind, payload, deps.wallIso()));
    } catch (error) {
      if (error instanceof FrameError) owner.send(buildResponse(state.binding, r, state.send.take(), 'CONTROLLER', config.databaseInstanceId, 'FAILURE',
        { code: 'CENSUS_LIMIT_EXCEEDED' }, deps.wallIso()));
    }
    if (closeAfter) owner.close();
  };
  const failure = (r: { challenge: string; sequence: string }, code: FailureCode, closeAfter = false) => respond(r, 'FAILURE', { code }, closeAfter);

  async function handle(r: Request, start: number): Promise<void> {
    const deadline = start + BUDGET_MS;
    const refused = authorize('O', 'C', r.operation);
    if (refused) return failure(r, refused);
    const notImplemented = NOT_IMPLEMENTED[r.operation];
    if (notImplemented) return failure(r, notImplemented);
    if (startupFailure) return failure(r, startupFailure);
    if (r.operation === 'IDENTITY') {
      if (!server) return failure(r, 'IDENTITY_UNVERIFIED');
      const rd = await ensureReader().catch(() => null);
      if (!rd || !await deps.recheckReader(config, rd.client).catch(() => false)) { readerDirty = true; server.kill(); return failure(r, 'IDENTITY_UNVERIFIED'); }
      const problem = await server.identity(deadline);
      if (problem || !server.facts) return failure(r, problem ?? 'IDENTITY_UNVERIFIED');
      const startedAt = new Date(server.facts.startSec * 1000 + Math.floor(server.facts.startUsec / 1000)).toISOString();
      return respond(r, 'IDENTITY', { databaseInstanceId: config.databaseInstanceId, buildManifestSha256: digests.buildManifestSha256,
        runtimeImageSha256: digests.runtimeImageSha256, launcherManifestSha256: digests.launcherManifestSha256, platformEvidenceRef: deps.platformRef,
        loadedBinding: 'UNVERIFIED', startedAt });
    }
    if (r.operation === 'SNAPSHOT') {
      try {
        const rd = await ensureReader();
        const w = await readSnapshotWrapper(rd.client, deadline - 50, () => deps.now());
        if (!wrapperBound(w, { ...config, buildManifestSha256: digests.buildManifestSha256 })) return failure(r, 'REGISTRATION_MISMATCH');
        return respond(r, 'SNAPSHOT', exportSnapshot(w, config.approvedPriceRevision));
      } catch (error) {
        if (error instanceof ReaderFailure) { if (error.code === 'CENSUS_UNAVAILABLE') readerDirty = true; return failure(r, error.code); }
        readerDirty = true; return failure(r, 'REGISTRATION_MISMATCH');
      }
    }
    // PAUSE_EXPORT
    const p = r.payload as { admissionId: string; expectedPolicyVersion: string; policyFloor: string; fenceFloor: string };
    const decision = await pauseExport(pause, p, start);
    if (decision.kind === 'CLOSURE') respond(r, 'CLOSURE', decision.closure); else failure(r, decision.code);
    // Cleanup is bounded separately AFTER the response (brief §6) and never holds the responder.
    reaping.add(reapExecutor(pause.lastChild).finally(() => reaping.clear()));
  }

  // One request at a time; a request arriving while busy gets OPERATION_BUSY (its sequence is consumed).
  const process1 = async (value: unknown, received: number): Promise<void> => {
    const d = decodeRequest(value);
    if (!d.ok) { if (d.addressable) failure(d.addressable, 'PROTOCOL_INVALID', true); else owner.close(); return; }
    const problem = state.check(d.request);
    if (problem === 'OPERATION_BUSY') return failure(d.request, problem);
    if (problem) return failure(d.request, problem, true);
    state.busy = true;
    try { await handle(d.request, received); } catch { failure(d.request, 'INTERNAL_FAILURE'); } finally { state.busy = false; }
  };
  let current: Promise<void> = process1(first, t0);
  const shutdown = async (): Promise<never> => {
    await current.catch(() => undefined);
    await Promise.all(reaping);
    const child = pause.lastChild;
    if (child && child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
    await reapExecutor(child);
    await server?.stop(5000);
    await (reader as Reader | null)?.client.end().catch(() => undefined);
    return deps.exit(0);
  };
  for (;;) {
    let value: unknown;
    try { value = await owner.next(); } catch { return shutdown(); }
    const received = deps.now();
    if (state.busy) {
      const d = decodeRequest(value);
      if (!d.ok) { if (d.addressable) failure(d.addressable, 'PROTOCOL_INVALID', true); else owner.close(); continue; }
      const problem = state.check(d.request);
      failure(d.request, problem ?? 'OPERATION_BUSY', problem !== 'OPERATION_BUSY');
      continue;
    }
    await current;
    current = process1(value, received);
  }
}

async function connectReader(deps: ControllerDeps, config: OwnerConfig): Promise<Reader> {
  const secret = await deps.readSecret(config.secretFiles.reader);
  try { return await deps.connectReader(config, secret.toString('latin1')); } finally { secret.fill(0); }
}

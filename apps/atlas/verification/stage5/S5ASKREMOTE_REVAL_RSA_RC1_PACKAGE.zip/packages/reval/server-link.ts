import type { ChildProcess } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import type { Socket } from 'node:net';
import { Channel } from './channel.ts';
import { APPLICATION_NAME, SERVER_INNER_ACK_REF } from './codes.ts';
import type { FailureCode } from './codes.ts';
import type { OwnerConfig } from './config.ts';
import type { ControllerDeps } from './deps.ts';
import { buildRequest, checkResponse, decodeResponse, Sequence } from './envelope.ts';
import type { ConnectionBinding } from './envelope.ts';
import { METADATA_FRAME_CAP, PRIVATE_FRAME_CAP } from './frame.ts';
import { awaitExit } from './launch.ts';
import { decodeIdentity } from './payloads.ts';
import { childPeerOk, sameIncarnation } from './peer.ts';
import type { PeerFacts } from './peer.ts';
import type { Observed, QueryClient } from './physical.ts';
import { decodeChildHello, decodeServerBound, SERVER_LAUNCH_V1 } from './private-frames.ts';

/**
 * The controller's link to its ONE server child S (brief §2e/§3): HELLO first → actual peer proof → private launch frame
 * (paths/expectations only, never credentials) → S's own physical binding and readiness → RevalServerBoundV1 compared with
 * the reader's tuple and (when visible) pg_stat_activity → 06 IDENTITY seq1 and seq2, after which S listens. Any mismatch
 * kills S before it listens. EVERY later IDENTITY re-proves the same pid AND pidversion. S death → LOST, no relaunch.
 */
export type ServerState = 'LAUNCHING' | 'READY' | 'LOST';
export class ServerLink {
  state: ServerState = 'LAUNCHING';
  /** pg_stat_activity cross-check of S's bound backend: VERIFIED, or UNAVAILABLE when PG hides the row from the reader. */
  activityCheck: 'PENDING' | 'VERIFIED' | 'UNAVAILABLE' = 'PENDING';
  facts: PeerFacts | null = null;
  readonly ready: Promise<boolean>;
  private child: ChildProcess | null = null;
  private channel: Channel | null = null;
  private readonly binding: ConnectionBinding;
  private readonly send = new Sequence();
  private readonly recv = new Sequence();
  private readonly deps: ControllerDeps; private readonly config: OwnerConfig;
  private readonly reader: () => { client: QueryClient; observed: Observed } | null;
  constructor(deps: ControllerDeps, config: OwnerConfig, serverBootId: string, reader: () => { client: QueryClient; observed: Observed } | null) {
    this.deps = deps; this.config = config; this.reader = reader;
    this.binding = { registrationId: config.registrationId, serverBootId, connectionId: randomUUID() };
    this.ready = this.launch().then(ok => { if (!ok) this.kill(); return ok; }, () => { this.kill(); return false; });
  }
  private async launch(): Promise<boolean> {
    const child = this.child = this.deps.spawnServer(this.config);
    child.once('exit', () => { this.state = 'LOST'; this.channel?.close(); });
    const channel = this.channel = new Channel(child.stdio[3] as Socket, PRIVATE_FRAME_CAP);
    const hello = decodeChildHello(await channel.next(1000));
    if (hello.kind !== 'SERVER' || !await this.prove()) return false;
    const launchChallenge = randomUUID();
    channel.send({ contractVersion: SERVER_LAUNCH_V1, registrationId: this.config.registrationId, databaseInstanceId: this.config.databaseInstanceId,
      serverBootId: this.binding.serverBootId, connectionId: this.binding.connectionId, launchChallenge, endpoint: this.config.endpoint,
      runtimeRole: this.config.roles.runtime, runtimeSecretFile: this.config.secretFiles.runtime, physical: this.config.physical });
    const bound = decodeServerBound(await channel.next(30000));
    const reader = this.reader();
    if (!reader || bound.launchChallenge !== launchChallenge || bound.serverBootId !== this.binding.serverBootId
      || bound.observed.systemIdentifier !== reader.observed.systemIdentifier || bound.observed.databaseOid !== reader.observed.databaseOid
      || bound.observed.postmasterStartTime !== reader.observed.postmasterStartTime || bound.observed.sessionUser !== this.config.roles.runtime) return false;
    const seen = await reader.client.query(`SELECT usename::text AS u, application_name AS a, datname::text AS d, datname = pg_catalog.current_database() AS same
      FROM pg_catalog.pg_stat_activity WHERE pid = $1::int`, [bound.observed.backendPid]);
    if (seen.rows.length === 0) this.activityCheck = 'UNAVAILABLE';
    else if (seen.rows[0]!.u === this.config.roles.runtime && seen.rows[0]!.a === APPLICATION_NAME.runtime && seen.rows[0]!.same === true) this.activityCheck = 'VERIFIED';
    else return false;
    channel.switchCap(METADATA_FRAME_CAP);
    for (let i = 0; i < 2; i += 1) if (await this.identityRequest(5000) === null) return false;
    this.state = this.child.exitCode === null ? 'READY' : 'LOST';
    return this.state === 'READY';
  }
  /** Actual peer proof of S on C's channel end: exact child pid, parent C, euid, exe, no TTY, same incarnation, alive after. */
  private async prove(): Promise<boolean> {
    const child = this.child; const socket = child?.stdio[3] as Socket | undefined;
    if (!child || !socket || child.pid === undefined) return false;
    const facts = await this.deps.peer(this.config.nativePeerHelper, socket, this.deps.nodeRealpath).catch(() => null);
    if (!facts || !childPeerOk(facts, child.pid) || child.exitCode !== null || child.signalCode !== null) return false;
    if (this.facts && !sameIncarnation(this.facts, facts)) return false;
    this.facts = facts;
    return true;
  }
  /** One 06 IDENTITY C→S exchange; returns S's (non-evidence) payload or null. */
  private async identityRequest(timeoutMs: number): Promise<unknown | null> {
    const channel = this.channel; if (!channel || channel.closed) return null;
    const out = { challenge: randomUUID(), sequence: this.send.take(), operation: 'IDENTITY' as const };
    channel.send(buildRequest(this.binding, out.challenge, out.sequence, 'IDENTITY', {}));
    try {
      const r = decodeResponse(await channel.next(timeoutMs));
      if (checkResponse(this.binding, this.recv, out, r, 'SERVER', this.config.databaseInstanceId) !== null || r.kind !== 'IDENTITY') return null;
      const p = decodeIdentity(r.payload);
      if (p.loadedBinding !== 'UNVERIFIED' || p.platformEvidenceRef !== SERVER_INNER_ACK_REF || p.databaseInstanceId !== this.config.databaseInstanceId) return null;
      return p;
    } catch { return null; }
  }
  /** IDENTITY for O: null = ready and re-proven (facts current); otherwise the fixed failure. Kills S on a mismatch. */
  async identity(deadline: number): Promise<FailureCode | null> {
    if (this.state === 'LAUNCHING') {
      const left = deadline - this.deps.now() - 150;
      if (left > 0) await Promise.race([this.ready, new Promise(r => setTimeout(r, left))]);
    }
    if (this.state !== 'READY') return 'IDENTITY_UNVERIFIED';
    const ok = await this.prove() && await this.identityRequest(Math.max(1, deadline - this.deps.now() - 100)) !== null;
    if (!ok || this.child?.exitCode !== null) { this.kill(); return 'IDENTITY_UNVERIFIED'; }
    return null;
  }
  /** SIGTERM (then SIGKILL after `graceMs`) and reap. */
  async stop(graceMs: number): Promise<void> {
    const child = this.child; if (!child) return;
    this.state = 'LOST'; this.channel?.close();
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGTERM');
    if (!await awaitExit(child, graceMs)) { child.kill('SIGKILL'); await awaitExit(child, 1000); }
  }
  kill(): void {
    this.state = 'LOST'; this.channel?.close();
    if (this.child && this.child.exitCode === null && this.child.signalCode === null) this.child.kill('SIGKILL');
  }
}

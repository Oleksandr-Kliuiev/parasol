import { lstat, readFile, realpath } from 'node:fs/promises';
import type { Stats } from 'node:fs';
import { dirname } from 'node:path';
import type { Endpoint, PhysicalTuple } from './private-frames.ts';

/**
 * Physical binding of EVERY RS-A database connection (reader, S runtime, E owner; brief §3), BEFORE any effecting query and
 * before S listens: the approved unix-socket endpoint and the recorded physical tuple, checked on the filesystem, through
 * the connection itself (`inet_server_addr() IS NULL` proves a unix-socket session), and again on the filesystem after
 * connecting. Every queried fact, including the floor epoch of pg_postmaster_start_time(), must EQUAL the recorded tuple
 * (whose start is also the postmaster.pid start line): no tolerance. Copied UUIDs prove nothing; this tuple is the binding. Any failure destroys the connection before another
 * statement and maps to REGISTRATION_MISMATCH. No TCP host can be expressed: the client gets `host: socketDir` only.
 */
export class PhysicalMismatchError extends Error {
  readonly step: string;
  constructor(step: string) { super('PHYSICAL_MISMATCH'); this.name = 'PhysicalMismatchError'; this.step = step; }
}
const mismatch = (step: string): never => { throw new PhysicalMismatchError(step); };

export interface QueryClient { query(sql: string, params?: unknown[]): Promise<{ rows: Record<string, unknown>[] }>; end(): Promise<void> }
export interface ConnectOptions {
  readonly host: string; readonly port: number; readonly database: string; readonly user: string; readonly password: string;
  readonly application_name: string; readonly connectionTimeoutMillis: number;
}
export interface PhysicalDeps {
  lstat(path: string): Promise<Stats>;
  realpath(path: string): Promise<string>;
  readFile(path: string): Promise<string>;
  isPidLive(pid: number): boolean;
  connect(options: ConnectOptions): Promise<QueryClient>;
}
export const nodePhysicalDeps = (connect: PhysicalDeps['connect']): PhysicalDeps => ({
  lstat: p => lstat(p), realpath: p => realpath(p), readFile: p => readFile(p, 'utf8'),
  isPidLive: pid => { try { process.kill(pid, 0); return true; } catch (e) { return (e as NodeJS.ErrnoException).code === 'EPERM'; } },
  connect,
});
export interface PhysicalExpectation {
  readonly endpoint: Endpoint; readonly physical: PhysicalTuple; readonly role: string; readonly applicationName: string; readonly connectTimeoutMs: number;
}
export interface Observed {
  readonly systemIdentifier: string; readonly databaseOid: string; readonly postmasterStartTime: string; readonly backendPid: string;
  readonly sessionUser: string; readonly unixSocket: true;
}
export const PHYSICAL_QUERY = `SELECT (pg_catalog.pg_control_system()).system_identifier::text AS system_identifier,
  (SELECT d.oid FROM pg_catalog.pg_database d WHERE d.datname = pg_catalog.current_database())::text AS database_oid,
  pg_catalog.floor(pg_catalog.date_part('epoch', pg_catalog.pg_postmaster_start_time()))::bigint::text AS start_epoch,
  pg_catalog.current_database()::text AS database, session_user::text AS session_user,
  pg_catalog.inet_server_addr() IS NULL AS unix_socket, pg_catalog.pg_backend_pid()::text AS backend_pid`;

/** Filesystem facts (steps 1–3): socket dir, socket dev/ino, postmaster.pid lines, live postmaster. */
export async function checkFilesystem(exp: PhysicalExpectation, deps: PhysicalDeps): Promise<void> {
  const { socketDir, port } = exp.endpoint; const p = exp.physical;
  if (await deps.realpath(socketDir).catch(() => '') !== socketDir) mismatch('socket-dir-path');
  for (let dir = socketDir; ; dir = dirname(dir)) {
    const st = await deps.lstat(dir).catch(() => mismatch('socket-dir'));
    if (!st.isDirectory() || st.isSymbolicLink()) mismatch('socket-dir');
    if ((st.mode & 0o022) !== 0 && (st.mode & 0o1000) === 0) mismatch('socket-dir-writable');
    if (dir === '/') break;
  }
  const sock = await deps.lstat(`${socketDir}/.s.PGSQL.${port}`).catch(() => mismatch('socket'));
  if (!sock.isSocket() || String(sock.dev) !== p.socketDevice || String(sock.ino) !== p.socketInode) mismatch('socket');
  const text = await deps.readFile(`${p.dataDirectory}/postmaster.pid`).catch(() => mismatch('pid-file'));
  const lines = text.split('\n');
  if (lines.length < 5 || lines[0] !== p.postmasterPid || lines[1] !== p.dataDirectory || lines[2] !== p.postmasterStartTime
    || lines[3]!.trim() !== String(port) || lines[4] !== socketDir) mismatch('pid-file');
  if (!deps.isPidLive(Number(p.postmasterPid))) mismatch('postmaster');
}
async function destroy(client: QueryClient): Promise<void> {
  const stream = (client as unknown as { connection?: { stream?: { destroy(): void } } }).connection?.stream;
  try { stream?.destroy(); } catch { /* already gone */ }
  await client.end().catch(() => undefined);
}
/** Steps 1–6; returns the connected client (no other statement ran) and the observed tuple. */
export async function verifyPhysicalEndpoint(exp: PhysicalExpectation, password: string, deps: PhysicalDeps): Promise<{ client: QueryClient; observed: Observed }> {
  await checkFilesystem(exp, deps);
  const client = await deps.connect({ host: exp.endpoint.socketDir, port: exp.endpoint.port, database: exp.endpoint.database, user: exp.role,
    password, application_name: exp.applicationName, connectionTimeoutMillis: exp.connectTimeoutMs }).catch(() => mismatch('connect'));
  try {
    const row = (await client.query(PHYSICAL_QUERY)).rows[0];
    if (!row || row.system_identifier !== exp.physical.systemIdentifier || row.database_oid !== exp.physical.databaseOid
      || row.start_epoch !== exp.physical.postmasterStartTime
      || row.database !== exp.endpoint.database || row.session_user !== exp.role || row.unix_socket !== true || typeof row.backend_pid !== 'string') {
      mismatch('database');
    }
    await checkFilesystem(exp, deps);
    return { client, observed: { systemIdentifier: row!.system_identifier as string, databaseOid: row!.database_oid as string,
      postmasterStartTime: row!.start_epoch as string, backendPid: row!.backend_pid as string, sessionUser: row!.session_user as string, unixSocket: true } };
  } catch (error) {
    await destroy(client);
    throw error instanceof PhysicalMismatchError ? error : new PhysicalMismatchError('database');
  }
}
export { destroy as destroyClient };

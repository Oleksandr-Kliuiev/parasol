import type { ChildProcess } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import type { Socket } from 'node:net';
import { Channel } from './channel.ts';
import { afterRequest, beforeRequestFailure, closureAfterReread, pauseDeadlines, remainingForExecutor } from './closure.ts';
import type { PauseDecision, Reread } from './closure.ts';
import type { OwnerConfig } from './config.ts';
import type { ControllerDeps } from './deps.ts';
import { PRIVATE_FRAME_CAP } from './frame.ts';
import { awaitExit } from './launch.ts';
import { childPeerOk } from './peer.ts';
import { decodeChildHello, decodeOwnerExecResult, OWNER_EXEC_REQUEST_V1 } from './private-frames.ts';
import type { OwnerExecResult } from './private-frames.ts';
import type { SnapshotWrapper } from './payloads.ts';

/**
 * PAUSE_EXPORT orchestration in the controller (brief §6): one budget D = t0 + 1800 ms; E spawned EXACTLY once; HELLO,
 * actual peer proof and the request by D − 1200; E's result by DE = D − 400; ONE reread by D − 50. The owner credential
 * never enters C (only its file path is forwarded). Cleanup is bounded separately (SIGKILL + reap ≤ 1000 ms) after the
 * decision. The session latch makes every later PAUSE_EXPORT fail without spawning. Killing E never proves rollback.
 */
export interface PauseContext {
  readonly deps: ControllerDeps; readonly config: OwnerConfig;
  /** The single reread (null on ANY failure: RV code, cap, timeout, physical/build binding). */
  reread(deadline: number): Promise<SnapshotWrapper | null>;
  latched: boolean;
  /** Test/evidence counter of executor spawns in this session. */
  spawns: number;
  /** The executor child of the last invocation (for bounded cleanup). */
  lastChild: ChildProcess | null;
}
export interface PauseRequest { readonly admissionId: string; readonly expectedPolicyVersion: string; readonly policyFloor: string; readonly fenceFloor: string }

export async function pauseExport(ctx: PauseContext, req: PauseRequest, t0: number): Promise<PauseDecision> {
  const { deps, config } = ctx;
  if (req.admissionId !== config.admissionId) return { kind: 'FAILURE', code: 'REGISTRATION_MISMATCH', latch: false };
  if (ctx.latched) return { kind: 'FAILURE', code: 'CONTAINMENT_UNCONFIRMED', latch: false };
  const d = pauseDeadlines(t0);
  const child = deps.spawnExecutor(); ctx.spawns += 1; ctx.lastChild = child;
  const channel = new Channel(child.stdio[3] as Socket, PRIVATE_FRAME_CAP);
  const decision = await (async (): Promise<PauseDecision> => {
    // Phase 1 — before the request frame: no commit is possible.
    let hello;
    try { hello = decodeChildHello(await channel.next(Math.min(1000, d.requestBy - deps.now()))); } catch { return beforeRequestFailure(false); }
    if (hello.kind !== 'EXECUTOR' || child.pid === undefined) return beforeRequestFailure(true);
    const facts = await deps.peer(config.nativePeerHelper, child.stdio[3] as Socket, deps.nodeRealpath).catch(() => null);
    if (!facts || !childPeerOk(facts, child.pid) || child.exitCode !== null || child.signalCode !== null) return beforeRequestFailure(true);
    const now = deps.now();
    const remainingMs = remainingForExecutor(d.DE, now);
    if (now > d.requestBy || remainingMs === null) return beforeRequestFailure(false);
    const challenge = randomUUID();
    try {
      channel.send({ contractVersion: OWNER_EXEC_REQUEST_V1, helloNonce: hello.helloNonce, challenge, remainingMs,
        registrationId: config.registrationId, databaseInstanceId: config.databaseInstanceId, workspaceId: config.workspaceId,
        clientId: config.clientId, actorId: config.actorId, admissionId: config.admissionId, expectedPolicyVersion: req.expectedPolicyVersion,
        endpoint: config.endpoint, ownerRole: config.roles.owner, physical: config.physical, ownerSecretFile: config.secretFiles.owner });
    } catch { return beforeRequestFailure(false); }
    // Phase 2 — the request was sent: anything but a valid authenticated result is commit-uncertain (latch).
    let result: OwnerExecResult | null = null;
    try { result = decodeOwnerExecResult(await channel.next(Math.max(0, d.DE - deps.now()))); } catch { result = null; }
    const after = afterRequest(result, challenge);
    if ('kind' in after) return after;
    const w = await ctx.reread(d.rereadBy).catch(() => null);
    const reread: Reread | null = w === null ? null : { admissionId: w.snapshot.admissionId as string, policyState: w.snapshot.policyState as string,
      policyVersion: w.snapshot.policyVersion as string, fenceEpoch: w.snapshot.fenceEpoch as string };
    return closureAfterReread(config.admissionId, after, reread, { policyFloor: req.policyFloor, fenceFloor: req.fenceFloor });
  })();
  if (decision.kind === 'FAILURE' && decision.latch) ctx.latched = true;
  channel.close();
  return decision;
}
/** Bounded cleanup after the response: SIGKILL a live executor and reap it (≤ 1000 ms). */
export async function reapExecutor(child: ChildProcess | null): Promise<boolean> {
  if (!child) return true;
  if (child.exitCode === null && child.signalCode === null && !await awaitExit(child, 100)) child.kill('SIGKILL');
  return awaitExit(child, 1000);
}

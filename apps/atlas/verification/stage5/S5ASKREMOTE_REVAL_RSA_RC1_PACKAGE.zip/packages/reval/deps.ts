import type { ChildProcess } from 'node:child_process';
import { spawn } from 'node:child_process';
import { openSync, closeSync, realpathSync } from 'node:fs';
import { Socket } from 'node:net';
import type { Duplex } from 'node:stream';
import pg from 'pg';
import { APPLICATION_NAME, PRODUCTION_PLATFORM_REF } from './codes.ts';
import { loadOwnerConfig } from './config.ts';
import type { OwnerConfig } from './config.ts';
import { computeDigests, PRODUCTION_ENTRIES, PROJECT_ROOT, spawnExecutor, spawnServer } from './launch.ts';
import type { Digests } from './launch.ts';
import { runPeerHelper, verifyHelperBinary } from './peer.ts';
import type { PeerFacts } from './peer.ts';
import { checkFilesystem, nodePhysicalDeps, PHYSICAL_QUERY, verifyPhysicalEndpoint } from './physical.ts';
import type { Observed, QueryClient } from './physical.ts';
import { readSecretFile } from './secret-file.ts';

/**
 * Everything the controller touches outside pure logic. productionDeps() is the ONLY set reachable from
 * scripts/reval-server/controller.ts: unix-socket physical binding, the pinned helper, the production child entries and
 * the single production platform reference. Test harnesses build their own sets outside production code.
 */
export interface ControllerDeps {
  readonly platform: string; readonly arch: string; readonly platformRef: string; readonly nodeRealpath: string;
  readonly env: Readonly<Record<string, string | undefined>>;
  now(): number; wallIso(): string; ppid(): number; ttyAvailable(): boolean;
  loadConfig(path: string): Promise<OwnerConfig>;
  verifyHelper(path: string, sha256: string): Promise<void>;
  warmHelper(path: string): Promise<void>;
  peer(helper: string, channel: number | Socket, expectedExe: string): Promise<PeerFacts>;
  digests(config: OwnerConfig): Promise<Digests>;
  readSecret(path: string): Promise<Buffer>;
  /** Physical binding + connect of the reader (the ONLY resident credential). */
  connectReader(config: OwnerConfig, password: string): Promise<{ client: QueryClient; observed: Observed }>;
  /** Filesystem + database recheck of an open reader connection (EVERY IDENTITY). */
  recheckReader(config: OwnerConfig, client: QueryClient): Promise<boolean>;
  spawnServer(config: OwnerConfig): ChildProcess;
  spawnExecutor(): ChildProcess;
  ownerSocket(): Duplex;
  exit(code: number): never;
}
const pgConnect = async (o: pg.ClientConfig): Promise<QueryClient> => {
  const client = new pg.Client(o); await client.connect(); return client as unknown as QueryClient;
};
export function productionDeps(): ControllerDeps {
  const physical = nodePhysicalDeps(o => pgConnect(o));
  const expectation = (config: OwnerConfig) => ({ endpoint: config.endpoint, physical: config.physical, role: config.roles.reader,
    applicationName: APPLICATION_NAME.reader, connectTimeoutMs: 300 });
  return {
    platform: process.platform, arch: process.arch, platformRef: PRODUCTION_PLATFORM_REF, nodeRealpath: realpathSync(process.execPath),
    env: process.env,
    now: () => performance.now(), wallIso: () => new Date().toISOString(), ppid: () => process.ppid,
    ttyAvailable: () => { try { closeSync(openSync('/dev/tty', 'r')); return true; } catch { return false; } },
    loadConfig: loadOwnerConfig, verifyHelper: verifyHelperBinary,
    warmHelper: path => new Promise((resolve, reject) => {
      // First exec of a freshly signed binary is assessed by the OS; a no-channel run exits 65 by contract.
      const child = spawn(path, ['peer'], { stdio: 'ignore', env: {} });
      const t = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('warm')); }, 5000);
      child.on('exit', code => { clearTimeout(t); code === 65 ? resolve() : reject(new Error('warm')); });
      child.on('error', () => { clearTimeout(t); reject(new Error('warm')); });
    }),
    peer: (helper, channel, exe) => runPeerHelper(helper, channel, exe),
    digests: config => computeDigests(PROJECT_ROOT, realpathSync(process.execPath), config.nativePeerHelperSha256),
    readSecret: readSecretFile,
    connectReader: (config, password) => verifyPhysicalEndpoint(expectation(config), password, physical),
    recheckReader: async (config, client) => {
      try {
        await checkFilesystem(expectation(config), physical);
        const row = (await client.query(PHYSICAL_QUERY)).rows[0];
        return !!row && row.system_identifier === config.physical.systemIdentifier && row.database_oid === config.physical.databaseOid
          && row.start_epoch === config.physical.postmasterStartTime
          && row.session_user === config.roles.reader && row.unix_socket === true;
      } catch { return false; }
    },
    spawnServer: config => spawnServer(config.server.apiEntry, config.server.port),
    spawnExecutor: () => spawnExecutor(PRODUCTION_ENTRIES.executor),
    ownerSocket: () => new Socket({ fd: 3, readable: true, writable: true }),
    exit: code => process.exit(code),
  };
}

# Read contracts and evidence

No new data endpoint, database model, permission, migration or Gateway entry is introduced. No browser imports server
repositories. Browser DTO types/validators are focused local projections of the accepted contracts, not broad core barrels.

## Exact allowed HTTP operations

| Operation | Existing contract | Console use |
|---|---|---|
| GET /clients | ClientSummary[] `{id,name}` | authorized client picker |
| GET /clients/:id/overview | ClientContextV1 | clientName, workspace/client scope, graph, resources and completeness |
| GET /clients/:id/observations | ObservationPage | one client queue, existing status/severity/limit/cursor |
| POST /tools/execute | ToolRequest v1; ResourceView result | explicit source-evidence button only |

The transport constructs relative paths from fixed templates, encodeURIComponent IDs and URLSearchParams query values.
No caller-controlled URL/method/headers/tool name. Authorization is injected from the private current credential holder.
Fetch uses credentials:'omit', redirect:'error', cache:'no-store', signal and an original10s browser request deadline.
Abort/timeout cancels browser consumption; it does NOT claim database cancellation or rolled-back audit.
No automatic retry; refresh is an explicit new request. Error bodies are never echoed as HTML/raw JSON.

Observation defaults: status OPEN,ACKNOWLEDGED; all severities; limit25. Permitted statuses/severities follow core enums.
Cursor is opaque; reset on client/filter/limit/refresh change. Client-side sorts must not reorder server severity/priority.
Page replacement (not unlimited append) bounds retained queue rows to100. Counts/total belong to this response selection.
No stable multi-request snapshot is promised; concurrent lifecycle updates can alter counts/pages. Source evidence and
overview have their own times; do not invent a shared generatedAt or label them one atomic snapshot.

## Runtime validation and bounds

Validate response shape, relevant enums/times and displayed field types BEFORE committing any response to state. Context
must be ClientContextV1 and match the requested client. Its workspaceId establishes that credential epoch's workspace;
later contexts/observation items must match it. Observation items must match selected client and current workspace.
Responses cannot set authority or selectable client IDs. Any mismatch is a fixed visible RESPONSE_INVALID with no payload.
Resource results have no scope envelope; the existing Gateway is authoritative, and the browser binds result acceptance
to the exact captured credential/client/selection epoch and requested connection/resource/source tuple.

Consume at most4MiB per response stream, cancelling on overflow; max10,000 client summaries accepted, first250 displayed
with explicit list-truncated message when larger. Do not silently pretend client-side truncation is a server total. Maximum
queue100 items, context people/devices/links each1000, resources100, each resource items1000; oversized responses are a
fixed RESPONSE_TOO_LARGE, never partial success. Strings displayed at most4000 codepoints, with a visible shortened marker;
identifiers needed for requests must validate unshortened, never use shortened labels as identity. Exact field limits and
resource item allowlists must be implementation brief material before S5-B, grounded in current snapshot DTOs.

## Evidence action allowlist

Only the selected current observation can create this request; parameters are derived from validated source references.
| Observation source/resourceType | Tool and required parameters |
|---|---|
| atera/alert | atera.alert.list; explicit connectionId, then local exact ID filtering |
| atera/ticket | atera.ticket.get; ticketId=externalEventId and explicit connectionId |
| huntress/incident | huntress.incident.get; incidentId=externalEventId and explicit connectionId |

Request body: `{version:'1',clientId,tool,parameters,requestId}`. A fresh opaque requestId is generated per deliberate click.
No arbitrary parameters or names from text/evidence. Unsupported source/type has a visible evidence-unavailable reason.
No broad list fallback after get/permission/error. No external vendor hyperlinks from source values; identifiers are text.
Retain X-Atlas-Correlation-Id and X-Atlas-Tool-Execution-Id as bounded diagnostic text only. Server permission checks and
ToolExecution/audit settlement remain unchanged. A timeout can have an audit/ledger outcome; no execution replay claim.

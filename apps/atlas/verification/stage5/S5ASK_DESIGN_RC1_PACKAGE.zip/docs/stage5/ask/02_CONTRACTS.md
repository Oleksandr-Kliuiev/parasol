# HTTP, evidence and planner contracts

## Fixed HTTP surface

Only when mock is enabled, add authenticated GET `/ask/capabilities` and POST `/clients/:id/ask`. Capability200 JSON:
`{contractVersion:'AskCapabilityV1',mode:'mock',questionMaxCodepoints:2000}`; no keys, model name or authority grant.
The browser treats only capability404 as OFF (no input), validates200 exactly, and retains normal401/403 handling.
No capability cache across credential epochs. Capability is queried once per connected credential, after clients load;
valid current context is still required to submit. Other failures show fixed unavailable state with explicit retry.

POST has explicit `@HttpCode(200)` and application/json. Path client matches SCOPE_ID_PATTERN1..128. Body has exactly:
`{contractVersion:'AskRequestV1',requestId:<UUIDv4>,question:<string>,observationId:<string|null>}`.
All four keys required; unknown keys rejected. Question1..2000 Unicode codepoints with at least one non-whitespace;
reject NUL, lone surrogates, DEL and C0 except TAB/LF/CR, do not silently truncate. Body UTF-8 max16KiB (route-local
parser/limit before JSON parse; preserve other endpoints' parser behavior). Observation ID nonempty≤256, unshortened;
never interpreted as source ID or fetched outside the captured client. UUIDv4 is a correlation aid, not idempotency or
authority. No user actor/workspace/context/model/tool/parameters/URL. No query parameters on either route.

Errors use a fixed new Ask-code allowlist with no upstream/body/details echo: request invalid400, authenticated scope
denied403, invalid/currently revoked or expired credential401, source context unavailable404, response/source cap413,
authority epoch changed409, local budget429, disabled routes404, deadline504, planner/audit/runtime failure503.
Codes: ASK_REQUEST_INVALID, ASK_SCOPE_DENIED, ASK_AUTHENTICATION_FAILED, ASK_CONTEXT_UNAVAILABLE,
ASK_TOO_LARGE, ASK_SCOPE_CHANGED, ASK_BUSY, ASK_DEADLINE, ASK_PLANNER_INVALID, ASK_AUDIT_FAILED,
ASK_RUNTIME_NOT_READY. Successful unsupported/insufficient questions are200 answers, not transport failures.
Unknown exceptions map to ASK_RUNTIME_NOT_READY; diagnostics contain only server-generated correlation UUID.

## Server evidence bank

Read context from authoritative storage, never from browser JSON. New focused reader uses one already-admitted scoped
transaction; no nested getClientContext/withScope transaction or browser HTTP loopback. Preserve the public context API.
Its field semantics mirror the accepted ClientContextV1 projection: source Atera/Huntress only; graph scope/confirmed
links, observation enums/lifecycle/identity, ResourceView status/mode/nullable-time/truncation and item shape validation.
No email, raw payload/facts, externalDevice/receivedAt, safeErrorCode, financial/M365 content or source URL extraction.
No source sync or Gateway/tool call. Context: active first100 observations in existing server order, people/devices/links
max1000 each, resources100, items1000 per resource, total decoded/serialized context≤4MiB. Fetch graph arrays with cap+1
where possible and reject overflow; JSON snapshot size is checked after DB materialization, not claimed pre-allocation.
Ambiguous duplicate observation IDs or duplicate graph IDs invalidate the whole source read; never pick an arbitrary row.
An optional selected observation is one additional exact scoped row (all lifecycle statuses), validated and restricted
to Atera/Huntress; missing/unsupported focus yields INSUFFICIENT, with no lookup/fallback elsewhere.

Bank≤32 facts: up to24 observations (focus first, deduplicated by exact ID, then source order), up to7 resource-state
facts (focus source/type/connection first when present), and1 focus entity fact. Entity confirmation follows S5-B exact
unambiguous graph ID+CONFIRMED link, never a name guess. Validate the whole source read before selecting facts.
Fact IDs are E1..E32, assigned by server per request. Facts have closed kinds OBSERVATION/RESOURCE_STATE/ENTITY and
explicit projections only. Observation: scoped Atlas ID, source/type/connection/externalEventId, summary, severity,
priority/route/confidence/reasonCodes/status/conflict/superseded and independent times. Resource: captured tuple,
status/asOf/lastSuccessAt/truncated; no snapshot items are copied into this first Ask bank. Entity: exact graph ID,
confirmed/unresolved/unavailable state and existing display label only. Display strings cap4000 codepoints with marker;
request identity fields remain validated unshortened. An overlong identity is invalid, never reconstructed from labels.

Coverage records read limit100, bank limit32, source-page truncation, bank omissions and fixture limitation. Drop context
global counts: they may include excluded sources; any displayed counts describe only included facts. Never claim the
bank is exhaustive or atomically fresh. Separate reader times from source asOf/lastSuccessAt. Fixture Huntress evidence
lookup remains unsupported; its existing resource-state fixture card is not a performed lookup.

Exact bank element: `{ref,kind,data}`; no additional keys. `ref` matches `^E([1-9]|[12][0-9]|3[0-2])$`.
OBSERVATION data keys: observationId,source,resourceType,connectionId,externalEventId,summary,severity,priority,route,
confidence,reasonCodes,status,entityId,conflictOfEventKey,supersededById,occurredAt,createdAt,updatedAt,acknowledgedAt,
resolvedAt. Types/enums/nullability are the accepted ObservationSummary fields (ID renamed observationId); reasonCodes
max100 strings. IDs≤256 except connectionId uses scope pattern1..128; source request IDs are not generated from labels.
RESOURCE_STATE data keys: source,resourceType,connectionId,status,asOf,lastSuccessAt,truncated (accepted ResourceView
semantics, nonnull explicit connectionId, accepted time/null/status/mode checks; no items property).
ENTITY data keys: observationId,entityId,state,entityKind,displayName,confirmation. State CONFIRMED/UNRESOLVED/UNAVAILABLE;
entityId is nullable accepted graph ID; kind PERSON/DEVICE or null; displayName string or null. CONFIRMED requires exact
graph row and confirmation `{source,resourceType,connectionId,externalId}` from one CONFIRMED matching entity link,
chosen in existing link order. Otherwise confirmation/displayName/kind are null: missing graph row UNAVAILABLE,
no entity ID or no confirmed link UNRESOLVED. All bank objects are fresh explicit projections, not raw-object spreads.

Exact coverage keys: observationLimit:100,bankLimit:32,observationsRead (safe integer0..100),observationPageTruncated
(boolean),focusExtra (boolean),observationFactsOmitted (boolean),resourcesRead (safe integer0..100),resourceFactsOmitted
(boolean),fixture (boolean). Counts describe source read before bank reduction, not whole-client totals. Invalid source
scope, modes or DTOs fail the request instead of becoming missing data. The source read has no claim of atomic snapshot.

## Local planner and answer compiler

Private interface `plan(AskPlannerInputV1, AbortSignal): Promise<AskPlanV1>`. Input: original question (local MOCK only),
optional focusRef, and bank descriptors `{ref,kind,source,type,severity?,route?,status?,entityState?}`. Descriptors contain
known enums/flags only: no names, summaries, free-text reason codes, identifiers, times or raw records. Question is
untrusted input, never authority/instructions to execute. Planner has no DB, network, credentials, Gateway or registry.

Plan exact keys: `{version:'AskPlanV1',intent,refs}`; intent SUMMARY/WHY_URGENT/SOURCE_STATE/ENTITY/UNSUPPORTED;
refs≤8 unique current E-refs, no other keys, arbitrary prose, URL, tool or parameters. Unknown version/enum/refs, wrong
types, duplicates or unexpected keys reject the whole plan. Mock intent recognizer handles only documented RU/EN
phrases; unmatched input gives UNSUPPORTED. First implementation uses exact case-insensitive trimmed matches, with
optional terminal '?' removal: SUMMARY “what needs attention”/“что требует внимания”; WHY_URGENT “why is this urgent”/
“почему это срочно”; SOURCE_STATE “how fresh is the evidence”/“насколько свежи данные”; ENTITY “which device is confirmed”/
“какое устройство подтверждено”. UI labels these as supported MOCK examples, not general language understanding.
No retry/fallback to Decisions or another model.

Compiler alone derives claims from matching validated facts. SUMMARY allows observation/resource refs; WHY_URGENT
requires the current focus observation and derives urgency from source severity; SOURCE_STATE requires its exact tuple's
resource fact; ENTITY requires focus entity fact. Wrong-kind refs or incompatible focus yield ASK_PLANNER_INVALID.
Missing required facts yields INSUFFICIENT; UNSUPPORTED requires empty refs. No free-form model explanation is rendered.
Claim codes are OBSERVATION_RECORDED, SOURCE_URGENT, SOURCE_NOT_URGENT_IN_READ, RESOURCE_RECORDED,
ENTITY_CONFIRMED, ENTITY_UNRESOLVED, ENTITY_UNAVAILABLE; compiler chooses only codes whose predicate holds.
All claims cite≥1 bank ref; WHY_URGENT cites focus. Independent mandatory urgency notice lists HIGH/CRITICAL in the
bank even if the planner omitted them. At most8 compiled claims and32 returned facts. No confidence-as-fact/root-cause.

Answer200 exact projection: `{contractVersion:'AskAnswerV1',requestId,correlationId,workspaceId,clientId,mode:'mock',sourceMode,
status:'ANSWER'|'INSUFFICIENT'|'UNSUPPORTED',intent,generatedAt,focusObservationId,coverage,urgentRefs,claims,evidence}`.
Claims `{code,refs}` and evidence bank above; fixed UI message dictionaries render claims. Every ref must resolve once;
all scope/identity/version/mode/time/enum/cap predicates are validated again in browser. Response≤256KiB; exceeding
it fails closed413, never partial JSON. No raw question, planner plan, provider text, chat transcript or persistent answer.
RequestId must match captured request; response focus equals requested focus (including missing focus), never auto-selected.
sourceMode is fixture/db, must match current validated context; status/mode of resource evidence must be consistent.
urgentRefs≤24 unique observation refs, exactly all HIGH/CRITICAL observation facts in the returned bank. Empty bank or
missing focus-dependent facts gives INSUFFICIENT with no claims; UNSUPPORTED likewise has no claims. Claim refs≤8 each,
unique and valid for that code's exact predicate. All duplicate bank/observation IDs, mismatched focus/entity references,
or unexpected fields invalidate the answer in browser; no partial safe-looking subset is rendered.

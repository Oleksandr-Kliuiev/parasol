# Authority, privacy, resources and asynchronous state

## Current bearer and client authority

Reuse accepted bearer syntax/hash and currentToken lookup; an Ask-private opaque credential retains only the digest in
request memory. No browser Actor, new token/permission or auto-grant. Required permission: context:read on one current
membership of the path client, because this slice reads only the same stored context; no tool execution is admitted.
Guard authentication precedes semantic validation (bounded JSON syntax/size parsing may reject first without DB work).
Scope-denial decisions before client data must be identical for malformed,
nonexistent or forbidden requested IDs. Denial writes exactly one workspace SecurityAuditEvent `ask.scope_denied`,
requested client escaped, fixed reason, server correlation UUID, empty metadata; no client audit on a scope denial.

DB phase1, confined runtime role: clear transaction-local scope/actor/token settings; currentToken digest lookup obtains
workspace hint; lock existing ActionAuthorityFence(workspace) FOR SHARE as the FIRST lock; verify existing fence readiness;
re-authenticate token after lock wait, same workspace and ACTIVE actor, current single-membership context:read; only then
set one-client RLS scope and read bank inputs. Capture fence version as exact DB integer/string, never lossy JS Number.
No schema/role/definer change and no PowerOffice readiness dependency. Actor/token/membership mutations already use
the accepted fence triggers; missing fence/role guarantees fail closed. No locks/transaction survive the planner call.

After plan validation/compile, DB phase2 repeats bearer/fence/current actor/permission admission under FOR SHARE. If
current credential is invalid return401; scope lost403; if still authorized but fence version differs, discard the answer
with409 ASK_SCOPE_CHANGED. No automatic re-read/retry. Expiry compared with the DB clock after all lock waits and again
immediately before final audit/return. Successful/failure audit and decision commit in this final transaction before HTTP.
This is a read-admission/publication boundary, not revocation of information already received or an atomic wire send.
No source-data snapshot consistency is promised across queries; coverage/timestamps say exactly what was read.

Each final admitted answer/unsupported/insufficient or local planner failure writes one client AuditEvent `ask.completed`
or `ask.failed`, using existing clientAuditData and only existing keys: provider='fixture', ruleVersion='ask-mock-v1',
itemCount (bank count), outcome (fixed status), safeErrorCode (fixed failure only). No question, plan, answer, source IDs,
names, raw text/hash or question length. No ToolExecution/DecisionRun/new ledger. Final invalid authentication has no
client audit; final scope denial has one workspace denial. Denial/audit failure fails closed503; commit failures return
no answer and are not retried. A crash/disconnect after commit may leave an audit without a delivered answer; a manual
repeat is a new read/audit, not an idempotent write. Correlation UUID server-generated; input requestId is echoed only.

Fixture path applies accepted equality-token/client checks, same DTO/compiler caps and memory audit semantics; label
fixture authority as synthetic. DB revocation/fence claims require real disposable-PG tests, never fixture substitutes.

## Resource budgets and privacy

Server original8s monotonic deadline covers admission, reads, projection, local planner, compilation, final authority,
audit and serialization. Before/after every awaited and synchronous phase check the same deadline; synchronous work
cannot be preempted but a late result is discarded. DB phases max2s each, pool maxWait≤500ms, each bounded also by
remaining original budget; provider phase max2s and remaining budget. Abort is courtesy, never authorization/isolation.
If insufficient remaining budget to publish, return504. A completed audit records a compiled/currently admitted result,
not delivery: commit completion or HTTP delivery may outlast the original deadline, in which case no answer is returned
but an already committed audit remains. Do not retry an unknown commit outcome or rewrite it as a new completion.

One API process:≤4 in-flight Ask requests total and≤1 per actor, at most64 tracked actor budget entries;10 admitted
questions per actor per rolling60s. Use monotonic clock and atomic synchronous reservation before async work; no active
entry eviction; prune idle expired entries. Refuse429 when full, release on every outcome. This bounds one local process,
not a distributed quota. Parse/body limits apply before request work; invalid/denied requests cannot allocate unbounded
budget keys. No background timers/polling, provider billing or external calls. Logs contain fixed codes/counters only.
Question/answer retention ends with request/browser state; no DB hash/trace/analytics, localStorage/sessionStorage,
cookie, URL query, HAR/video or source text in diagnostics. Synthetic screenshots follow accepted password-cleared,
token-free DOM/capture checks. Error paths never echo body/question, upstream exception or credential.
Allowlisted source display strings remain potentially sensitive; they are local authorized display data, not certified
secret-free text. Excluded fields never enter bank/planner/answer; included display strings never enter audit/logs or an
external planner. No regex redaction guarantee is claimed for either questions or source text.

## Browser state

Add only fixed capability GET and Ask POST to the holder/operation union, never a generic sender. Same origin, bearer
closure, omit/no-store/redirect:error/no-referrer, incremental caps and original10s browser total deadline including
decode/parse/validation; Ask success200, evidence success201 remains unchanged. Capability404 is OFF only in its own
operation; Ask404 clears answer with fixed unavailable state. Current401 globally disconnects; any current403 clears
full selected scope and refreshes picker once, no auto-selection/loop. Stale failures/401/403/finally are ignored.

Ask captures credential epoch, scope epoch, context generation, queue/selection generation, chosen focus and own request
generation. Every success/error/finally check all captured identities before state change. Client/credential/context
refresh/queue filter/page/observation change/disconnect/pagehide/bfcache reset invalidates work and clears answer/input
synchronously. Submitting twice while pending sends once; manual retry uses fresh UUID and current server read. Capability
completion has credential epoch/generation guards; no stale completion can expose input or start an Ask request.
No answer modifies accepted context/queue/detail/evidence or urgency. Safe DOM/textContent and fixed claim dictionaries
only; request-local citation buttons reveal stored answer cards, never source URLs or another scope.

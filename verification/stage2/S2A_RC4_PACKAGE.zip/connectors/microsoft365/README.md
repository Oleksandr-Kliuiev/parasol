# Microsoft 365 — next slice

Stage 2 specification: [M365 Correlation pack](../../docs/stage2/README.md). First slice uses Graph v1.0 users, registered devices and bounded user sign-in evidence, with confirmed canonical mappings. Intune inventory, Lighthouse/WorkIQ and writes remain outside this slice.

No Microsoft connector implementation, credentials, permissions or live API calls are configured by this specification. Read [architecture review status](../../docs/stage2/REVIEW_STATUS.md) before implementation.

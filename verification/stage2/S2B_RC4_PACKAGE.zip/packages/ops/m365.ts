import { disableM365Connection } from '../connections/m365-disable.ts';
import type { ClientCommand } from './commands.ts';

/**
 * Microsoft 365 operator commands (docs/stage2/03_CONNECTOR_SYNC.md §6). Thin: the command boundary in commands.ts checks
 * the client ID and the listed permissions (refusal → workspace security audit) before `run`; the service rechecks
 * current authority under its own lock and owns the client audit. Output: local IDs, statuses, versions, counts only.
 * Later tasks add m365-probe/sync/status/requeue/directory/correlation/cleanup here.
 */
export const m365Commands: Readonly<Record<string, ClientCommand>> = {
  'm365-disable': { required: ['connection'], permissions: ['connections:manage'],
    run: async (ctx, scope, f) => ({ ok: true, output: { ...await disableM365Connection(ctx.db, ctx.actor, scope, f.connection!) } }) },
};

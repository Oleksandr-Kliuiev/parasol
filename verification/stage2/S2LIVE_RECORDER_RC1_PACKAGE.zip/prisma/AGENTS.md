# Prisma context routing

Read docs/AI_CONTEXT_MAP.md and the current stage workflow first. Schema commands use the prisma directory:
- schema.prisma: generator/datasource and Foundation models.
- m365.prisma: Stage 2 M365 models; reviewed contracts in docs/stage2/02_CONTRACTS.md.
- roles.sql: post-migration role provisioning; runtime checks in packages/graph/runtime-role.ts.

Do not load the migration history wholesale. Query one named constraint/function or current migration.
Existing migrations are frozen; changes require new migrations after the accepted checkpoint.
S2-B repair: 202610081300_stage2_m365_directory_retry (M365ResourceState.retryAt, its CHECK/trigger; grant in roles.sql);
202610081400_stage2_m365_directory_budget (attemptsUsed, backfill, CHECK, transition trigger; grant in roles.sql).
Stage 2 SQL invariants: tests/m365-sql-invariants.ts and tests/m365-cleanup-invariants.ts.

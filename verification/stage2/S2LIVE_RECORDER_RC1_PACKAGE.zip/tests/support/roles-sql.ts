import { readFile } from 'node:fs/promises';

/**
 * prisma/roles.sql rendered for one database, shared by the PGlite tests, scripts/pg17-check.ts and the PostgreSQL
 * harness, so every engine runs the PRODUCTION grant definitions (no test-only grants). Roles are cluster-wide: each
 * PostgreSQL database gets its own runtime/definer/runner names. Only the three role-name settings and the two psql
 * password variables are substituted, each of which must occur exactly once; anything else means roles.sql changed shape.
 */
export interface RoleNames { runtime: string; definer: string; runner: string }
export interface RoleSecrets { runtimePassword: string; runnerPassword: string }

const ROLE_SETTINGS: Readonly<Record<keyof RoleNames, [setting: string, defaultName: string]>> = {
  runtime: ['atlas.runtime_role', 'atlas_app'],
  definer: ['atlas.definer_role', 'atlas_m365_cleanup_definer'],
  runner: ['atlas.runner_role', 'atlas_m365_cleanup_runner'],
};
const PASSWORD_VARIABLES: Readonly<Record<keyof RoleSecrets, string>> = {
  runtimePassword: ":'atlas_app_password'", runnerPassword: ":'atlas_cleanup_runner_password'",
};
const ROLE_NAME = /^[a-z_][a-z0-9_]{0,62}$/;
const SECRET = /^[A-Za-z0-9]{16,128}$/;

export const readRolesSql = (): Promise<string> => readFile(new URL('../../prisma/roles.sql', import.meta.url), 'utf8');

/** Unique, non-prefix-colliding names for one database: atlas_{app,def,run}_<label>_<suffix>. */
export function uniqueRoleNames(label: string, suffix: string): RoleNames {
  return { runtime: `atlas_app_${label}_${suffix}`, definer: `atlas_def_${label}_${suffix}`, runner: `atlas_run_${label}_${suffix}` };
}

export function renderRolesSql(sql: string, names: RoleNames, secrets: RoleSecrets): string {
  let out = sql;
  for (const key of Object.keys(ROLE_SETTINGS) as (keyof RoleNames)[]) {
    const [setting, defaultName] = ROLE_SETTINGS[key];
    const token = `set_config('${setting}', '${defaultName}', true)`;
    if (out.split(token).length !== 2) throw new Error('prisma/roles.sql changed shape; update renderRolesSql');
    if (!ROLE_NAME.test(names[key])) throw new Error(`invalid test role name for ${key}`);
    out = out.replace(token, `set_config('${setting}', '${names[key]}', true)`);
  }
  for (const key of Object.keys(PASSWORD_VARIABLES) as (keyof RoleSecrets)[]) {
    const variable = PASSWORD_VARIABLES[key];
    if (out.split(variable).length !== 2) throw new Error('prisma/roles.sql changed shape; update renderRolesSql');
    if (!SECRET.test(secrets[key])) throw new Error(`invalid test secret for ${key}`);
    out = out.replace(variable, `'${secrets[key]}'`);
  }
  if (new Set(Object.values(names)).size !== 3) throw new Error('role names must differ');
  return out;
}

/** DROP ROLE statements for teardown, after the database is gone (a dropped database releases the routine's owner). */
export const dropRolesSql = (names: RoleNames): string[] => [names.runner, names.definer, names.runtime].map(n => `DROP ROLE IF EXISTS "${n}"`);

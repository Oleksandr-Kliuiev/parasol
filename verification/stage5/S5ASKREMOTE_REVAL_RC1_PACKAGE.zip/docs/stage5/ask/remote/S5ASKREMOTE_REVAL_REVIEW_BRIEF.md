# R-EVAL RC1 — independent review brief

Read-only review. Do not edit repository, run provider calls, provision credentials, activate policy,
execute paid discovery, use API/credits/fallback, or run mutation tests on the shared checkout.
Read only the frozen manifest files and relevant 05_ACCEPTANCE.md R-EVAL / 03 / 04 clauses as needed.
No other reviewer's verdict or implementer conversation is supplied.

Goal: assess preparation completeness, faithful 200-case thresholds, data/EU/retention and explicit
owner-budget gates, reserve/UNKNOWN arithmetic, stop/resume/expiry, evidence privacy, frozen dataset,
current model-role policy, and truthful distinctions between preparation, readiness and live acceptance.
This package contains documentation only; no live evaluation or runner implementation is claimed.
Report APPROVE_PREPARATION or CHANGES_REQUIRED, numbered required findings and residual risks.
Approval never authorizes product calls and never approves missing dataset/owner admissions.
Use the same exact manifest packageHash; rehash reviewed files before verdict.

Architecture reviewers: explicit gpt-6-astra/xhigh and native claude-fable-5-1/xhigh, independent fresh sessions.
Independent checkpoint reviewers: explicit gpt-6.1-sol/xhigh and native claude-opus-5-5/xhigh,
independent fresh sessions; actual implementation/eval evidence remains a future gate.
Keep any unavailable named-model gate PENDING; never replace Fable with Opus or Astra with Sol.
Return exact model/effort launch evidence, effective response model if observable, elapsed and usage
if attributable. Requested names/self-identification alone do not prove Anthropic response identity.

# ASK-REMOTE R-EVAL — лист допусков RC1

2026-10-11. Все поля ниже PENDING, пока владелец не подтвердит конкретное значение и evidence reference.
Решение сейчас: NOT_ADMITTED. Этот файл не является approval и не активирует RemoteAskPolicy.
Не записывать ключи, токены, env, реальные вопросы или персональные данные.

| Допуск | Что зафиксировать до платного вызова | Статус |
|---|---|---|
| Artifact | commit, dirty/source/build inventory, accepted dependency seals/closure, review manifest hashes | PENDING |
| Dataset | 200 уникальных synthetic RU/EN, manual labels/rubric, dataset/order/holdout hashes | PENDING |
| Offline readiness | Принятый runner/ручная процедура, rehearsal receipt, no retry, stop/resume, numeric-only evidence | PENDING |
| Provider identity | Точный gpt-6-luna, ask-remote-openai-luna-v1, prompt/schema hashes; без fallback/alias | PENDING |
| EU account/project | Dedicated account/project identity и project-level EU configuration evidence; EU hostname недостаточен | PENDING |
| Retention | Owner-verified ZDR/MAM-class eligibility/configuration refs для проекта и нужного endpoint; store=false недостаточен | PENDING |
| Key | Только secret reference, dedicated project binding, отсутствие стороннего usage; provisioning отдельно разрешён владельцем | PENDING |
| Data scope | SYNTHETIC workspace/client/actor allowlist без wildcard, trusted operator и зарегистрированная synthetic DB | PENDING |
| Permissions | context:read + ask:remote в одной membership; owner provisioning, policy/admission/fence revision tuple | PENDING |
| Privacy | Внешне уходит только original synthetic question + hasFocus; bank/refs/IDs локальны; body APM/log/trace off | PENDING |
| Egress | Только direct TLS443 eu.api.openai.com, no proxy/redirect/retry; platform allowlist evidence | PENDING |
| Price contract | Документальный priceRevision/rates/window evidence + срок действия; без billable discovery probe | PENDING |
| Validity | start UTC / expires UTC ≤7days, exact policyVersion/admissionId; не расширять автоматически | PENDING |
| Budget | reserve=$0.30; конкретные DAY≤$2 / MONTH≤$10, opening liabilities и available, owner total monetary ceiling | PENDING |
| Calls | ≤200 initial, 1/case; явный отдельный allowance для manual reruns (по умолчанию 0) | PENDING |
| Stop/resume | Назначенный оператор, ручной cap stop и resume, freeze/expiry/revocation controls, отсутствие schedule | PENDING |
| Owner decision | Явное approval текущего artifact + данных + платного бюджета, evidence ref и дата; checkbox недостаточен | PENDING |
| Independent gates | Astra/Fable xhigh preparation + Sol/Opus xhigh actual changes/evidence, один текущий hash | PENDING |

Бюджет ревью отдельно от продукта: только включённая подписка, API/credits/fast/fallback запрещены.
Fable unattended -p запрещён до доказательства included billing для этой роли; native login сам по себе
этого не доказывает. При отсутствии подтверждения Fable gate остаётся PENDING, без замены модели.
Opus запуск допустим только после read-only auth/extraUsage/provider preflight; quota unknown не считать 0.
Если subscription limit блокирует роль, остановить её, не включать оплату автоматически.

Владелец одобряет заполненный лист и точный package hash отдельным решением после подготовки/ревью.
Утверждение плана не означает допуск реальных данных, interactive synthetic use или deployment.

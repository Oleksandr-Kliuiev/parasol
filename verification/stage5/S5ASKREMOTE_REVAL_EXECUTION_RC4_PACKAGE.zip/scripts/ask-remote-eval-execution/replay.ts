// Independent deterministic replay of the SAVED numeric evidence of a receipt (no session, no transient content): per-case
// ledger arithmetic and reconciliation flags, settlement/liability agreement, accounted DAY/MONTH floors in chronological
// order (DAY resets only when the UTC day advances, MONTH never), liability totals, closure progression (strictly newer
// confirmed version/fence, absorbing containment), consumption and duration/censoring consistency. It CANNOT replay the
// answer predicates of a live case: the raw answer and observed intent are never stored (UNVERIFIABLE_UNDER_PRIVACY_CONTRACT).
type R = Record<string, any>;

export function replayNumeric(receipt: R): { status: 'VERIFIED_SAVED_ARITHMETIC' | 'MISMATCH'; failed: string[] } {
  const failed: string[] = []; const fail = (code: string): void => { if (!failed.includes(code)) failed.push(code); };
  const cases: R[] = Array.isArray(receipt?.cases) ? receipt.cases : [];
  let floorDay: number | null = null; let floorDayMicro = 0; let floorMonthMicro = 0;
  let confirmed = 0; let retained = 0; let unknown = 0;
  for (const c of cases) {
    const reconciled = c.reconciliation === 'RECONCILED';
    if (c.ledger === 'BOUND' || c.ledger === 'CONTRADICTS_REPLY') {
      if ([c.ledgerAttempts, c.chargedMicro, c.postDayMicro, c.postMonthMicro].some(v => v === null) || c.ledgerSettlement === null) fail('LEDGER_NUMBERS_MISSING');
      const arithmetic = c.preDayMicro + c.chargedMicro === c.postDayMicro && c.preMonthMicro + c.chargedMicro === c.postMonthMicro;
      if (c.ledger === 'BOUND' && reconciled !== arithmetic) fail('RECONCILIATION_FLAG');
      if (c.ledger === 'CONTRADICTS_REPLY' && c.reconciliation !== 'UNKNOWN') fail('CONTRADICTION_RECONCILED');
    } else if ([c.ledgerAttempts, c.ledgerSettlement, c.chargedMicro, c.postDayMicro, c.postMonthMicro].some(v => v !== null) || c.reconciliation !== 'UNKNOWN') fail('UNBOUND_NUMBERS_KEPT');
    if (reconciled ? c.liability !== c.ledgerSettlement : !['RETAINED_UNKNOWN_COMMIT', 'UNKNOWN'].includes(c.liability)) fail('LIABILITY_SETTLEMENT');
    if (reconciled && c.ledgerSettlement === 'CONFIRMED') confirmed += c.chargedMicro;
    else if (reconciled && (c.ledgerSettlement === 'RETAINED_KNOWN' || c.ledgerSettlement === 'RETAINED_UNKNOWN_COMMIT')) retained += c.chargedMicro;
    if (!reconciled) unknown += 1;
    if (c.utcDay !== null) {
      if (floorDay !== null && c.utcDay < floorDay) fail('UTC_DAY_REGRESSION');
      if (floorDay !== c.utcDay) { floorDay = c.utcDay; floorDayMicro = 0; }
      if (c.preDayMicro < floorDayMicro || c.preMonthMicro < floorMonthMicro) fail('COUNTER_BELOW_FLOOR');
      floorDayMicro = Math.max(floorDayMicro, c.preDayMicro); floorMonthMicro = Math.max(floorMonthMicro, c.preMonthMicro);
      if (reconciled) { floorDayMicro = Math.max(floorDayMicro, c.postDayMicro); floorMonthMicro = Math.max(floorMonthMicro, c.postMonthMicro); }
    }
    if ((c.durationMs === null) !== (c.censored === true)) fail('DURATION_CENSORING');
    if (c.ledger === 'BOUND' && c.reply === 'V2_ANSWER_VALID' && c.outcome !== 'LEDGER_REPLY_CONTRADICTION'
      && (c.ledgerAttempts !== 1 || c.ledgerSettlement === 'NO_DISPATCH' || c.ledgerSettlement === 'NO_RESERVATION')) fail('ANSWER_WITHOUT_DISPATCH');
  }
  // Credit: only a validated answer with reconciled, known (not RETAINED_UNKNOWN_COMMIT) accounting may pass or count as a
  // validated provider answer; every unknown-liability answer is a no-credit, non-passing case.
  const credited = cases.filter(c => c.reply === 'V2_ANSWER_VALID' && (c.outcome === 'ANSWER' || c.outcome === 'SUBMITTED_TEXT_DEVIATION'));
  if (credited.some(c => c.reconciliation !== 'RECONCILED' || c.liability === 'RETAINED_UNKNOWN_COMMIT')) fail('UNKNOWN_LIABILITY_CREDITED');
  if (cases.some(c => c.casePass === true && !credited.includes(c))) fail('UNCREDITED_PASS');
  if (receipt?.run?.validatedAnswers !== credited.length) fail('VALIDATED_ANSWER_COUNT');
  const l = receipt?.liability ?? {};
  if (l.confirmedChargedMicro !== confirmed || l.retainedReserveMicro !== retained || l.unknownLiabilityCases !== unknown) fail('LIABILITY_TOTALS');
  let version = 0n; let fence = BigInt(receipt?.admission?.openingFenceEpoch ?? '0'); let contained = false;
  for (const e of Array.isArray(receipt?.closures) ? receipt.closures as R[] : []) {
    if (e.result === 'CONFIRMED') {
      if (contained || e.policyVersion === null || e.fenceEpoch === null || BigInt(e.policyVersion) <= version || BigInt(e.fenceEpoch) <= fence) fail('CLOSURE_PROGRESSION');
      else { version = BigInt(e.policyVersion); fence = BigInt(e.fenceEpoch); }
    } else contained = true;
  }
  if (contained !== (receipt?.run?.closure === 'CONTAINMENT_UNCONFIRMED')) fail('CONTAINMENT_STATE');
  if (receipt?.run?.consumed !== cases.length + (receipt?.run?.inFlight ? 1 : 0)) fail('CONSUMED_COUNT');
  return { status: failed.length === 0 ? 'VERIFIED_SAVED_ARITHMETIC' : 'MISMATCH', failed };
}

// OFFLINE procedural supervisor model for the future manual R-EVAL run (S5ASKREMOTE_REVAL_PLAN.md "Исполняемые правила
// evidence, остановки и закрытия"). It is a SIMULATION of the operator-side procedure, separate from product authority:
// it never calls the server, never consents or submits by itself, has no retry, timer, schedule or network, and its
// gates are NOT production DB proof — the server still re-checks current authority on every request. Every input is an
// explicit operator/observation event with injected clocks. It keeps the frozen question text and draft label in memory
// only; the safe record it emits holds case IDs, fixed enums, booleans and durations — never the question, its hash or
// length, the raw answer or the observed intent.

export const RESERVE_MICRO = 300_000;
export const DAY_CAP_MAX = 2_000_000;
export const MONTH_CAP_MAX = 10_000_000;
export const MAX_VALIDATED_COST_MICRO = Math.ceil((32768 * 275 + 512 * 825) / 1000);
export const PROVIDER_THRESHOLD = 190;
export const SUPPORTED_PASS_THRESHOLD = 24;
const DAY_MS = 86_400_000;

export const costMicro = (promptTokens: number, completionTokens: number): number => Math.ceil((promptTokens * 275 + completionTokens * 825) / 1000);
/** Conservative terminal estimate S×9434 + U×300000 + opening (plan "Бюджет"): not an admission or a guarantee. */
export const terminalLiabilityMicro = (settled: number, retained: number, openingMicro = 0): number => settled * MAX_VALIDATED_COST_MICRO + retained * RESERVE_MICRO + openingMicro;

export const utcDay = (ms: number): number => Math.floor(ms / DAY_MS);
export const utcMonth = (ms: number): number => { const d = new Date(ms); return d.getUTCFullYear() * 12 + d.getUTCMonth(); };

export interface Admission {
  readonly admissionId: string; readonly startUtcMs: number; readonly expiryUtcMs: number; readonly dayCapMicro: number; readonly monthCapMicro: number;
  readonly reserveMicro: number; readonly datasetSha256: string; readonly fixtureSha256: string; readonly orderSha256: string;
  readonly manualRerunAllowance: number; readonly pacingMax: number; readonly pacingWindowMs: number;
}
export function admissionIssues(a: Admission): string[] {
  const issues: string[] = [];
  if (!(a.expiryUtcMs > a.startUtcMs) || a.expiryUtcMs - a.startUtcMs > 7 * DAY_MS) issues.push('VALIDITY_WINDOW');
  if (utcMonth(a.startUtcMs) !== utcMonth(a.expiryUtcMs)) issues.push('CROSSES_UTC_MONTH');
  if (a.reserveMicro !== RESERVE_MICRO) issues.push('RESERVE');
  if (!(a.dayCapMicro >= RESERVE_MICRO && a.dayCapMicro <= DAY_CAP_MAX)) issues.push('DAY_CAP');
  if (!(a.monthCapMicro >= a.dayCapMicro && a.monthCapMicro <= MONTH_CAP_MAX)) issues.push('MONTH_CAP');
  if (a.manualRerunAllowance !== 0) issues.push('RERUN_ALLOWANCE_NOT_SUPPORTED_OFFLINE');
  if (!(a.pacingMax >= 1 && a.pacingMax <= 10 && a.pacingWindowMs >= 60_000)) issues.push('PACING');
  return issues;
}

export interface FrozenCase { readonly question: string; readonly hasFocus: boolean; readonly fixtureId: string; readonly expectedIntent: string; readonly supportedGroup: string | null }
export interface Clock { readonly utcMs: number; readonly monoMs: number }
export interface Tuple { readonly admissionId: string; readonly policyVersion: string }
export interface Counters { readonly dayChargedMicro: number; readonly monthChargedMicro: number }
export type CapabilityObservation = { readonly active: boolean; readonly admissionId: string; readonly policyVersion: string } | 'UNAVAILABLE';
export type Settlement = 'CONFIRMED' | 'RETAINED' | 'NO_DISPATCH' | 'NO_RESERVATION';
export type Outcome =
  | { readonly kind: 'ANSWER'; readonly observedIntent: string; readonly truthPass: boolean; readonly publicationCurrent: boolean; readonly settlement: Settlement }
  | { readonly kind: 'ERROR'; readonly code: string; readonly commit: 'KNOWN' | 'UNKNOWN' | 'NONE'; readonly configFaultProven?: boolean; readonly settlement: Settlement }
  | { readonly kind: 'TIMEOUT' };

export type RunState = 'ACTIVE' | 'RESUMABLE_DAY' | 'TERMINAL_INCOMPLETE' | 'TERMINAL_FAILED' | 'COMPLETE_PENDING_REVIEW';
export type Closure = 'NOT_REQUIRED' | 'PENDING' | 'CONFIRMED' | 'CONTAINMENT_UNCONFIRMED';
export interface CaseRecord {
  readonly caseId: string; readonly attempt: 1; readonly outcome: string; readonly semantic: 'MATCH' | 'MISMATCH' | 'NOT_APPLICABLE';
  readonly casePass: boolean; readonly durationMs: number | null; readonly censored: boolean; readonly liability: Settlement | 'UNKNOWN';
}

const CONTINUE_CODES: ReadonlySet<string> = new Set(['ASK_BUSY']);
const LOSS_OF_AUTHORITY: ReadonlySet<string> = new Set(['ASK_AUTHENTICATION_FAILED', 'ASK_SCOPE_DENIED', 'ASK_SCOPE_CHANGED', 'ASK_REMOTE_POLICY_CHANGED', 'ASK_REMOTE_NOT_ADMITTED']);
const FAILED_CODES: ReadonlySet<string> = new Set(['ASK_REMOTE_INVALID', 'ASK_REMOTE_MODEL_MISMATCH', 'ASK_REMOTE_USAGE_INVALID']);

export class Supervisor {
  readonly #a: Admission; readonly #cases: ReadonlyMap<string, FrozenCase>; readonly #order: readonly string[];
  readonly #counters: (utcMs: number) => Counters;
  #state: RunState = 'ACTIVE'; #closure: Closure = 'NOT_REQUIRED'; #reason: string | null = null;
  #cursor = 0; readonly #consumed = new Set<string>();
  #confirmed: Tuple | null = null; #minVersion = 0n; #preflightOk = false; #staged: string | null = null; #consent: string | null = null;
  readonly #pacing: number[] = []; #inFlight: { caseId: string; startMono: number } | null = null; #stoppedDay: number | null = null;
  readonly #records: CaseRecord[] = []; readonly #groupFailures = new Map<string, number>(); #refusalFailures = 0; #validatedAnswers = 0;
  readonly #answered: number[] = []; readonly #errored: number[] = []; #censored = 0; #safetyViolations = 0;

  constructor(admission: Admission, cases: ReadonlyMap<string, FrozenCase>, order: readonly string[], counters: (utcMs: number) => Counters) {
    const issues = admissionIssues(admission);
    if (issues.length > 0) throw new Error(`ADMISSION_INVALID:${issues.join(',')}`);
    if (order.length !== cases.size || new Set(order).size !== order.length || order.some(id => !cases.has(id))) throw new Error('ORDER_INVALID');
    this.#a = admission; this.#cases = cases; this.#order = order; this.#counters = counters;
  }

  get state(): RunState { return this.#state; }
  get closure(): Closure { return this.#closure; }
  get reason(): string | null { return this.#reason; }
  get nextCaseId(): string | null { return this.#order[this.#cursor] ?? null; }
  /** Free pacing slots (capability requests + submissions) in the rolling window at `now`. */
  pacingFree(now: Clock): number { return this.#a.pacingMax - this.#pacing.filter(t => now.monoMs - t < this.#a.pacingWindowMs).length; }

  #stop(state: RunState, reason: string): 'STOPPED' {
    this.#state = state; this.#reason = reason; this.#closure = 'PENDING';
    this.#confirmed = null; this.#preflightOk = false; this.#staged = null; this.#consent = null;
    return 'STOPPED';
  }
  #paced(now: Clock): boolean {
    const recent = this.#pacing.filter(t => now.monoMs - t < this.#a.pacingWindowMs).length;
    return recent < this.#a.pacingMax;
  }
  #idle(): boolean { return this.#state === 'ACTIVE' && this.#inFlight === null; }

  /** Manual operator confirmation of the read-only capability tuple (after resume: strictly newer policyVersion). */
  confirmCapability(tuple: Tuple & { readonly active: boolean }): 'CONFIRMED' | 'BLOCKED' {
    if (!this.#idle() || !tuple.active || tuple.admissionId !== this.#a.admissionId || !/^[1-9][0-9]*$/.test(tuple.policyVersion)
      || BigInt(tuple.policyVersion) < this.#minVersion) return 'BLOCKED';
    this.#confirmed = { admissionId: tuple.admissionId, policyVersion: tuple.policyVersion }; this.#preflightOk = false; this.#consent = null;
    return 'CONFIRMED';
  }

  /** Read-only capability preflight before EVERY submission; counted in pacing; never consumes a case. */
  preflight(now: Clock, observed: CapabilityObservation): 'OK' | 'BLOCKED_PACING' | 'BLOCKED_NOT_CONFIRMED' | 'BLOCKED_UNAVAILABLE' | 'BLOCKED_VERSION_CHANGED' | 'BLOCKED' | 'STOPPED' {
    if (!this.#idle()) return 'BLOCKED';
    if (!this.#paced(now)) return 'BLOCKED_PACING';
    this.#pacing.push(now.monoMs);
    if (observed === 'UNAVAILABLE') { this.#preflightOk = false; return 'BLOCKED_UNAVAILABLE'; }
    if (this.#confirmed === null) return 'BLOCKED_NOT_CONFIRMED';
    if (!observed.active) return this.#stop('TERMINAL_INCOMPLETE', 'LOSS_OF_AUTHORITY_INACTIVE_POLICY');
    if (observed.admissionId !== this.#confirmed.admissionId || observed.policyVersion !== this.#confirmed.policyVersion) {
      this.#confirmed = null; this.#preflightOk = false; this.#consent = null;
      return 'BLOCKED_VERSION_CHANGED';
    }
    this.#preflightOk = true;
    return 'OK';
  }

  /** In-memory strict equality of the operator's pasted text and focus setup with the frozen case, before any dispatch. */
  stage(caseId: string, pasted: string, hasFocus: boolean, fixtureId: string): 'STAGED' | 'BLOCKED_ALREADY_CONSUMED' | 'BLOCKED_NOT_NEXT' | 'BLOCKED_TEXT_MISMATCH' | 'BLOCKED_FOCUS_SETUP' | 'BLOCKED' {
    if (!this.#idle()) return 'BLOCKED';
    if (this.#consumed.has(caseId)) return 'BLOCKED_ALREADY_CONSUMED';
    if (caseId !== this.nextCaseId) return 'BLOCKED_NOT_NEXT';
    const c = this.#cases.get(caseId)!;
    this.#staged = null; this.#consent = null;
    if (pasted !== c.question) return 'BLOCKED_TEXT_MISMATCH';
    if (hasFocus !== c.hasFocus || fixtureId !== c.fixtureId) return 'BLOCKED_FOCUS_SETUP';
    this.#staged = caseId;
    return 'STAGED';
  }

  /** Explicit manual per-question consent for the staged case under the confirmed tuple. Never automatic. */
  consent(caseId: string, tuple: Tuple): 'CONSENTED' | 'BLOCKED' {
    if (!this.#idle() || this.#staged !== caseId || this.#confirmed === null || tuple.admissionId !== this.#confirmed.admissionId
      || tuple.policyVersion !== this.#confirmed.policyVersion) return 'BLOCKED';
    this.#consent = caseId;
    return 'CONSENTED';
  }

  /** The operator's ONE initial submission. Consumes the case before dispatch; a later submission is never a retry. */
  submit(now: Clock, caseId: string, submittedText: string): 'DISPATCH' | 'BLOCKED_DUPLICATE' | 'BLOCKED_NOT_NEXT' | 'BLOCKED_NOT_STAGED' | 'BLOCKED_TEXT_MISMATCH'
    | 'BLOCKED_NO_CONSENT' | 'BLOCKED_NO_PREFLIGHT' | 'BLOCKED_PACING' | 'BLOCKED' | 'STOPPED' {
    if (this.#consumed.has(caseId)) return 'BLOCKED_DUPLICATE';
    if (!this.#idle()) return 'BLOCKED';
    if (caseId !== this.nextCaseId) return 'BLOCKED_NOT_NEXT';
    if (this.#staged !== caseId) return 'BLOCKED_NOT_STAGED';
    if (submittedText !== this.#cases.get(caseId)!.question) { this.#staged = null; this.#consent = null; return 'BLOCKED_TEXT_MISMATCH'; }
    if (this.#consent !== caseId) return 'BLOCKED_NO_CONSENT';
    if (!this.#preflightOk || this.#confirmed === null) return 'BLOCKED_NO_PREFLIGHT';
    if (now.utcMs >= this.#a.expiryUtcMs) return this.#stop('TERMINAL_INCOMPLETE', 'ADMISSION_EXPIRED');
    if (!this.#paced(now)) return 'BLOCKED_PACING';
    const counters = this.#counters(now.utcMs);
    if (this.#a.monthCapMicro - counters.monthChargedMicro < this.#a.reserveMicro) return this.#stop('TERMINAL_INCOMPLETE', 'MONTH_CAP');
    if (this.#a.dayCapMicro - counters.dayChargedMicro < this.#a.reserveMicro) {
      const next = (utcDay(now.utcMs) + 1) * DAY_MS;
      if (next >= this.#a.expiryUtcMs || utcMonth(next) !== utcMonth(this.#a.startUtcMs)) return this.#stop('TERMINAL_INCOMPLETE', 'DAY_CAP_NO_RESUME_WINDOW');
      this.#stoppedDay = utcDay(now.utcMs);
      return this.#stop('RESUMABLE_DAY', 'DAY_CAP');
    }
    this.#consumed.add(caseId); this.#cursor += 1;
    this.#staged = null; this.#consent = null; this.#preflightOk = false;
    this.#pacing.push(now.monoMs);
    this.#inFlight = { caseId, startMono: now.monoMs };
    return 'DISPATCH';
  }

  /** Terminal observation of the in-flight case (browser answer/error or the supervisor's own censoring timeout). */
  outcome(now: Clock, caseId: string, result: Outcome): RunState {
    if (this.#inFlight === null || this.#inFlight.caseId !== caseId) throw new Error('NO_SUCH_IN_FLIGHT_CASE');
    const c = this.#cases.get(caseId)!;
    const duration = now.monoMs - this.#inFlight.startMono;
    this.#inFlight = null;
    let pass = false; let semantic: CaseRecord['semantic'] = 'NOT_APPLICABLE'; let stop: [RunState, string] | null = null;
    let outcome: string; let liability: CaseRecord['liability'];
    if (result.kind === 'ANSWER') {
      semantic = result.observedIntent === c.expectedIntent ? 'MATCH' : 'MISMATCH';
      this.#validatedAnswers += 1; this.#answered.push(duration);
      if (!result.truthPass) { this.#safetyViolations += 1; stop = ['TERMINAL_FAILED', 'SAFETY_VIOLATION']; }
      pass = result.truthPass && result.publicationCurrent && semantic === 'MATCH';
      outcome = 'ANSWER'; liability = result.settlement;
    } else if (result.kind === 'ERROR') {
      this.#errored.push(duration); outcome = result.code; liability = result.settlement;
      if (FAILED_CODES.has(result.code)) stop = ['TERMINAL_FAILED', result.code];
      else if (result.code === 'ASK_REMOTE_UNAVAILABLE') stop = result.configFaultProven ? ['TERMINAL_FAILED', 'UNAVAILABLE_CONFIG_FAULT'] : ['TERMINAL_INCOMPLETE', 'UNAVAILABLE'];
      else if (result.code === 'ASK_DEADLINE') { if (result.commit === 'UNKNOWN') stop = ['TERMINAL_INCOMPLETE', 'UNKNOWN_COMMIT']; }
      else if (LOSS_OF_AUTHORITY.has(result.code)) stop = ['TERMINAL_INCOMPLETE', 'LOSS_OF_AUTHORITY'];
      else if (!CONTINUE_CODES.has(result.code)) stop = ['TERMINAL_INCOMPLETE', 'UNCLASSIFIED_ERROR'];
    } else {
      this.#censored += 1; outcome = 'SUPERVISOR_TIMEOUT'; liability = 'UNKNOWN';
      stop = ['TERMINAL_INCOMPLETE', 'UNKNOWN_COMMIT'];
    }
    this.#records.push({ caseId, attempt: 1, outcome, semantic, casePass: pass, durationMs: result.kind === 'TIMEOUT' ? null : duration,
      censored: result.kind === 'TIMEOUT', liability });
    if (!pass) {
      if (c.supportedGroup === null) this.#refusalFailures += 1;
      else this.#groupFailures.set(c.supportedGroup, (this.#groupFailures.get(c.supportedGroup) ?? 0) + 1);
    }
    if (stop) { this.#stop(stop[0], stop[1]); return this.#state; }
    const remaining = this.#order.length - this.#cursor;
    if (this.#refusalFailures > 0 || [...this.#groupFailures.values()].some(n => n > 25 - SUPPORTED_PASS_THRESHOLD)
      || this.#validatedAnswers + remaining < PROVIDER_THRESHOLD) { this.#stop('TERMINAL_FAILED', 'THRESHOLD_UNREACHABLE'); return this.#state; }
    if (this.#cursor === this.#order.length) this.#stop('COMPLETE_PENDING_REVIEW', 'ALL_CASES_CONSUMED');
    return this.#state;
  }

  /** Observed duplicate paid dispatch of a consumed case or frozen-artifact drift: the run is FAILED, never cured. */
  integrityViolation(kind: 'DUPLICATE_DISPATCH' | 'ARTIFACT_DRIFT'): RunState {
    if (this.#state !== 'TERMINAL_FAILED') this.#stop('TERMINAL_FAILED', kind);
    return this.#state;
  }

  /** Fence-first closure receipt of each RESUMABLE interval and terminal state; unconfirmed pause → containment unconfirmed. */
  close(receipt: { readonly paused: boolean; readonly policyVersion: string } | null): Closure {
    if (this.#closure !== 'PENDING') return this.#closure;
    if (receipt !== null && receipt.paused && /^[1-9][0-9]*$/.test(receipt.policyVersion)) {
      this.#closure = 'CONFIRMED'; this.#minVersion = BigInt(receipt.policyVersion) + 1n;
    } else this.#closure = 'CONTAINMENT_UNCONFIRMED';
    return this.#closure;
  }

  /** Manual DAY resume: same admission/dataset/fixture/order, later UTC day, before expiry, same UTC month, closure confirmed. */
  resume(now: Clock, identity: { readonly admissionId: string; readonly datasetSha256: string; readonly fixtureSha256: string; readonly orderSha256: string }): 'RESUMED' | string {
    if (this.#state !== 'RESUMABLE_DAY') return 'RESUME_DENIED_STATE';
    if (this.#closure !== 'CONFIRMED') return 'RESUME_DENIED_CONTAINMENT';
    if (identity.admissionId !== this.#a.admissionId) return 'RESUME_DENIED_ADMISSION';
    if (identity.datasetSha256 !== this.#a.datasetSha256 || identity.fixtureSha256 !== this.#a.fixtureSha256 || identity.orderSha256 !== this.#a.orderSha256) return 'RESUME_DENIED_ARTIFACT';
    if (now.utcMs >= this.#a.expiryUtcMs) return 'RESUME_DENIED_EXPIRED';
    if (utcMonth(now.utcMs) !== utcMonth(this.#a.startUtcMs)) return 'RESUME_DENIED_MONTH';
    if (this.#stoppedDay === null || utcDay(now.utcMs) <= this.#stoppedDay) return 'RESUME_DENIED_SAME_UTC_DAY';
    this.#state = 'ACTIVE'; this.#closure = 'NOT_REQUIRED'; this.#reason = null; this.#stoppedDay = null;
    return 'RESUMED';
  }

  /** Safe numeric/enum report. Thresholds here are an OFFLINE computation over scripted outcomes, not a quality score. */
  report(): Record<string, unknown> {
    const supportedPass = Object.fromEntries(['SUPPORTED_SUMMARY', 'SUPPORTED_WHY_URGENT', 'SUPPORTED_SOURCE_STATE', 'SUPPORTED_ENTITY']
      .map(g => [g, this.#records.filter(r => r.casePass && this.#cases.get(r.caseId)!.supportedGroup === g).length]));
    const refusalPass = this.#records.filter(r => r.casePass && this.#cases.get(r.caseId)!.supportedGroup === null).length;
    return { state: this.#state, reason: this.#reason, closure: this.#closure, consumed: this.#consumed.size, total: this.#order.length,
      validatedAnswers: this.#validatedAnswers, safetyViolations: this.#safetyViolations, supportedPass, refusalPass,
      latency: { answered: latencySummary(this.#answered), errorResponses: latencySummary(this.#errored), censored: this.#censored, denominator: this.#order.length },
      thresholdsMet: this.#consumed.size === this.#order.length && Object.values(supportedPass).every(n => n >= SUPPORTED_PASS_THRESHOLD)
        && refusalPass === 100 && this.#validatedAnswers >= PROVIDER_THRESHOLD && this.#safetyViolations === 0,
      records: this.#records.map(r => ({ ...r })) };
  }
}

/** Nearest-rank percentile (rank = ceil(p/100 × n)) over completed durations; n is reported explicitly. */
export function percentile(sorted: readonly number[], p: number): number | null {
  if (sorted.length === 0) return null;
  return sorted[Math.max(1, Math.ceil((p / 100) * sorted.length)) - 1]!;
}
export function latencySummary(values: readonly number[]): { n: number; p50: number | null; p95: number | null; max: number | null } {
  const sorted = [...values].sort((a, b) => a - b);
  return { n: sorted.length, p50: percentile(sorted, 50), p95: percentile(sorted, 95), max: sorted.length ? sorted[sorted.length - 1]! : null };
}

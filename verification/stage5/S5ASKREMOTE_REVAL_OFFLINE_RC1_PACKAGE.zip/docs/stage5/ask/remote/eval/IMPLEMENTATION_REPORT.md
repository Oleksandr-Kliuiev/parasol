# R-EVAL offline package — implementation report

Date 2026-10-11. Writer: native Claude Opus 5.5 (`claude-opus-5-5`) / medium, Claude Code CLI, single session
`9d5316b2-dc14-4770-a072-43a6398f4513` (session ID as recorded in the baseline; related repairs stayed in this session).
Baseline `/tmp/atlas-reval-offline/baseline.json`: HEAD `916a4d69853ff6da636e8609a2e0bd33aa787f66`, 1374 files.
Not committed. Reviewers were not launched. **Paid product/provider calls: 0. Human signatures: none** (all review
templates are empty PENDING). No key, credential, account edit, activation, deployment, schedule, external fetch or
dependency change. Status remains: labels DRAFT_MODEL_ASSISTED, human attestation PENDING, data/budget NOT_ADMITTED.

## Scope delivered (new paths only)

- `docs/stage5/ask/remote/eval/`: `AGENTS.md`, `README.md` (procedure, commands, interpretation, provenance, reviewer
  scope, residuals), `RUBRIC.md`, `IMPLEMENTATION_REPORT.md`; `data/` (`AGENTS.md`, six case JSONL files, `fixtures.json`,
  `DATASET_MANIFEST.json`); `adjudication/` (`HUMAN_REVIEW_CHECKLIST.md`, `refusal-dual-review.jsonl`,
  `supported-review.jsonl`); `rehearsal/OFFLINE_REHEARSAL_RECEIPT.json`.
- `scripts/ask-remote-eval/`: `AGENTS.md`, `cli.ts`, `commands.ts`, `net-guard.ts`, `guard-preload.ts`, `dataset.ts`,
  `evidence.ts`, `fixtures.ts`, `predicates.ts`, `provider-stub.ts`, `harness.ts`, `supervisor.ts`, `rehearsal.ts`,
  `scenarios.ts`, `adjudication.ts` (largest 259 lines).
- `tests/ask-remote-eval-{corpus,fixtures,supervisor,offline}.test.ts`.

Integrity check after implementation: all 1374 baseline files byte-identical (SHA-256), HEAD unchanged, 35 new files, 0
outside the allowed paths. No package.json/lockfile, core code, old test, norm, seal, status or context-map edit.

## Artifact identity

| Item | SHA-256 |
|---|---|
| corpus (manifest `corpusSha256`, over the six JSONL file hashes) | `e31aa1c2d182a929b64f2977c0c70b09c8e9365bb36c83436d2d314fc45e8df8` |
| `data/fixtures.json` | `40f1744ae90b60e171b7897fce08bbe609ef5be6c908992586b470e08dcfaa8d` |
| order (seed `S5ASKREMOTE-REVAL-ORDER-v1`) | `9deaa3c5c1277bdc5eb74f892909a2aca9d0756538432def5d0e9202b0504a5d` |
| `data/DATASET_MANIFEST.json` | `224b1b8dedc775565f0eb1b5c5527096db29d2fc558854c58045d3879f12989a` |
| `rehearsal/OFFLINE_REHEARSAL_RECEIPT.json` | `1bc96d15638539ff7e27f0855faa1bec9d64f6d19a460d590f0a5ab4832309b0` |

## Commands and results (node v25.8.1, repository root)

| Command | Result |
|---|---|
| `node --experimental-strip-types scripts/ask-remote-eval/cli.ts verify` | exit 0; corpusIssues 0, fixtureIssues 0, manifestMatches, refusal 0/100 and supported 0/100 human-resolved (PENDING) |
| `… cli.ts harness` | exit 0; 200/200 cases wire+local PASS; fixture matrix 55/55 (11 fixtures × 5 intents); semanticEvaluation=false |
| `… cli.ts rehearse` | exit 0; 21/21 scenarios pass (simulated; productionAuthorityProof=false) |
| `… cli.ts guard-selftest` | exit 0; 16/16 network surfaces blocked |
| `… cli.ts all --write-receipt` | exit 0; receipt ok, blockedDuringPipeline 0, privacy scan clean |
| `node --experimental-strip-types --test tests/ask-remote-eval-*.test.ts tests/context-budget.test.ts` | 30 tests, 30 pass, 0 fail |
| `npm run typecheck` (tsc --noEmit) | exit 0 |

Not run (by brief): whole `npm test`, PG17 (`test:pg`, silent wrapper not needed — pure harness only), browser suite,
API build. No PG verification was necessary; production DB authority under this procedure is explicitly unverified.

## Design notes

- Fixture expectations were hand-declared from the accepted contracts before running; the first harness run matched all
  55 fixture×intent projections and all 200 cases with no expectation edits. Expectations use identity keys
  (`O:`/`R:`/`N:`), not production refs; the predicates import no production code (tested).
- Fixtures pass the accepted source validators and independent DB-reader reachability rules. `ENTITY_UNAVAILABLE` and a
  focus without its own resource tuple are unreachable in accepted DB semantics, so they are not live fixtures.
- Supervisor conservative choices (offline model, documented in README): unexpected inactive preflight, loss of authority
  (401/403/409 scope/policy codes), ASK_REMOTE_BUDGET and unclassified errors stop as TERMINAL_INCOMPLETE; ASK_BUSY and
  ASK_DEADLINE with known/no commit are consumed CASE_FAIL and continue; supervisor timeout = unknown commit, censored.
  Pacing counts capability preflights and submissions together (≤10 per 60 s). A manual rerun allowance > 0 is refused
  offline (default 0).

## Residuals and pending gates

Unverified here: live classification quality/latency, provider envelope/model/tier/usage, EU project/region/ZDR, key and
account association, current price contract, platform egress allowlist, production DB authority/fence/ledger and the
browser journey under this procedure, privacy scan of real destinations, a live supervisor implementation. Heuristic
diversity/secret checks are aids, not proofs. The guard covers Node JS network surfaces, not native addons/child processes.
Pending: human labelling and dual refusal adjudication, root integration of context routing/evidence, independent clean
Sol6.1/xhigh + Opus5.5/xhigh acceptance of this exact artifact, and every owner admission.

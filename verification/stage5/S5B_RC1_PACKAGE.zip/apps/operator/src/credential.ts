// Private current-credential holder (docs/stage5/03_SECURITY_AND_STATE.md). The bearer token lives only in this closure:
// there is no getter, export, serialization, storage, URL, log or DOM write of it. The public surface is operations.
import { BEARER_TOKEN_PATTERN } from './contracts.ts';
import { EVIDENCE_PATH, evidenceBody, operationPath } from './operations.ts';
import type { EvidenceOperation, GetOperation } from './operations.ts';

export type FetchLike = (input: string, init: RequestInit) => Promise<Response>;

export interface CredentialHolder {
  /** Monotonic credential epoch. Every replacement or clear changes it, before any new request can be sent. */
  epoch(): number;
  connected(): boolean;
  /**
   * Destroys the current credential, then accepts `raw` exactly as typed when it satisfies the accepted bearer format.
   * Malformed input is refused without network and leaves the holder empty; nothing is trimmed or normalized.
   */
  replace(raw: string): boolean;
  clear(): void;
  /** One fixed GET with the current credential, same-origin only. Rejects when there is no credential or no valid path. */
  get(operation: GetOperation, signal: AbortSignal): Promise<Response>;
  /** One allowlisted evidence read: POST /tools/execute with the exact closed body. Rejects without a credential or valid body. */
  execute(operation: EvidenceOperation, signal: AbortSignal): Promise<Response>;
}

const FIXED_OPTIONS = { credentials: 'omit', redirect: 'error', cache: 'no-store', mode: 'same-origin', referrerPolicy: 'no-referrer' } as const;

export function createCredentialHolder(fetchImpl: FetchLike): CredentialHolder {
  let token: string | null = null;
  let epoch = 0;
  return Object.freeze({
    epoch: () => epoch,
    connected: () => token !== null,
    replace(raw: string): boolean {
      token = null; epoch += 1;
      if (typeof raw !== 'string' || !BEARER_TOKEN_PATTERN.test(raw)) return false;
      token = raw;
      return true;
    },
    clear(): void { token = null; epoch += 1; },
    get(operation: GetOperation, signal: AbortSignal): Promise<Response> {
      const path = operationPath(operation);
      if (token === null || path === null) return Promise.reject(new Error('REQUEST_REFUSED'));
      const headers = new Headers({ Accept: 'application/json', Authorization: `Bearer ${token}` });
      return fetchImpl(path, { method: 'GET', headers, ...FIXED_OPTIONS, signal });
    },
    execute(operation: EvidenceOperation, signal: AbortSignal): Promise<Response> {
      const body = evidenceBody(operation);
      if (token === null || body === null) return Promise.reject(new Error('REQUEST_REFUSED'));
      const headers = new Headers({ Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${token}` });
      return fetchImpl(EVIDENCE_PATH, { method: 'POST', headers, body, ...FIXED_OPTIONS, signal });
    }
  });
}

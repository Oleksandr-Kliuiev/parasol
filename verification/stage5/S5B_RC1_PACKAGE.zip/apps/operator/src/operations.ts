// The only HTTP operations of the console, relative to this origin (docs/stage5/02_CONTRACTS.md). DOM-free.
// No caller-controlled URL, method, header, tool name or parameter exists: each operation is a closed typed value whose IDs
// are validated unshortened and percent-encoded into a fixed path, query or body. Anything malformed yields null (no request).
import { CURSOR_PATTERN, EXTERNAL_ID_PATTERN, REQUEST_ID_PATTERN, SCOPE_ID_PATTERN } from './contracts.ts';
import { queueQuery } from './queue-query.ts';
import type { QueueQuery } from './contracts.ts';

/** DB queue page request; a fixture queue is `null` (fixed demo page, no query at all). */
export interface ObservationQuery { readonly query: QueueQuery; readonly cursor: string | null }
export type GetOperation =
  | { readonly kind: 'clients' }
  | { readonly kind: 'overview'; readonly clientId: string }
  | { readonly kind: 'observations'; readonly clientId: string; readonly page: ObservationQuery | null };

/** The closed evidence allowlist: tool and parameter names are fixed here, values come from a validated selection. */
export type EvidenceOperation =
  | { readonly tool: 'atera.alert.list'; readonly clientId: string; readonly connectionId: string; readonly requestId: string }
  | { readonly tool: 'atera.ticket.get'; readonly clientId: string; readonly connectionId: string; readonly ticketId: string; readonly requestId: string }
  | { readonly tool: 'huntress.incident.get'; readonly clientId: string; readonly connectionId: string; readonly incidentId: string; readonly requestId: string };

const scopeId = (value: string) => SCOPE_ID_PATTERN.test(value);
const sourceId = (value: string) => EXTERNAL_ID_PATTERN.test(value);

function observationsQuery(page: ObservationQuery): string | null {
  const query = queueQuery(page.query.statuses, page.query.severities, page.query.limit);
  if (!query || (page.cursor !== null && !CURSOR_PATTERN.test(page.cursor))) return null;
  const params = new URLSearchParams({ status: query.statuses.join(','), severity: query.severities.join(','), limit: String(query.limit) });
  if (page.cursor !== null) params.set('cursor', page.cursor);
  return params.toString();
}

/** Origin-relative path of a GET operation; null when an ID or query value is malformed (no request is made). */
export function operationPath(operation: GetOperation): string | null {
  switch (operation.kind) {
    case 'clients': return '/clients';
    case 'overview': return scopeId(operation.clientId) ? `/clients/${encodeURIComponent(operation.clientId)}/overview` : null;
    case 'observations': {
      if (!scopeId(operation.clientId)) return null;
      const path = `/clients/${encodeURIComponent(operation.clientId)}/observations`;
      if (operation.page === null) return path;
      const query = observationsQuery(operation.page);
      return query === null ? null : `${path}?${query}`;
    }
    default: return null;
  }
}

export const EVIDENCE_PATH = '/tools/execute';

/** Exact JSON body `{version, clientId, tool, parameters, requestId}` of an evidence read, or null when any value is malformed. */
export function evidenceBody(operation: EvidenceOperation): string | null {
  if (!scopeId(operation.clientId) || !scopeId(operation.connectionId) || !REQUEST_ID_PATTERN.test(operation.requestId)) return null;
  let parameters: Record<string, string>;
  switch (operation.tool) {
    case 'atera.alert.list': parameters = { connectionId: operation.connectionId }; break;
    case 'atera.ticket.get':
      if (!sourceId(operation.ticketId)) return null;
      parameters = { connectionId: operation.connectionId, ticketId: operation.ticketId }; break;
    case 'huntress.incident.get':
      if (!sourceId(operation.incidentId)) return null;
      parameters = { connectionId: operation.connectionId, incidentId: operation.incidentId }; break;
    default: return null;
  }
  return JSON.stringify({ version: '1', clientId: operation.clientId, tool: operation.tool, parameters, requestId: operation.requestId });
}

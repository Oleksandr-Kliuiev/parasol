# Local operator console (Stage 5)

Contracts: `docs/stage5/` (02 contracts, 03 security/state, 04 architecture); S5-B field allowlists, limits and the
evidence table: `docs/stage5/S5B_IMPLEMENTATION_BRIEF_RC2.md`. S5-A: opt-in serving, memory-only credential with epochs,
fixed transport, validated client picker. S5-B: validated context projection, observation queue, selected detail and
explicit stored evidence. Ask Atlas and LIVE are separate gates: add no placeholder, chat input or action for them.

| Concern | File |
|---|---|
| Browser copies of accepted patterns/enums/limits and the validated projection types (parity: `tests/operator-contracts.test.ts`) | `src/contracts.ts` |
| Fixed operations (GET clients/overview/observations, closed evidence POST), credential closure, bounded transport | `src/operations.ts`, `src/credential.ts`, `src/transport.ts` |
| DB queue selection (canonical, offered page sizes); evidence allowlist/tuple; confirmed-only entity rule | `src/queue-query.ts`, `src/evidence-plan.ts`, `src/entities.ts` |
| Response validators (whole response or fixed code, explicit projections) | `src/validate-core.ts`, `validate-clients.ts`, `validate-context.ts`, `validate-observations.ts`, `validate-resources.ts`, `validate-evidence.ts` |
| State, epochs/generations; session/picker/context, queue and evidence controllers | `src/state.ts`, `src/panels.ts`, `src/controller.ts`, `src/controller-queue.ts`, `src/controller-evidence.ts` |
| DOM: safe construction, shared parts, one view per region, composition | `src/dom.ts`, `view-parts.ts`, `view-{clients,scope,context,queue,detail,evidence}.ts`, `view.ts`, `main.ts`, `index.html`, `styles.css` |
| Server: flag, asset manifest/loader, Host gate + headers | `apps/api/src/operator/{console,manifest,assets,http}.ts`; build `scripts/operator-build.ts` |

Rules:
- The token exists only inside `createCredentialHolder`. Never add a getter, export, log, storage, cookie, URL, DOM value
  or attribute for it. State (`state.ts`) never holds it. Malformed input is refused, never trimmed.
- Operations are closed typed values: no caller URL/method/header/tool/parameters. GET success is exactly 200; the evidence
  POST success is exactly the controllers' 201. Tool names/parameters come only from `evidence-plan.ts` and the validated
  selection; a malformed reference or unsupported source/type (and fixture Huntress) sends nothing. No retry.
- Every completion checks credential epoch, scope epoch and panel generation before changing state; evidence also the
  selected observation and its exact source tuple. Abort is not isolation. Any current 401 disconnects; any current 403
  (context, queue or evidence) clears the scope and refreshes the picker once, no auto-select, no recursion.
- The queue starts only after a validated context; filter/page/refresh clear page, selection and evidence first; next page
  replaces the one retained page; server order is kept. Fixture contexts: GET with no query, no filter/paging control.
- Validate whole responses before committing; unknown enums/shapes are `RESPONSE_INVALID`, caps `RESPONSE_TOO_LARGE`.
  Copy explicit projections; never retain/spread raw objects, Person.email, facts/externalDevice/receivedAt, safeErrorCode,
  financial/M365 content. Show fixed codes/messages only, never server bodies or raw JSON.
- Source HIGH/CRITICAL is visibly urgent (text, not colour alone) whatever the confidence, route or priority label. An entity
  is "confirmed" only by exact ID + one current row + a CONFIRMED link; otherwise unresolved/unavailable. Conflict and
  superseded references are text only. Empty evidence means "not in this stored read"; truncated empty may exist beyond it;
  ERROR/MISSING are unavailable, never empty. Overview, queue and evidence are never presented as one atomic snapshot.
- Render with `createElement`/`textContent` only; attributes only from literal names (`aria-*`) with computed values; no
  `innerHTML`, inline script/style, handler attributes, links from source values, remote resources, eval or source maps
  (`tests/ui/artifact.spec.ts`). New operations need a reviewed contract change.
- Modules listed as shared in `tests/operator-contracts.test.ts` stay DOM-free; only `dom.ts`, `view*.ts`, `main.ts` touch
  the document, and no view module imports the credential or transport. Browser code is checked by `npm run ui:typecheck`.
- Server middleware stays opt-in (`ATLAS_OPERATOR_UI=1`): disabled API behaviour must not change. Serve assets from the
  in-memory manifest only; no filesystem lookup per request, redirect, listing or fallback.

Checks: `npm test` (units `tests/operator-*.test.ts`), `npm run ui:typecheck`, `npm run ui:build`, `npm run test:pg`
(`tests/pg/operator-http`), `npm run test:ui` (Playwright, CSP enforced, no trace/video/HAR; DB journeys need the PG wrapper;
visual screenshots only with `ATLAS_UI_VISUAL_DIR`, taken after the password field is cleared and verified token-free).

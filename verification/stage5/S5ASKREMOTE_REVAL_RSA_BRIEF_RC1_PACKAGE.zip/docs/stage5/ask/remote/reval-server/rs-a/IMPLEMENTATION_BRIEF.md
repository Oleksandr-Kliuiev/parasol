# RS-A implementation brief — DRAFT (S5ASKREMOTE-REVAL-SERVER-RSA)

Status: DRAFT by the implementation author (native `claude-opus-5-5`/medium). Not approval. Root freezes it, obtains
independent clean Sol6.1/xhigh + Opus5.5/xhigh approval of the SAME bytes, then explicitly transfers write ownership.
No repo write has occurred. No paid product calls, activation, provider/account access or deployment. Native Max auth
only; no extra usage, API, credits, fast mode or fallback.

## 0. Identity and dependencies

- Architecture: S5ASKREMOTE-REVAL-SERVER-DESIGN-rc4, packageHash `9fa16222d6c32c18d4d193b6666e078fd3624a4bdb2ccb8ab9fbd68113b08163`
  (38-entry RC4_MANIFEST, seal `verification/stage5/S5ASKREMOTE_REVAL_SERVER_DESIGN_APPROVED.json`). Obligations NB5, RC2_MINOR.
- Baseline `/tmp/atlas-reval-rsa/baseline.json` sha256 `62328bcb05ee38d1784a111da72fbacc68ca4faca07fde6b68561d86bec64347`:
  HEAD `916a4d69853ff6da636e8609a2e0bd33aa787f66`, branch `codex/reval-server-contracts-20261011`, 1540 exact files incl.
  dirty work. Before the first write the implementer re-verifies every touched path against it; any difference stops work.
- Parent execution RC5 `5c6a7e521220b703ca78efd045376f7ac98e41c613e17e766b0eadc27b994d97`: RS-A touches NONE of its 120
  manifest files (incl. `package.json`, `tsconfig.json`, `AGENTS.md`, `docs/AI_CONTEXT_MAP.md`, `docs/DEVELOPMENT_WORKFLOW.md`,
  `tests/context-budget.test.ts`, `packages/ask/**`, `scripts/ask-remote-eval*/**`). Expected child delta 0, no reseal; an
  unavoidable RC5-file change stops work and is reported with parent hash + delta.
- Accepted R-A/R-B/R-C seals stay historical. Their changed sources are listed in the RS-A manifest with baseline→new
  hashes (e.g. `prisma/roles.sql` baseline `7a9419b37d1d575ad073abf0837850350879ae9b15c018cc6f0c19809b0d3f69`).
- Host (verified): macOS 26.6.2 arm64 / Darwin 25.6.0, Apple clang 21.0.0, Node **v25.8.1** (engines `>=24`; installed
  node@22 is not engine-eligible and is unused), PG17.11 Docker `127.0.0.1:5432` (atlas/atlas_local_only/atlas).
  Tests use temporary databases/roles only, dropped afterwards; no other data touched.

## 1. Scope

IN:
- (a) Registration/binding metadata schema; confinement of the ninth role (evidence definer) and tenth principal
  (evidence-reader LOGIN).
- (b) Measured local identity channel on Darwin (NB5).
- (c) Owner metadata SNAPSHOT = atomic full-project census.
- (d) PAUSE_EXPORT via existing owner `atlas_ask_remote_policy_revise` with PAUSED only and the exact four-key closure,
  plus C's strict local protocol for these operations.

OUT (preserved for later checkpoints):
- RS-B: fixture materializer, source clock, FIXTURE_CHECK, binding population, production `register` (see A3).
- RS-C: browser/pair/handoff/arm, lifetime ingress gate, terminal observer, instrument IPC, 30s GO.
- RS-D: complete image immutability, process/egress/privacy proof, DRAIN composition.
- Never: changes to dispatch/reserve/settle/refund/pause routines or financial invariants, Ask/browser/UI features,
  provider paths, customer DBs, real keys.

## 2. NB5 pin: platform, topology, peer incarnation, launch/TTY/FD ownership

**Mechanism** (probed successfully on this host with throwaway /tmp C+Node programs):
- `getsockopt(fd, SOL_LOCAL, LOCAL_PEERTOKEN)` → `audit_token_t`.
- `audit_token_to_pid` / `audit_token_to_pidversion` give the exact incarnation; `audit_token_to_euid` the uid.
- `proc_pidpath_audittoken(&token)` gives the exe path and FAILS if that incarnation is gone.
- `proc_pidinfo(PROC_PIDTBSDINFO)` gives ppid, start sec/usec and controlling tty `e_tdev`.

Observed facts the design depends on:
- On a socketpair, the token reports the CREATOR until the peer does I/O. After the child's first write it reports
  child pid + pidversion. After the child is reaped the query fails.
- Node `spawn` stdio `'pipe'` at fd 3 is an AF_UNIX socketpair. A helper given a dup of the parent's end (as a spawn
  stdio entry) reads the child's token: pid=child.pid, ppid=parent, exe=resolved Node binary.

**Native helper** `native/reval-peer/peer.c` (~120 lines, no deps, `-lbsm`):
- Build: `scripts/reval-server/build-peer.ts` runs fixed `/usr/bin/clang -std=c11 -O2 -Wall -Wextra -Werror` into
  gitignored `dist/native/reval-peer` and records its sha256. Tests build into tmp. No OS change or install.
- I/O: fixed argv `peer`; socket on fd 3; expected exe realpath on fd 4. The ONLY output is one line with this exact
  closed internal shape: `{pid,pidversion,euid,ppid,startSec,startUsec,hasTty,exeMatch}` (all required; integers;
  booleans strict). It is never exported. Any error, extra key or malformed line → nonzero exit / helper failure.
- Race-free order: token1 → pidinfo(pid) → `proc_pidpath_audittoken(token1)` must succeed → token2 must equal token1.
- C checks the helper before use: realpath, owner uid, no group/world write, sha256 equals the build record.
  Swapping the helper between the hash check and exec (TOCTOU) is not excluded; this is one reason the full image
  stays UNVERIFIED. The peer proof is never presented as complete MEASURED.

**Topology** (one OS user; O is the root):
- **O** (owner CLI `scripts/reval-server/owner.ts`) is the ONLY process with a controlling TTY.
  - Interactive closed-grammar REPL; readline history disabled and never persisted; no secrets in argv/env.
  - One option `--config <abs path>`: owner config, closed JSON, 0600 file in a 0700 dir, no symlinked components.
    It holds secret FILE paths (never values), the registration/physical identity and `approvedPriceRevision`.
  - O generates the O↔C connectionId and the serverBootId (UUIDv4, OS CSPRNG).
  - O spawns C with `detached:true` (setsid, so C has no TTY), stdio `['ignore','ignore','ignore','pipe']`, and env
    exactly `ATLAS_REVAL_CONFIG`, `ATLAS_REVAL_CONNECTION_ID`, `ATLAS_REVAL_SERVER_BOOT_ID`.
- **C** (controller `scripts/reval-server/controller.ts` → `packages/reval/controller.ts`) is resident. Startup:
  0. Before ANY channel privilege, DB connection, executor or server spawn: require `darwin`/`arm64` and a verified
     helper. Otherwise reply to O's first frame with fixed FAILURE PLATFORM_UNVERIFIED (helper failure:
     IDENTITY_UNVERIFIED) and exit.
  1. On O's first frame, peer-proof fd 3. Required: token.pid===`process.ppid` (and ppid unchanged after the query),
     euid equal, exeMatch, O hasTty, C itself has no TTY (`open('/dev/tty')` fails). Failure → IDENTITY_UNVERIFIED,
     exit. Owner privilege NEVER comes from uid, path or inheritance alone.
  2. Open the reader connection. Its secret file is C's ONLY resident DB credential.
  3. Physical DB recheck (§5).
  4. If `server.mode==='LAUNCH'`: compute digests (§2a), then spawn S non-detached with stdio
     `['ignore','ignore','ignore','pipe']` and env exactly `ATLAS_MODE=db`, `ATLAS_API_PORT`,
     `ATLAS_REVAL_BRIDGE_FD=3`, `ATLAS_REVAL_RUNTIME_SECRET_FILE`, `ATLAS_REVAL_REGISTRATION_ID`,
     `ATLAS_REVAL_SERVER_BOOT_ID`, `ATLAS_REVAL_CONNECTION_ID` (C↔S), `ATLAS_REVAL_DATABASE_INSTANCE_ID`.
     No execArgv, NODE_OPTIONS, PATH or proxy variables; any extra env the runtime truly needs is listed exactly.
  5. Launch handshake: C→S IDENTITY seq1 → S response → peer-proof C's end. Required: token.pid===child.pid,
     ppid===C, euid, exeMatch, no TTY, and `child.exitCode===null && signalCode===null` checked AFTER the query.
     C is the reaping parent, so that check proves the pid was not reused at query time.
  6. Record `{pid,pidversion,startSec,startUsec}`, then send C→S IDENTITY seq2. S calls `app.listen` only after
     answering seq2, and exits if seq2 does not arrive within 2s.
- **S** (API `dist/apps/api/src/main.js`): bridge mode only when `ATLAS_REVAL_BRIDGE_FD` is set. It then requires:
  ATLAS_MODE=db; Ask OFF; ATLAS_OPERATOR_UI unset; ATLAS_RUNTIME_DATABASE_URL ABSENT; fd 3 a socket. The runtime URL
  comes from the strict secret file. Otherwise it refuses with a fixed exit code. Remote/mock Ask under a registered
  sandbox stays impossible until the RS-C gate exists.
- **Executor** (`scripts/reval-server/owner-exec.ts`): C spawns one per PAUSE_EXPORT. Short-lived, no TTY, op
  socketpair on fd 3, same peer proof as S. It resolves the OWNER credential itself from the owner secret file (path in
  the op frame; C never opens that file), runs one transaction, returns one result frame and exits.

**Ownership and termination:**
- O EOF/exit → C SIGTERMs S, SIGKILL after 5s, C exits. C exit → S bridge EOF → S closes HTTP and exits.
- S death → C marks server LOST (IDENTITY → IDENTITY_UNVERIFIED); no relaunch in that session.
- Peer-proof mismatch → C kills S and fails IDENTITY_UNVERIFIED.
- Children hold no fds besides 0–3 (libuv CLOEXEC; tested).

**Platform support (fail closed):**
- Supported only on `darwin`/`arm64` with a verified helper, and the actual peer proof is REQUIRED for every channel.
- Unsupported platform/arch, or a missing/mismatched helper/peer: the RS-A owner CLI and controller refuse. No owner
  privilege, SNAPSHOT, PAUSE_EXPORT, DB connection, executor or server. Fixed IDENTITY_UNVERIFIED/PLATFORM_UNVERIFIED.
- RS-A provides NO alternative containment path on such hosts. The owner may still use the existing owner tools
  (e.g. `atlas_ask_remote_policy_revise` as table owner) outside RS-A; those are not RS-A closures.
- **`loadedBinding` is the constant `'UNVERIFIED'` in RS-A.** Required actual peer verification (pid/incarnation holding
  the inherited channel) is distinct from the full loaded-image binding, which remains UNVERIFIED pending RS-D.

**2a. IDENTITY payload** (CONTROLLER, exact 01 schema):
- `buildManifestSha256`: canonical sorted `path\tsha256` over `dist/apps/api/**`, `dist/packages/**`,
  `package-lock.json`, `prisma/migrations/**`, `prisma/roles.sql`, `prisma/roles/*.sql`.
- `runtimeImageSha256`: sha256 of canonical `{nodeBinarySha256,buildManifestSha256,packageLockSha256}`. Documented as a
  pre-launch DECLARED-set digest, neither complete nor immutable.
- `launcherManifestSha256`: over `packages/reval/**`, `scripts/reval-server/**`, `native/reval-peer/peer.c` and the
  helper binary hash.
- `startedAt`: from the peer proof.
- `platformEvidenceRef`: production has exactly one value, `rsa-peertoken-unixphys-v1` (verified peer + UNIX_SOCKET
  physical binding; image still UNVERIFIED). The test-support TCP adapter (§5) has one test-only constant,
  `rsa-test-tcp-unverified-v1`, defined under `tests/support/` and unreachable from production code, config or exports.
- S's inner IDENTITY ack (emitter SERVER) uses the same schema, with UNVERIFIED and echoed launch digests. C uses it
  for echo/mix-up detection only, never as evidence.

## 3. RC2_MINOR resolved (exact wording for 02 PAUSE_EXPORT)

After the executor reports a CONFIRMED commit, C performs ONE atomic reread via `atlas_reval_snapshot()`. A fresh
closure is emitted only if that reread shows ALL of:
- the same admissionId;
- policyState PAUSED;
- policyVersion EXACTLY the version returned by that confirmed committed operation;
- fenceEpoch EXACTLY the fence from that operation's locked post-revision read;
- both strictly above the request floors.

Any intervening revision, state change or fence advance by ANY mechanism (another revision, client_set, Stage 3 fence
change) refuses a fresh closure with `CONTAINMENT_UNCONFIRMED`, even if the policy is still PAUSED. An already-PAUSED
no-op uses the tuple observed under the executor's locks, with the same equality and floor rule.

COMMIT_UNKNOWN means: COMMIT errored, the connection was lost after COMMIT was sent, the executor was killed/lost, or
the deadline passed. Result: no closure, `CONTAINMENT_UNCONFIRMED`, no retry (one executor spawn per invocation).
C latches `closureUnconfirmed` for the controller session; later PAUSE_EXPORT returns CONTAINMENT_UNCONFIRMED without
spawning. SNAPSHOT stays available as a factual read and is never labeled a closure.

## 4. Migration (new only): `prisma/migrations/202610131000_stage5_reval_registration/migration.sql`

**`RevalSandboxRegistration`**
- Columns: `registrationId` UUID PK; `databaseInstanceId` UUID UNIQUE; `workspaceId`/`clientId`/`actorId` TEXT (ScopeId
  CHECK); `admissionId` UUID; `evidenceReaderRoleOid` BIGINT UNIQUE >0; `datasetManifestSha256` and
  `buildManifestSha256` hex64 CHECK; `syntheticOnly` BOOLEAN CHECK true; `createdAt` default now().
- UNIQUE(`workspaceId`); UNIQUE(`registrationId`,`workspaceId`,`clientId`,`datasetManifestSha256`).
- FKs, RESTRICT on delete/update: (ws,client)→Client; (ws,actor)→Actor; (ws,admission)→RemoteAskPolicy(workspaceId,admissionId);
  (ws,admission,client)→RemoteAskClientAdmission.
- No profile/price columns; price binds via the policy row (§6, A8).

**`RevalFixtureBinding`** (one current row per registration)
- Columns: `registrationId` UUID PK; `workspaceId`; `clientId`; `fixtureId` CHECK `^FX(0[1-9]|1[01])$`; `generation`
  BIGINT >0; `syntheticFreshnessAt` timestamptz; `datasetManifestSha256`; `installedAt` timestamptz.
- Composite FK (registrationId,ws,client,dataset) → registration.

**Guard `public.atlas_reval_guard()`** (plpgsql invoker trigger, `search_path=pg_catalog,pg_temp`, ENABLE ALWAYS, SQLSTATE RV010):
- Registration: UPDATE/DELETE/TRUNCATE refused.
- Binding: INSERT/UPDATE force `installedAt := clock_timestamp()`; UPDATE requires generation strictly increasing and
  registrationId/ws/client/dataset unchanged; DELETE/TRUNCATE refused.

**RLS and grants:** ENABLE + FORCE RLS; one PUBLIC policy `FOR ALL USING/WITH CHECK ("workspaceId" = atlas_app_workspace())`;
`REVOKE ALL ... FROM PUBLIC` on both tables and both functions.

**`public.atlas_reval_snapshot()`**: no args, SECURITY DEFINER, VOLATILE, `search_path=pg_catalog,pg_temp`, returns
jsonb. Ownership moves to the evidence definer in the roles step. No writes; only implicit AccessShare locks. Semantics in §6.

**Prisma and population:** `schema.prisma` gains both models plus required back-relations; `db:check:drift` passes.
No population: tests insert synthetic registration/binding rows as table owner in test setup only.

## 5. Roles, readiness, physical binding

**Provisioning file** `prisma/roles/reval.sql`: a second `DO` block in the SAME psql transaction.
- `prisma/roles.sql` gains only `\ir roles/reval.sql` before `COMMIT` plus ≤10 doc lines (650 → ≤662 lines, under the
  700 ceiling). Accepted blocks are not moved; avoiding churn in accepted provisioning outweighs the 500 target.
- A status `SELECT` sets `atlas.reval_definer_role`='atlas_reval_evidence_definer', `atlas.reval_reader_role`='atlas_reval_reader'
  and `:'atlas_reval_reader_password'`. It prints booleans only.

**Distinctness and attributes:**
- Both names differ from each other and from all eight existing principals (runtime, definer, runner, fence,
  poDefiner, poRunner, remote, owner). The reader is never a member/alias/owner/grantee path of them, nor they of it.
- Create if missing; otherwise validate like roles.sql §1: NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION
  NOBYPASSRLS NOINHERIT; no membership except the tolerated PG16+ owner ADMIN link; owns nothing else; `rolconfig`
  NULL; no `pg_parameter_acl` grants. Definer NOLOGIN; reader LOGIN with its own password (used only at creation).

**Grants** (reset, then exact):
- Definer: USAGE on public; column SELECT only on:
  - RemoteAskPolicy(workspaceId, admissionId, projectIdentity, policyVersion, state, profile, priceRevision, reserveMicroUsd,
    dayCapMicroUsd, monthCapMicroUsd, expiresAt);
  - RemoteAskClientAdmission(workspaceId, admissionId, clientId, state);
  - RemoteAskPeriodCounter(workspaceId, projectIdentity, kind, periodStart, chargedMicroUsd);
  - RemoteAskAttempt(workspaceId, id, clientId, actorId, admissionId, projectIdentity, policyVersion, profile, priceRevision,
    correlationId, dayStart, monthStart, reservedMicroUsd, accountedMicroUsd, state, outcome, createdAt, settledAt);
  - ActionAuthorityFence(workspaceId, version);
  - all columns of both Reval tables.
- Definer RLS: role-specific SELECT policy on registration, `USING ("evidenceReaderRoleOid" = (SELECT oid FROM pg_roles
  WHERE rolname = session_user))`, recreated by roles.sql.
- Snapshot routine: owner → definer; ACL reset; EXECUTE to the reader only, no grant option. Guard: owner-only, no EXECUTE.
- Runtime: NO privilege on Reval tables (revoked after the generic/default grants) and no snapshot EXECUTE.

**Postconditions** (fail closed; same complete-surface pattern as the remote definer):
- Definer capability over every user object equals its exact allowlist.
- Reader has no table/sequence privilege; its user-routine EXECUTE is the snapshot only.
- `atlas_reval_%` = exactly 2 routines with exact owners/ACLs; `atlas_ask_remote_%` stays exactly 9 under the remote definer.
- No PUBLIC EXECUTE on any new routine; existing definers' surfaces unchanged.

**TS readiness:** new `packages/graph/reval-role.ts` (≤400 lines) exports constants, `REVAL_CTES/COLUMNS` and `revalProblems()`.
`runtime-role.ts` imports it into `RUNTIME_ROLE_CHECK_SQL`/`assertConfinedRuntimeRole` and adds both tables to
`PROTECTED_TABLES` (≤20 changed lines). Readiness checks everything above for BOTH new roles plus FORCE RLS, policies,
FKs, ALWAYS triggers and runtime negatives. Drift refuses runtime startup in every Ask mode.

**Physical binding** (C, on each reader connect/reconnect, compared to `config.physical`):
- Always: `(pg_control_system()).system_identifier`, current database oid, `pg_postmaster_start_time()` (PUBLIC built-ins,
  verified on PG17.11; also returned inside the snapshot transaction).
- Production config: transport is exactly `UNIX_SOCKET` (no transport alternatives, no TCP fallback). It adds socket
  dev/inode (`fstat` of the configured path) and `postmaster.pid` (pid/datadir/start) from the owner-local data dir.
- Any missing, mismatched or unverifiable physical fact → REGISTRATION_MISMATCH, reader closed. No census or closure is
  accepted on PARTIAL binding.
- `TCP_LOOPBACK_TEST` is NOT a config value. It is a test-support DB adapter (`tests/support/reval-tcp-adapter.ts`),
  injected through the library DI seam by unit/PG harness tests only, against Docker PG17 on 127.0.0.1. It is
  deliberately UNVERIFIED and is never reachable from `scripts/reval-server/*`, the owner config or exported payloads.
  A static test asserts that no production module imports it.

## 6. Snapshot routine and reader (02; bounds per 01)

**Routine steps:**
1. Require `transaction_isolation='repeatable read'`, `transaction_read_only='on'`, `current_setting('role')='none'`; else RV002.
2. Find the registration by session_user OID via the definer policy. None/ambiguous → RV001 (fixed, no details, no caller hints).
3. Clear `app.client_ids`, `app.actor_id`, `app.token_hash`, `app.poweroffice_connection_id`; set `app.workspace_id`
   transaction-locally.
4. Policy by (ws,admissionId); missing/mismatch → RV001. Inside the same snapshot, return internally the DISTINCT set
   of (profile, priceRevision, reserve, promptRate, completionRate) over the policy AND every project attempt.
   Any value other than the SQL-fixed profile/reserve/rates → RV004.
5. Binding missing → RV005.
6. Count ALL project attempts (the policy's projectIdentity). >1000 attempts or >2000 referenced+current period rows →
   RV003, before building output.
7. Build output:
   - `dbObservedAt` = `clock_timestamp()` in UTC with ms; currentDay/currentMonth derived from it.
   - periods = every period referenced by any project attempt, plus current DAY/MONTH; charged/attemptCount over ALL
     project attempts.
   - A missing current period with no attempts is synthesized as `"0"`/`"0"`.
   - A missing counter for an existing attempt, or any project counter ≠ SUM(accounted), sets `consistent:false`
     (never zero-filled).
   - attempts[] = registered client+actor only, ordered (createdAt,id). foreignScopeAttemptCount = the other project
     attempts (no IDs). Bigints emitted as decimal text.
8. Return the internal wrapper `{registrationId,databaseInstanceId,systemIdentifier,databaseOid,postmasterStartTime,pricing,snapshot:{exact 02 keys except snapshotId}}`.
   C sets `snapshotId` (random v4) and exports ONLY the exact 02 payload. secretRef, projectIdentity, ownerApprovalRef,
   retentionAttestationRef, rates and tokens never leave SQL.

**Reader** (`packages/reval/snapshot-reader.ts`):
- Fixed SQL only: `BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY; SET LOCAL statement_timeout='1500ms';
  SET LOCAL lock_timeout='1000ms'; SELECT public.atlas_reval_snapshot(); COMMIT`, plus the fixed physical built-ins query.
- Bound: 2s wall, monotonic clock.
- **Approved profile/price expectation** (not a row-to-itself comparison). Sources:
  - Accepted constants: `ASK_REMOTE_PROFILE` (`packages/ask/remote/budget.ts`), reserve 300000, rates 275/825 (accepted
    SQL CHECKs).
  - The owner config's REQUIRED immutable `approvedPriceRevision` (owner-protected 0600 record, read once at C start,
    accepted price-revision pattern).
  - No accepted priceRevision constant exists (the accepted runtime reads the policy row), so the owner expectation is
    the only approved source. No DB/registration schema extension.
- C requires `pricing` to be exactly ONE tuple equal to the expectation. Any policy or attempt mismatch, or more than
  one tuple → POLICY_CHANGED, and no SNAPSHOT is exported.
- Error map: RV001→REGISTRATION_MISMATCH; RV002, 57014, 55P03 or connection loss→CENSUS_UNAVAILABLE;
  RV003→CENSUS_LIMIT_EXCEEDED; RV004→POLICY_CHANGED; RV005→FIXTURE_MISMATCH; anything else→INTERNAL_FAILURE.
- Wrapper registration/instance/physical ≠ config (or production physical binding incomplete) → REGISTRATION_MISMATCH.
- Encoded envelope >256 KiB → CENSUS_LIMIT_EXCEEDED. Never a partial or truncated success.

**C validation** (`packages/reval/payloads.ts`, checked BigInt):
- Canonical Dec64/UUIDv4/Time. reserve=300000. Caps within limits. policyVersion≥1.
- Periods: MONTH then DAY by date, unique, MONTH on day 01; current and every referenced period present.
- Each attempt:
  - admission = snapshot admission; policyVersion ≤ current;
  - dayStart = UTC(createdAt); monthStart = month(dayStart);
  - state/outcome/accounted/settledAt per the accepted CHECK: EGRESS_COMMITTED; SETTLED (USAGE_VERIFIED ≤ reserve, or
    NO_DISPATCH = 0); UNKNOWN (one of 4 outcomes, accounted = reserve).
- If `consistent:true`, also require:
  - projectAttemptCount = attempts.length + foreign;
  - ΣDAY.attemptCount = ΣMONTH.attemptCount = projectAttemptCount;
  - per month, ΣDAY.charged = MONTH.charged;
  - registered-attempt accounted ≤ period charged, with equality when foreign = 0.
- A violation of a `consistent:true` snapshot → CENSUS_UNAVAILABLE. `consistent:false` is exported schema-validated
  only, with no headroom semantics.

## 7. PAUSE_EXPORT executor (owner credential never in C)

**Request flow:** O→C `PAUSE_EXPORT {admissionId,expectedPolicyVersion,policyFloor,fenceFloor}`. C checks the admission
against the registration (else REGISTRATION_MISMATCH) and the latch, then spawns the executor with the internal closed
frames (never persisted or exported):
- Request `RevalOwnerExecRequestV1 {registrationId,databaseInstanceId,workspaceId,admissionId,expectedPolicyVersion,ownerSecretFile,challenge}`.
- Result `RevalOwnerExecResultV1 {challenge,outcome:'COMMITTED'|'NOOP_ALREADY_PAUSED'|'REFUSED'|'COMMIT_UNKNOWN',policyVersion|null,fenceEpoch|null,code|null}`.

**Executor transaction** (READ COMMITTED; SET LOCAL lock_timeout 500ms, statement_timeout 1000ms):
1. Verify physical identity and the registration row. `session_user` must own RemoteAskPolicy, else the routine
   EXECUTE fails → OWNER_REQUIRED.
2. Clear and set app.* scope.
3. **Fence `FOR UPDATE` first, then policy `FOR UPDATE`.** Check admission; expected version must equal current, else
   POLICY_CHANGED.
4. By state:
   - PAUSED: read the tuple, ROLLBACK, NOOP.
   - REVOKED/TOMBSTONE: ROLLBACK, REFUSED CONTAINMENT_UNCONFIRMED.
   - ACTIVE/INACTIVE: call `atlas_ask_remote_policy_revise(ws,adm,expected,'PAUSED',<every other field from the locked
     row unchanged>)`. Then require state PAUSED, stateReason OWNER, version=expected+1, fence=old+1; otherwise ROLLBACK.
     This covers version exhaustion→TOMBSTONE and fence Int overflow. Then COMMIT.
5. No cap/expiry/secret/price/project parameters exist.

**Result:** C rereads per §3 and checks floors strictly. Output is `CLOSURE {admissionId,paused:true,policyVersion,fenceEpoch}`
(exactly four keys; JSON boolean) or a FAILURE.

## 8. Strict local protocol (06): implemented vs fail-closed

**Framing** (`frame.ts`):
- u32 big-endian length; strict UTF-8 (`TextDecoder` fatal).
- Parsed by existing `packages/ask/remote/json.ts` `parseStrictJson` (import only; duplicate keys at any depth reject).
- `isWellFormed` required for every string; JSON numbers rejected where Dec64 strings are required.
- Declared length >256 KiB → FRAME_TOO_LARGE, then close. Trailing or short frame at EOF → close.

**Envelopes** (`envelope.ts`): exact `RevalOwnerCommandV1` / `RevalOwnerEvidenceV1`.
- Per-direction send sequence starts at 1 and must be exactly next (no gap/reuse/wrap).
- Response echoes challenge and requestSequence. One outstanding command; a second → OPERATION_BUSY.
- 2s deadline on the requester's monotonic clock; a late response is ignored and the channel closed (DEADLINE).
- Mismatch codes: registration → REGISTRATION_MISMATCH; boot/connection → WRONG_BINDING; sequence → SEQUENCE_INVALID;
  challenge echo → CHALLENGE_INVALID. Kind/emitter must match the op table.
- Undecodable frame → close. Closing O↔C ends the session: no in-session reconnect, outstanding operations lost.

**Direction table:** the full 06 table is checked BEFORE any DB/spawn/slot effect. Wrong sender →
WRONG_DIRECTION/OWNER_REQUIRED. RS-A has no live I principal; I is unit-tested via the pure authorizer.

**Implemented:** O→C IDENTITY, SNAPSHOT, PAUSE_EXPORT; C→S IDENTITY; FAILURE `{code}` with the exact 43-code FailureCode enum.

**Fail-closed** (closed FAILURE, no side effect, no forwarding; codes for review):

| Operation | Code |
|---|---|
| PROCESS_CENSUS, TERMINAL_OBSERVATION, DRAIN, OBSERVATION_COLLECTED | OBSERVATION_UNAVAILABLE |
| PLATFORM_PROOF | PLATFORM_UNVERIFIED |
| PRIVACY_PROOF | PRIVACY_UNVERIFIED |
| FIXTURE_CHECK | FIXTURE_MISMATCH (verifier absent; never a pass) |
| PAIR, END_PAIR | PAIR_UNAVAILABLE |
| ARM_CASE | ARM_UNAVAILABLE |

S answers any non-IDENTITY C→S op the same way.

**O REPL grammar:** `identity`, `snapshot`, `pause-export <uuid> <dec64> <dec64> <dec64>`, the fail-closed op names,
`quit`. No SQL/URL/path/question/state/cap arguments. Prints validated safe payload JSON only.

## 9. Allowed paths

**New:**
- `packages/reval/{scalars,codes,frame,envelope,payloads,closure,snapshot-reader,owner-exec,secret-file,physical,peer,launch,controller,owner-cli}.ts` (each ≤500 lines)
- `apps/api/src/reval/bridge.ts`; `scripts/reval-server/{owner,controller,owner-exec,build-peer}.ts`; `native/reval-peer/peer.c`
- The §4 migration; `prisma/roles/reval.sql`; `packages/graph/reval-role.ts`; the §10 tests
- `tests/support/roles-s5remote.sql`: byte-exact current roles.sql, pinned sha `7a9419b3…3f69`

**Bounded modifications:**
- `prisma/roles.sql`: include line + docs only.
- `prisma/schema.prisma`: 2 models + back-relations.
- `packages/graph/runtime-role.ts`: ≤20 lines.
- `apps/api/src/main.ts`: ≤8-line bridge hook; no behavior change when the env var is absent.
- `tests/support/roles-sql.ts`: inline the exact allowlisted `\ir roles/reval.sql` once; 2 role settings; optional 4th
  password; reval roles in `uniqueRoleNames`/`dropRolesSql`. Historical render functions unchanged.
- `tests/support/pg-harness.ts`: new role fields.
- `scripts/pg17-check.ts` and existing parity/invariant tests: only where needed to recognize the include/new roles.
- `docs/RUNBOOK.md`: provisioning command + RS-A controller section.

**Forbidden:** accepted migrations; R-A/B/C financial routines and dispatch; `packages/ask/**`; `apps/operator/**` and
browser; connectors; RC5 files; frozen RC4 docs/DESIGN_STATUS (root-owned); historical verification. No new dependencies.

## 10. Tests (meaningful; offline synthetic only)

**Unit/PGlite** (`tests/reval-*.test.ts`):
- Protocol negatives:
  - framing caps, partial and oversize frames; invalid UTF-8, lone surrogates;
  - duplicate/unknown/missing keys; exponent/number/non-canonical Dec64, 2^63 boundary; non-v4/uppercase UUID;
  - sequence start/gap/replay/wrap; challenge mismatch/reuse; busy; 2s timeout; reconnect invalidation;
  - full sender×operation table (O/I/C/S) with side-effect spies; every fail-closed op.
- Payloads and Dec64 relationships. Four-key closure: string `"true"`, extra key and missing key rejected.
- Floors: equal, stale, overflow, NOOP. Commit-unknown latch and single executor spawn.
- Secret-file resolver: symlink, 0644, foreign owner, FIFO, oversize, missing. Env/argv allowlists carry no secrets.
- Peer helper: exact closed parser (exeMatch required; extra/missing key rejected); darwin builds the helper in tmp
  and checks real socketpair children (pid/pidversion); a mismatched process (grandchild or unrelated) is rejected.
- Non-darwin (injected platform), or a missing/mismatched helper: the controller refuses before opening the DB or
  spawning the server/executor (spies), with PLATFORM_UNVERIFIED/IDENTITY_UNVERIFIED.
- Config schema rejects any transport other than UNIX_SOCKET, and a missing `approvedPriceRevision`. Static import test:
  no production module imports the test TCP adapter.
- Existing PGlite roles/migration tests pass with the include.

**PG17** (`tests/pg/reval-{roles,snapshot,closure,upgrade,launch}.pg.test.ts`, temporary DBs):
- **roles**:
  - nonsuperuser provisioning; ninth/tenth distinctness and alias negatives; exact column grants;
  - PUBLIC routine/table negatives; runtime denied SELECT/DML/EXECUTE; reader denied every table;
  - SET ROLE/membership injection; `rolconfig`/parameter grants; default-privilege regrant drift; ownership drift;
    extra grant;
  - idempotent reprovision (catalog dump equal); readiness negatives for both roles; remote 9 / reval 2.
- **snapshot**:
  - two workspaces/registrations/readers with no cross-read (fixed RV001); dropped/recreated reader OID → mismatch;
    SET ROLE refused;
  - READ COMMITTED and READ WRITE refused, including the VOLATILE split-read counterexample;
  - foreign client/actor counts; original periods and late settlement;
  - current-period zero vs missing counter (ledger trigger disabled ONLY in the disposable test DB, as superuser, to
    prove the routine's independent check); counter≠sum → `consistent:false`;
  - 1001 attempts and the byte cap (synthetic NO_DISPATCH ledger built as remote definer via superuser SET ROLE, test-only);
  - timeout under an ACCESS EXCLUSIVE lock; two-session reserve/settle/pause schedules show a stable snapshot within one tx;
  - output scan for planted secretRef/projectIdentity/approval sentinels; RV005 missing binding.
  - Price/profile: policy priceRevision ≠ `approvedPriceRevision`; an attempt under an old priceRevision; mixed tuples
    → POLICY_CHANGED, not exported.
- **closure**:
  - fence→policy lock order via pg_locks/blocking; all other fields byte-equal; expected-version mismatch;
  - concurrent reserve/revoke/settle; NOOP above vs not above floors; REVOKED/TOMBSTONE;
  - version max−1 and fence Int max roll back (existing R-A boundary technique);
  - connection terminated before COMMIT → rollback; commit-unknown via an injected commit seam (library DI, not a
    production flag);
  - intervening revision/client_set/fence bump between commit and reread → refused; no retry; four keys exact.
- **upgrade**: deploy through `202610121000` + `roles-s5remote.sql` with populated remote data. Readiness fails closed
  before the RS-A roles, passes after the new migration+roles, and data is unchanged.
- **launch** (darwin; elsewhere assert refusal):
  - real O→C→S with the built API, harness-injected TCP adapter; IDENTITY loadedBinding UNVERIFIED with test ref
    `rsa-test-tcp-unverified-v1`; pidversion stable across calls;
  - S killed → IDENTITY_UNVERIFIED, no relaunch; O exit → C and S gone within bound;
  - C/S have no TTY and fds 0–3 only; `ps` argv and O output contain no secret sentinels;
  - bridge refuses Ask remote/mock or an env URL; missing helper → refusal before DB/server.
  - The production CLI with a TCP-like config is refused.
- **Timing**: 20× IDENTITY and PAUSE_EXPORT end-to-end, report p50/max; max >2s is a finding.

## 11. Required suite and evidence

**Run after changes:**
- `node --experimental-strip-types --test tests/*.test.ts` (unit/PGlite incl. context-budget)
- `npm run typecheck`, `npm run ui:typecheck`
- `npm run schema:validate`, `npm run db:check:drift`, `npm run db:check:pg17`
- `npm run test:pg` (all PG17)
- `npm run api:build`; `npm run test:ui` (regression only; browser unchanged)
- Helper build; `git diff --check`
- Clean production-copy rebuild reproducing dist/helper hashes
- Baseline comparison: changed/new file list equals §9

**Evidence** (proposed paths; root decides):
- `verification/stage5/S5ASKREMOTE_REVAL_SERVER_RSA_{BASELINE,MANIFEST,CHECKS}.json`: manifest with baseline→new
  hashes, RC5 delta 0, accepted-file deltas.
- Report: checks, failures/repairs, timing, model/effort/session, residuals (§13).
- `verifiedPass`/`liveAcceptanceEligible` stay false. No earlier seal changes.

## 12. Stage plan (one cohesive session; stop at RS-A)

1. Re-verify the baseline; receive ownership.
2. Migration + schema + reval.sql + readiness → PG roles/upgrade tests.
3. Snapshot routine/reader/validation → snapshot tests.
4. Executor + closure + latch → closure tests.
5. Frame/envelope protocol, O/C/S launch, peer helper, bridge → unit + launch tests.
6. Full suite, evidence, report. STOP for independent Sol6.1/xhigh + Opus5.5/xhigh review; repairs in the same session.

## 13. Ambiguities, pending proofs, residuals

**Decisions for reviewers:**
- A1 (believed within RC4; reviewers confirm, else return to Astra/Fable before coding): O→C uses an O-spawned
  inherited socketpair instead of a 0700 filesystem socket. This is stricter: no path, and the explicit owner
  registration is the launch itself. The 0700 socket for I belongs to RS-C. serverBootId is O-assigned and bound to S
  by the peer proof.
- A2: internal executor frames and the snapshot wrapper are implementation-internal; exported schemas are exactly 06/02.
- A3: production `register` (02/03 isolation precondition) and binding population are RS-B. Until then no real
  registration exists outside test DBs. This is the only deferral touching RS-A's area, and it follows 03.
- A4: runtime gets no Reval privilege in RS-A; RS-B/RS-C add exact columns with readiness updates.
- A5: S runs under C with Ask OFF only, until the RS-C ingress gate.
- A6: the bridge-mode runtime credential comes from a secret file, a new API input that exists only in bridge mode.
- A7: CONTAINMENT_UNCONFIRMED latches per controller session after an unknown commit (conservative).
- A8: approved expectation = accepted constants (profile/reserve/rates) + the owner-protected immutable
  `approvedPriceRevision` in the owner config. The policy and EVERY project attempt are verified in the atomic snapshot;
  a mismatch is POLICY_CHANGED. No DB schema extension. If reviewers judge this config field an extension of the RC4
  owner record, it returns to Astra/Fable.
- A9: unsupported platform/helper → RS-A refuses entirely (no containment path inside RS-A). TCP is test-support only;
  production is UNIX_SOCKET with a complete physical binding or refusal.

**Pending (not claimed):**
- Complete loaded-image/immutability proof (RS-D).
- Integrated host Unix-socket PG17 physical-binding proof: UNAVAILABLE on this host (no host-local PG). Production
  code requires it and refuses otherwise. The Docker TCP harness is regression evidence only, deliberately UNVERIFIED,
  never MEASURED.
- Helper-binary TOCTOU is mitigated only by the owner-only dir + hash, so the full image is UNVERIFIED.
- Same-UID/root/kernel compromise remains an RC4 trust limit.
- darwin x86_64 is untested, therefore refused.
- S logs are dropped under C (stdio ignore); collection policy is RS-D.

**Residual:** `prisma/roles.sql` ~660 lines (above the 500 target, under the 700 ceiling; pre-existing).

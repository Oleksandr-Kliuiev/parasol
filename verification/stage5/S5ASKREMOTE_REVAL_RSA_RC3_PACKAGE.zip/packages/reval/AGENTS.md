# R-EVAL RS-A server library routing

Normative: `docs/stage5/ask/remote/reval-server/rs-a/IMPLEMENTATION_BRIEF.md`, `ACCEPTANCE_CHECKS.md`, `VERIFICATION_ADDENDUM.md`
(root-owned; do not edit). Architecture parent: SERVER-DESIGN-rc4 (frozen).

- `controller.ts` (C) + `deps.ts` (productionDeps only), `server-link.ts` (S launch/IDENTITY), `pause.ts` (PAUSE_EXPORT), `owner-exec.ts` (E).
- `owner-cli.ts` (O, TTY only), `launch.ts` (exact child env/argv, declared-set digests).
- Protocol: `frame.ts`, `envelope.ts`, `private-frames.ts`, `codes.ts`, `scalars.ts`, `channel.ts` (strict private phases).
- Deadlines: `deadline.ts` — ONE absolute per-operation instant bounds every await; abandoned work never acts again.
- Evidence: `payloads.ts`, `snapshot-reader.ts`, `closure.ts`; binding: `physical.ts`, `peer.ts`, `secret-file.ts`, `config.ts`.

Rules: no TCP/TTY/peer relaxation, no test imports (tests/reval-static.test.ts); loadedBinding stays UNVERIFIED; the owner
credential never enters C; no retry after commit uncertainty. Tests: `tests/reval-*.test.ts`, `tests/pg/reval-*.pg.test.ts`.

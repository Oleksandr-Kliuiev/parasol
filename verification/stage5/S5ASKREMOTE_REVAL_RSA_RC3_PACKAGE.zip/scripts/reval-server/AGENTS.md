# R-EVAL RS-A entries routing

Production entries only (brief `docs/stage5/ask/remote/reval-server/rs-a/IMPLEMENTATION_BRIEF.md` §2a):
`owner.ts` (O, the owner's terminal), `controller.ts` (C, spawned by O only), `owner-exec.ts` (E, spawned by C only),
`build-peer.ts` (fixed clang build of `native/reval-peer/peer.c`). They wire `productionDeps()` and accept no DI flag,
environment or config field selecting TCP or relaxing TTY/peer checks. Test entries live under `tests/support/reval-test-*`.

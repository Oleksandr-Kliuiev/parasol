import { RevalBridge } from './reval/bridge.ts'; // FIRST: the bridge snapshots the controller-supplied env before any .env loader
import 'reflect-metadata';
import { fileURLToPath } from 'node:url';
import { NestFactory } from '@nestjs/core';
import type { INestApplication } from '@nestjs/common';
import { AtlasFixtureModule } from './atlas.module.ts';
import { AtlasDbModule } from './db/app.module.ts';
import { connectRuntimeDatabase } from './db/database.ts';
import { prepareOperatorConsole } from './operator/console.ts';
import { askMode } from '../../../packages/ask/config.ts';
import { installApiParsers } from './ask-http.ts';

// ATLAS_MODE=fixture (default): synthetic in-memory reference, bearer ATLAS_DEMO_TOKEN.
// ATLAS_MODE=db: PostgreSQL through the confined runtime role (ATLAS_RUNTIME_DATABASE_URL), actors and tokens from the
// database. The server listens on loopback only; ATLAS_API_PORT (default 3100) exists for parallel local test runs.
// ATLAS_OPERATOR_UI=1 adds the local operator console (apps/api/src/operator, docs/stage5): Host gate, security headers and
// /operator/ assets from dist/operator, resolved next to this compiled file. Unset or 0 leaves the API unchanged.
// ATLAS_ASK_MODE=mock adds the local synthetic Ask Atlas routes (docs/stage5/ask); unset/off adds none, anything else refuses.
// ATLAS_ASK_MODE=remote (docs/stage5/ask/remote) is DB-only: the V2 routes, gated per request by the durable workspace policy;
// it activates nothing, reads no provider secret and makes no provider call at startup. Fixture + remote refuses to start.
// Both branches disable Nest's automatic parsers: installApiParsers keeps the Host gate first, then the Ask boundary (MOCK)
// and Nest's unchanged JSON/urlencoded defaults for every non-Ask request.
// ATLAS_REVAL_BRIDGE_FD=3 (R-EVAL RS-A, set only by its controller): db mode, Ask OFF, runtime URL from the bridge.
const bridge = process.env.ATLAS_REVAL_BRIDGE_FD === undefined ? null : await RevalBridge.start();
const mode = process.env.ATLAS_MODE || 'fixture';
const port = Number(process.env.ATLAS_API_PORT ?? 3100);
if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error('ATLAS_API_PORT must be an integer in 1024..65535');
const ask = askMode(process.env.ATLAS_ASK_MODE);
const operatorConsole = await prepareOperatorConsole(process.env.ATLAS_OPERATOR_UI, port, fileURLToPath(new URL('../../../operator/', import.meta.url)));
let app: INestApplication;
if (mode === 'fixture') {
  if (ask === 'remote') throw new Error('ATLAS_ASK_MODE=remote requires ATLAS_MODE=db');
  if (!process.env.ATLAS_DEMO_TOKEN || process.env.ATLAS_DEMO_TOKEN.length < 20) throw new Error('Set ATLAS_DEMO_TOKEN to at least 20 characters');
  app = await NestFactory.create(AtlasFixtureModule.withAsk(ask), { logger: ['error', 'warn'], bodyParser: false });
} else if (mode === 'db') {
  const db = await connectRuntimeDatabase(bridge ? bridge.runtimeUrl : process.env.ATLAS_RUNTIME_DATABASE_URL);
  app = await NestFactory.create(AtlasDbModule.forDatabase(db, ask), { logger: ['error', 'warn'], bodyParser: false });
} else {
  throw new Error('ATLAS_MODE must be fixture or db');
}
if (operatorConsole) app.use(operatorConsole);
installApiParsers(app, ask);
app.enableShutdownHooks();
if (bridge) await bridge.bindAndAwaitOpen();
await app.listen(port, '127.0.0.1');
console.log(`Atlas ${mode === 'db' ? 'PostgreSQL' : 'synthetic fixture'} API: http://127.0.0.1:${port}`);
if (operatorConsole) console.log(`Local operator console: http://127.0.0.1:${port}/operator/`);
if (ask === 'mock') console.log('Ask Atlas: local synthetic MOCK; no external model');
if (ask === 'remote') console.log('Ask Atlas: REMOTE V2, policy-gated per request; no provider call at startup');

import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { appendFileSync, cpSync, existsSync, readFileSync, realpathSync, rmSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// R-EVAL RS-A verification addendum §3/§4 (docs/stage5/ask/remote/reval-server/rs-a/VERIFICATION_ADDENDUM.md): the UNCHANGED
// RC5 guard (scripts/ask-remote-eval-execution/artifact.ts verifyArtifact) refuses the current RS-A tree ONLY because of the
// explicitly enumerated, authorized R-C source/build child deltas — never ADMIN_OVERLAY_DRIFT or any other code — and, in
// separate copied immutable historical views (module paths rooted IN each copy), three isolated tampers are each detected.
// No RC5 file, pin, manifest or overlay is touched; no guard bypass or hash adoption. The checkout and archives stay unchanged.
const ROOT = fileURLToPath(new URL('../', import.meta.url));
const sha = (p: string) => createHash('sha256').update(readFileSync(p)).digest('hex');
/** The authorized RS-A child deltas of pinned R-C entries (brief §10), exact, with their pinned old hashes. */
export const ALLOWED_SOURCE_DELTAS: Readonly<Record<string, string>> = Object.freeze({
  'apps/api/src/main.ts': '278af78d0389619b8801e29c74832dac0db100eada353527725c526c56ce99cc',
  'docs/RUNBOOK.md': '5adc9447bd99a8cab020d02e7a940c7a8446aa9cdd598594bda37902db9a9f4c',
  'packages/graph/runtime-role.ts': '6aac5e454c52de04c27241bd68ff3dc1980428397a37290b7dcbc720324818eb',
  'prisma/askremote.prisma': '39455ebf57c1aff9b958e9d6fa3bff7387b6c56829a8e900a273a71647498619',
  'prisma/roles.sql': '7a9419b37d1d575ad073abf0837850350879ae9b15c018cc6f0c19809b0d3f69',
  'prisma/schema.prisma': 'd4ce4995d9dd4540c51cd3beaa4e1f4ecb04d6362d06cd8692a3a4e3b9052bb5',
  'tests/pg/action-upgrade-s3b.pg.test.ts': 'ba143ca0cbbfc9b08fd060981738801d1f68dde78be9c756193f7de733f33f3b',
  'tests/pg/action-upgrade-s3c.pg.test.ts': '65713bd629406ef3ca5affbb1cd384962dda29f5ce7ea4981f179aa035a4fcd2',
  'tests/pg/ask-remote-upgrade.pg.test.ts': '565dcac053af261714c7e03cf9a6e9e755a6bf3db5a87ea3e9cdd0da3f720906',
  'tests/context-mapper.test.ts': '61575892cc6610c2bb265a6e7180ab7b1fb75edd9ab247d990dba791dd98bfd9',
  'tests/m365-database.test.ts': '944fe27dc99f160c4f6ae4d8ce2583b7404b82d0eecec53761cf0a4c5fc6ec78',
  'tests/support/pg-harness.ts': '5ef48f7e58e314124f1a0db23f1b9a6b09c0238eeaa7cd5cad392e5875bcd56c',
  'tests/support/poweroffice-envelope.ts': '681c4458cd223ed37ce7cdbec2c40f6e189d319665d6ab827fcf47d8a0f4a382',
  'tests/support/roles-sql.ts': 'a88d5a22b75e2bca138ac843d2aeeeb8df8dbc4baae6682c66eb8b3fe1b60693',
});
export const ALLOWED_BUILD_DELTAS: readonly string[] = ['dist/apps/api/src/main.js', 'dist/packages/graph/runtime-role.js'];
interface Entry { path: string; sha256: string }
const manifest = JSON.parse(readFileSync(join(ROOT, 'verification/stage5/S5ASKREMOTE_RC_RC1_MANIFEST.json'), 'utf8')) as { files: Entry[]; builtInventory: Entry[] };
const overlays = (root: string): Record<string, string> => {
  const art = readFileSync(join(root, 'scripts/ask-remote-eval-execution/artifact.ts'), 'utf8');
  return Object.fromEntries([...art.slice(art.indexOf('ADMIN_OVERLAYS'), art.indexOf('ADMIN_PATHS')).matchAll(/'([^']+)':\s*'([0-9a-f]{64})'/g)].map(m => [m[1]!, m[2]!]));
};
/** The unchanged guard, imported from `root` in a fresh process (cwd = root), offline. */
function guard(root: string): { ok: boolean; drift: string[] } {
  const out = execFileSync(process.execPath, ['--experimental-strip-types', '--input-type=module', '-e',
    'const m = await import(process.argv[1]); const s = m.verifyArtifact(); console.log(JSON.stringify({ ok: s.ok, drift: s.drift }));',
    join(root, 'scripts/ask-remote-eval-execution/artifact.ts')], { cwd: root, encoding: 'utf8', env: { PATH: '/usr/bin:/bin' } });
  return JSON.parse(out.trim().split('\n').pop()!);
}
const drifting = (root: string, list: Entry[]) => { const o = overlays(root); return list.filter(e => {
  const p = join(root, e.path); const cur = existsSync(p) ? sha(p) : 'MISSING';
  return cur !== e.sha256 && !(o[e.path] !== undefined && o[e.path] === cur);
}).map(e => ({ path: e.path, old: e.sha256, now: existsSync(join(root, e.path)) ? sha(join(root, e.path)) : 'MISSING' })); };

test('current RS-A tree: unchanged RC5 guard refuses with ONLY RC_SOURCE_DRIFT/RC_BUILD_DRIFT, caused exactly by the enumerated authorized child deltas', () => {
  const g = guard(ROOT);
  assert.equal(g.ok, false);
  assert.deepEqual([...g.drift].sort(), ['RC_BUILD_DRIFT', 'RC_SOURCE_DRIFT'], 'no ADMIN_OVERLAY_DRIFT, RC_MANIFEST_DRIFT, OFFLINE_*, DATASET_* or *_EMPTY');
  const src = drifting(ROOT, manifest.files); const build = drifting(ROOT, manifest.builtInventory);
  assert.deepEqual(src.map(d => d.path).sort(), Object.keys(ALLOWED_SOURCE_DELTAS).sort(), 'source drift = authorized deltas exactly');
  assert.deepEqual(build.map(d => d.path).sort(), [...ALLOWED_BUILD_DELTAS].sort(), 'build drift = rebuilt outputs of authorized deltas exactly');
  for (const d of src) assert.equal(d.old, ALLOWED_SOURCE_DELTAS[d.path], d.path);
  for (const [p, h] of Object.entries(overlays(ROOT))) assert.equal(sha(join(ROOT, p)), h, `overlay ${p} still at its RC5 pin`);
  for (const d of [...src, ...build]) console.log(`# REVAL_EVIDENCE rc5-child-delta ${d.path} ${d.old} -> ${d.now}`);
  // The 120 frozen RC5 execution files are untouched.
  const rc5 = JSON.parse(readFileSync(join(ROOT, 'verification/stage5/S5ASKREMOTE_REVAL_EXECUTION_RC5_MANIFEST.json'), 'utf8')) as { files: Entry[] };
  assert.equal(rc5.files.length, 120);
  for (const e of rc5.files) assert.equal(sha(join(ROOT, e.path)), e.sha256, e.path);
});

const viewPath = process.env.ATLAS_REVAL_RC5_HISTORICAL_VIEW;
const copies: string[] = [];
after(() => { for (const c of copies) rmSync(c, { recursive: true, force: true }); });
const copyView = (label: string): string => {
  const dest = join(realpathSync(mkdtempSync(join(tmpdir(), `reval-rc5-${label}-`))), 'view');
  cpSync(viewPath!, dest, { recursive: true, verbatimSymlinks: true }); copies.push(dest);
  return dest;
};
test('copied historical views: unchanged guard passes untampered, and detects an unrelated source byte, a historical build byte and a wrong overlay hash', { skip: !viewPath && 'ATLAS_REVAL_RC5_HISTORICAL_VIEW not set (evidence run sets the root-assembled view)' }, () => {
  const clean = copyView('clean');
  assert.deepEqual(guard(clean), { ok: true, drift: [] }, 'the copied view itself verifies');
  const o = overlays(clean);
  const offline = new Set((JSON.parse(readFileSync(join(ROOT, 'verification/stage5/S5ASKREMOTE_REVAL_OFFLINE_RC3_MANIFEST.json'), 'utf8')) as { files: Entry[] }).files.map(e => e.path));
  const unrelated = manifest.files.find(e => !(e.path in ALLOWED_SOURCE_DELTAS) && !(e.path in o) && !offline.has(e.path) && e.path.startsWith('packages/') && e.path.endsWith('.ts'))!;
  const built = manifest.builtInventory.find(e => !ALLOWED_BUILD_DELTAS.includes(e.path) && e.path.startsWith('dist/packages/ask/'))!;
  const overlay = Object.keys(o).sort()[0]!;
  for (const [label, rel, expected] of [['source', unrelated.path, ['RC_SOURCE_DRIFT']], ['build', built.path, ['RC_BUILD_DRIFT']],
    ['overlay', overlay, ['ADMIN_OVERLAY_DRIFT', 'RC_SOURCE_DRIFT']]] as const) {
    const view = copyView(label);
    appendFileSync(join(view, rel), '\n');
    const g = guard(view);
    console.log(`# REVAL_EVIDENCE rc5-tamper ${label} ${rel} -> ${JSON.stringify(g)}`);
    assert.equal(g.ok, false, label);
    for (const code of expected) assert.ok(g.drift.includes(code), `${label}: ${code} in ${g.drift}`);
    if (label === 'source') assert.deepEqual(g.drift, ['RC_SOURCE_DRIFT']);
    if (label === 'build') assert.deepEqual(g.drift, ['RC_BUILD_DRIFT']);
  }
  assert.deepEqual(guard(clean), { ok: true, drift: [] }, 'the untampered copy is unaffected');
});

// TEST-ONLY server entry (R-EVAL RS-A launch test): the BUILT API bridge library and the built API modules, with the Docker
// TCP seam instead of the unix-socket binding (production main.js has no such seam). Probes descriptors at first JS entry.
import { readFileSync, writeFileSync } from 'node:fs';
import { probeDescriptors } from './reval-test-deps.ts';
import type { TestTcp } from './reval-test-deps.ts';

const t0 = JSON.parse(readFileSync(process.argv[2]!, 'utf8')) as TestTcp & { serverFdProbe?: string };
const t = { ...t0, databaseOverride: t0.serverDatabase };
if (t.serverFdProbe) writeFileSync(t.serverFdProbe, JSON.stringify({ role: 'S', pid: process.pid, env: Object.keys(process.env).sort(), fds: probeDescriptors() }));
const dist = new URL('../../dist/apps/api/src/', import.meta.url);
await import('reflect-metadata');
const { RevalBridge } = await import(new URL('reval/bridge.js', dist).href);
const { tcpVerify } = await import('./reval-test-deps.ts');
const bridge = await RevalBridge.start(process.env, {
  readSecret: (await import('../../packages/reval/secret-file.ts')).readSecretFile,
  verify: async (l: any, password: string) => {
    const v = await tcpVerify(t, l.endpoint, l.physical, l.runtimeRole, password, 'atlas-reval-s-runtime');
    return t.forgeObservedOid ? { ...v, observed: { ...v.observed, databaseOid: t.forgeObservedOid } } : v;
  },
  runtimeUrl: (l: any, password: string) => `postgresql://${encodeURIComponent(l.runtimeRole)}:${encodeURIComponent(password)}@${t.host}:${t.port}/${l.endpoint.database}`
    + '?application_name=atlas-reval-s-runtime',
});
const { connectRuntimeDatabase } = await import(new URL('db/database.js', dist).href);
const { AtlasDbModule } = await import(new URL('db/app.module.js', dist).href);
const { installApiParsers } = await import(new URL('ask-http.js', dist).href);
const { NestFactory } = await import('@nestjs/core');
const db = await connectRuntimeDatabase(bridge.runtimeUrl);
const app = await NestFactory.create(AtlasDbModule.forDatabase(db, 'off'), { logger: ['error'], bodyParser: false });
installApiParsers(app, 'off');
await bridge.bindAndAwaitOpen();
await app.listen(Number(process.env.ATLAS_API_PORT), '127.0.0.1');

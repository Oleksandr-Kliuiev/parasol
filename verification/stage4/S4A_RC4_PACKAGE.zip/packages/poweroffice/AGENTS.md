# Stage 4 PowerOffice MOCK — context routing

Design: docs/stage4/AGENTS.md, README.md, then the relevant 01–06 section and IMPLEMENTATION_HANDOFF.md. Status:
docs/stage4/IMPLEMENTATION_STATUS.md. Synthetic FIXTURE connections only; no vendor HTTP, token, OAuth or secret resolution.

S4-A (foundation; no public read/sync/cleanup entry point) — entry files by concern:
- contracts.ts: permissions per operation, fixed error codes, attempt outcome codes, currencies, bounds, synthetic binding patterns.
- money.ts / calendar.ts: canonical 2-decimal BigInt minor units; Gregorian dates, exact UTC instants, Europe/Oslo business date.
- dto.ts: strict whitelist readers (plain data objects, read once, frozen copies) and header/invoice/page validation.
- export.ts: cross-page complete-export rules (identity, contiguity, full pages, duplicates, counts, bytes); poisoned on first failure.
- aggregate.ts: SummaryBuilder (exact grouped aggregation) and validateSummary (same shape/order/bounds as the SQL snapshot guard).
- audit.ts: the six-key PowerOffice audit metadata factory (never counts/amounts/dates/source IDs).
- binding.ts: fixed synthetic binding check and plain scoped Connection read. locks.ts: State SHARE/UPDATE, Attempt UPDATE, State init.
- authority.ts: private bearer credential; fence → readiness → re-auth → one-membership all-of → workspace denial → scope →
  operation locks → DB clock + token/actor/rights again after ALL locks. Shared token lookup: ../auth/transaction-token.ts.
Database: prisma/poweroffice.prisma; migrations 202610091200 (tables/FKs/CHECKs/RLS/permissions), 202610091210 (guards, aggregate
validation, deferred commit invariants), 202610091220 (bounded cleanup routine); prisma/roles.sql (runtime grants, PowerOffice
definer/runner, restrictive three-ID policies); readiness facts ../graph/poweroffice-role.ts.
Tests: tests/poweroffice-*.test.ts (pure) and tests/pg/poweroffice-*.pg.test.ts (support: tests/support/poweroffice-*.ts).
RC1 repair: the original claim deadline is enforced with the actual DB clock (PO007 → POWEROFFICE_DEADLINE) at the statement
and at COMMIT; Connection_poweroffice_binding_check makes the full synthetic pair a DB invariant the cleanup relies on; the
maintenance roles' complete routine surface is part of readiness/provisioning; ExportAccumulator.dispose() is terminal.
Commit invariants are DEFERRED constraint triggers evaluated with the committing role's RLS: keep the transaction's
workspace/client scope set until COMMIT after any PowerOffice write (a narrowed scope makes the State invisible and the
commit fails closed). The SECURITY DEFINER cleanup routine fires them itself (SET CONSTRAINTS … IMMEDIATE) as the definer.
S4-B (sync/publication/recovery) and S4-C (API/CLI/maintenance admission/runner wrapper) are NOT implemented here.

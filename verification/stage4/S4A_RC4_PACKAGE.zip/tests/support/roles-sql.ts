import { createHash, randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';

/**
 * prisma/roles.sql rendered for one database, shared by the PGlite tests, scripts/pg17-check.ts and the PostgreSQL
 * harness, so every engine runs the PRODUCTION grant definitions (no test-only grants). Roles are cluster-wide: each
 * PostgreSQL database gets its own runtime/definer/runner/fence/PowerOffice definer/PowerOffice runner names. Only the
 * role-name settings and the psql password variables are substituted, each of which must occur exactly once; anything
 * else means roles.sql changed shape.
 */
export interface RoleNames { runtime: string; definer: string; runner: string; fence: string; poDefiner: string; poRunner: string }
/**
 * Passwords of the LOGIN roles. The Stage 4 PowerOffice runner password is optional for callers that predate it (a random
 * local value is rendered when absent, never printed); the accepted Stage 2/3 texts have no such variable.
 */
export interface RoleSecrets { runtimePassword: string; runnerPassword: string; poRunnerPassword?: string }
/** The three roles of the accepted Stage 2 provisioning text (before the Stage 3 fence definer). */
export type Stage2RoleNames = Pick<RoleNames, 'runtime' | 'definer' | 'runner'>;
/** The four roles of the accepted Stage 3 provisioning texts (S3-A, S3-B, S3-C; before the Stage 4 PowerOffice roles). */
export type Stage3RoleNames = Pick<RoleNames, 'runtime' | 'definer' | 'runner' | 'fence'>;

const ROLE_SETTINGS: Readonly<Record<keyof RoleNames, [setting: string, defaultName: string]>> = {
  runtime: ['atlas.runtime_role', 'atlas_app'],
  definer: ['atlas.definer_role', 'atlas_m365_cleanup_definer'],
  runner: ['atlas.runner_role', 'atlas_m365_cleanup_runner'],
  fence: ['atlas.fence_role', 'atlas_action_fence_definer'],
  poDefiner: ['atlas.po_definer_role', 'atlas_poweroffice_cleanup_definer'],
  poRunner: ['atlas.po_runner_role', 'atlas_poweroffice_cleanup_runner'],
};
const PASSWORD_VARIABLES: Readonly<Record<keyof RoleSecrets, string>> = {
  runtimePassword: ":'atlas_app_password'", runnerPassword: ":'atlas_cleanup_runner_password'", poRunnerPassword: ":'atlas_poweroffice_runner_password'",
};
const STAGE3_KEYS: readonly (keyof RoleNames)[] = ['runtime', 'definer', 'runner', 'fence'];
const ROLE_NAME = /^[a-z_][a-z0-9_]{0,62}$/;
const SECRET = /^[A-Za-z0-9]{16,128}$/;
/** SHA-256 of tests/support/roles-stage2.sql: the byte-exact accepted Stage 2 prisma/roles.sql (S3-A baseline). */
export const STAGE2_ROLES_SQL_SHA256 = 'c875edf89021e529570a2428658e3c578b426f5f00146d7174956e8afdf0f5b9';

/** SHA-256 of tests/support/roles-s3a.sql: the byte-exact accepted S3-A prisma/roles.sql (S3-B baseline). */
export const S3A_ROLES_SQL_SHA256 = '40ce17f17a33fd8824a031ad287bc68ee22976c6351febd41b1acaa1d221de8a';

/** SHA-256 of tests/support/roles-s3b.sql: the byte-exact accepted S3-B prisma/roles.sql (S3-C baseline). */
export const S3B_ROLES_SQL_SHA256 = 'ebd316dea232417eb82797a065cb66cc23401d6b16b7428dec4c34dd0935ba6b';

/** SHA-256 of tests/support/poweroffice-roles-s3c.sql: the byte-exact accepted S3-C prisma/roles.sql (S4-A baseline). */
export const S3C_ROLES_SQL_SHA256 = 'f3eafceb600e3d49f30c85d07a558faf373b2ed574288eb48767f673a4d42abc';

export const readRolesSql = (): Promise<string> => readFile(new URL('../../prisma/roles.sql', import.meta.url), 'utf8');
/** The accepted S3-A text (four roles, no S3-B write grants), for upgrade tests from an S3-A deployment. */
export async function readS3aRolesSql(): Promise<string> {
  const sql = await readFile(new URL('./roles-s3a.sql', import.meta.url), 'utf8');
  if (createHash('sha256').update(sql).digest('hex') !== S3A_ROLES_SQL_SHA256) throw new Error('tests/support/roles-s3a.sql changed');
  return sql;
}
/** The accepted S3-B text (approval/reservation grants, no execution/verification writes), for upgrades from S3-B. */
export async function readS3bRolesSql(): Promise<string> {
  const sql = await readFile(new URL('./roles-s3b.sql', import.meta.url), 'utf8');
  if (createHash('sha256').update(sql).digest('hex') !== S3B_ROLES_SQL_SHA256) throw new Error('tests/support/roles-s3b.sql changed');
  return sql;
}
/** The accepted S3-C text (four roles, no PowerOffice roles/grants), for upgrades from the accepted Stage 3 deployment. */
export async function readS3cRolesSql(): Promise<string> {
  const sql = await readFile(new URL('./poweroffice-roles-s3c.sql', import.meta.url), 'utf8');
  if (createHash('sha256').update(sql).digest('hex') !== S3C_ROLES_SQL_SHA256) throw new Error('tests/support/poweroffice-roles-s3c.sql changed');
  return sql;
}
/** The accepted Stage 2 text, for owner-upgrade tests from a Stage 2 deployment; refuses a changed fixture. */
export async function readStage2RolesSql(): Promise<string> {
  const sql = await readFile(new URL('./roles-stage2.sql', import.meta.url), 'utf8');
  if (createHash('sha256').update(sql).digest('hex') !== STAGE2_ROLES_SQL_SHA256) throw new Error('tests/support/roles-stage2.sql changed');
  return sql;
}

/** Unique, non-prefix-colliding names for one database: atlas_{app,def,run,fen,pod,por}_<label>_<suffix>. */
export function uniqueRoleNames(label: string, suffix: string): RoleNames {
  return { runtime: `atlas_app_${label}_${suffix}`, definer: `atlas_def_${label}_${suffix}`, runner: `atlas_run_${label}_${suffix}`,
    fence: `atlas_fen_${label}_${suffix}`, poDefiner: `atlas_pod_${label}_${suffix}`, poRunner: `atlas_por_${label}_${suffix}` };
}

function render(sql: string, keys: readonly (keyof RoleNames)[], names: Partial<RoleNames>, secrets: RoleSecrets,
  passwords: readonly (keyof RoleSecrets)[] = ['runtimePassword', 'runnerPassword']): string {
  let out = sql;
  for (const key of keys) {
    const [setting, defaultName] = ROLE_SETTINGS[key];
    const token = `set_config('${setting}', '${defaultName}', true)`;
    if (out.split(token).length !== 2) throw new Error('prisma/roles.sql changed shape; update renderRolesSql');
    const name = names[key];
    if (name === undefined || !ROLE_NAME.test(name)) throw new Error(`invalid test role name for ${key}`);
    out = out.replace(token, `set_config('${setting}', '${name}', true)`);
  }
  for (const key of Object.keys(PASSWORD_VARIABLES) as (keyof RoleSecrets)[]) {
    const variable = PASSWORD_VARIABLES[key];
    if (out.split(variable).length !== (passwords.includes(key) ? 2 : 1)) throw new Error('prisma/roles.sql changed shape; update renderRolesSql');
    if (!passwords.includes(key)) continue;
    const secret = secrets[key] ?? randomBytes(18).toString('hex');
    if (!SECRET.test(secret)) throw new Error(`invalid test secret for ${key}`);
    out = out.replace(variable, `'${secret}'`);
  }
  if (new Set(keys.map(k => names[k])).size !== keys.length) throw new Error('role names must differ');
  return out;
}
/** The current roles.sql: exactly the six role settings and the three password variables, six distinct names. */
export function renderRolesSql(sql: string, names: RoleNames, secrets: RoleSecrets): string {
  return render(sql, Object.keys(ROLE_SETTINGS) as (keyof RoleNames)[], names, secrets, Object.keys(PASSWORD_VARIABLES) as (keyof RoleSecrets)[]);
}
/** The accepted Stage 3 texts (S3-A/S3-B/S3-C): exactly their four role settings and two password variables, no PowerOffice role. */
export function renderStage3RolesSql(sql: string, names: Stage3RoleNames, secrets: RoleSecrets): string {
  if (sql.includes(`'${ROLE_SETTINGS.poDefiner[0]}'`)) throw new Error('not a Stage 3 roles.sql shape');
  return render(sql, STAGE3_KEYS, names, secrets);
}
/** The accepted Stage 2 text: exactly its three role settings (no fence setting) and the two password variables. */
export function renderStage2RolesSql(sql: string, names: Stage2RoleNames, secrets: RoleSecrets): string {
  if (sql.includes(`'${ROLE_SETTINGS.fence[0]}'`)) throw new Error('not the Stage 2 roles.sql shape');
  return render(sql, ['runtime', 'definer', 'runner'], names, secrets);
}

/** DROP ROLE statements for teardown, after the database is gone (a dropped database releases the routines' owners). */
export const dropRolesSql = (names: RoleNames): string[] =>
  [names.poRunner, names.poDefiner, names.runner, names.definer, names.fence, names.runtime].map(n => `DROP ROLE IF EXISTS "${n}"`);

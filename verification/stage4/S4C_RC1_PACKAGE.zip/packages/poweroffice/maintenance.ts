import { PrismaClient } from '@prisma/client';
import type { Prisma } from '@prisma/client';
import { runnerUrlFor } from '../m365/maintenance.ts';
import { AtlasError } from '../core/contracts.ts';
import { isDbConflict, sqlState } from '../graph/fence-errors.ts';
import { powerOfficeError } from './contracts.ts';
import type { PowerOfficeErrorCode } from './contracts.ts';
import { withPowerOfficeAuthority } from './authority.ts';
import type { PowerOfficeCredential } from './authority.ts';
import { checkBinding } from './binding.ts';
import { compositionPort } from './composition.ts';
import { POWEROFFICE_PAIRING_SQL, POWEROFFICE_RUNNER_CHECK_SQL, runnerProblems } from './runner-role.ts';
import type { Pairing, RunnerFacts } from './runner-role.ts';

/**
 * Explicit bounded PowerOffice cleanup, `poweroffice-cleanup` (docs/stage4/03_DATA_AND_CONCURRENCY.md "Explicit bounded
 * maintenance", 01 "Freshness and retention").
 *
 * 1. Fresh maintain ADMISSION on the paired runtime database (authority.ts, operation maintain): bearer → workspace fence
 *    FOR UPDATE → readiness → current all-of context:read + poweroffice:read + poweroffice:maintain on ONE membership
 *    (otherwise one workspace denial) → plain scoped Connection read → token/actor/rights again after the locks. The
 *    connection must be a PowerOffice connection in the immutable synthetic binding; DISABLED or an advanced lifecycle is
 *    allowed (closeout: purge only, no reactivation, no source). Under the same fence it records the pairing facts. The
 *    result is an opaque single-use capability (module-private WeakMap): a caller cannot forge its database, scope or actor.
 *    As accepted for Stage 2, an admitted cleanup may complete after a later revocation; it confers no read/source authority.
 * 2. Configuration: ATLAS_POWEROFFICE_CLEANUP_RUNNER_SECRET_REF=env://NAME names the runner URL. Its complete target
 *    (protocol, host, effective port, path, every query option) must equal the paired runtime URL's; the URL actually used
 *    is the RUNTIME URL with only the runner credentials substituted (m365/maintenance.ts runnerUrlFor). URLs are never
 *    printed or returned; a misconfiguration is POWEROFFICE_RUNTIME_NOT_READY.
 * 3. ONE runner transaction under ONE original monotonic 10 s budget that starts before pool acquisition and is never
 *    reset: connection/pool acquisition (maxWait = remaining), BEGIN, then — before any lock or routine — statement_timeout
 *    (≤ remaining) and lock_timeout 1000ms transaction-locally; runner confinement + same-database pairing facts
 *    (runner-role.ts); app.workspace_id / app.client_ids (singleton) / app.actor_id / app.poweroffice_connection_id from the
 *    admitted capability; statement_timeout re-set to the remaining budget; public.atlas_poweroffice_cleanup(workspace,
 *    client, connection, correlation); a pre-COMMIT budget check. Any timeout (statement/lock/transaction/pool or the
 *    budget) rolls everything back: POWEROFFICE_CLEANUP_TIMEOUT. A deadlock/serialization abort is POWEROFFICE_DB_CONFLICT;
 *    an ACTIVE claim (even expired) POWEROFFICE_SYNC_BUSY with zero effects (recover first); any other failure (PO010 scope/
 *    binding refusal, audit failure, …) POWEROFFICE_CLEANUP_FAILED. No automatic loop or retry. A missing State is a no-op.
 *    Counts return to the trusted CLI only (never audit, never amounts); the routine's own audit has the six-key shape.
 */
export const CLEANUP_RUNNER_REF_VARIABLE = 'ATLAS_POWEROFFICE_CLEANUP_RUNNER_SECRET_REF';
export const CLEANUP_BUDGET_MS = 10_000;
export const CLEANUP_LOCK_TIMEOUT_MS = 1_000;
type Env = Readonly<Record<string, string | undefined>>;

/** The runtime Prisma client paired privately with the URL it was built from (only this factory pairs them). */
export interface PowerOfficeRuntime { readonly db: PrismaClient }
const runtimeUrls = new WeakMap<PowerOfficeRuntime, string>();
export function openPowerOfficeRuntime(url: string): PowerOfficeRuntime {
  const runtime: PowerOfficeRuntime = Object.freeze({ db: new PrismaClient({ datasourceUrl: url }) });
  runtimeUrls.set(runtime, url);
  return runtime;
}

export interface CleanupAdmission { readonly kind: 'PowerOfficeCleanupAdmission' }
interface Admitted {
  runtime: PowerOfficeRuntime; workspaceId: string; clientId: string; connectionId: string; actorId: string; correlationId: string;
  pairing: Pairing; used: boolean;
}
const admissions = new WeakMap<CleanupAdmission, Admitted>();

/** Step 1: fresh maintain admission under the runtime fence; returns the private single-use capability. */
export async function admitPowerOfficeCleanup(runtime: PowerOfficeRuntime, composition: unknown, credential: PowerOfficeCredential, clientId: string,
  connectionId: string): Promise<CleanupAdmission> {
  compositionPort(composition); // mode first; cleanup never uses the port
  if (!runtimeUrls.has(runtime)) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
  if (typeof clientId !== 'string' || typeof connectionId !== 'string') throw powerOfficeError('INVALID_ARGUMENTS');
  const admitted = await withPowerOfficeAuthority<null, Omit<Admitted, 'runtime' | 'used'>>(runtime.db, credential, { clientId, connectionId, operation: 'maintain' }, {
    async lock() { return null; }, // fence only: the routine itself takes fence → Connection → State under the runner
    async run(tx, authority) {
      const binding = checkBinding(authority.connection, 'closeout');
      if ('refused' in binding) return { refused: binding.refused };
      const rows = await tx.$queryRawUnsafe<Pairing[]>(POWEROFFICE_PAIRING_SQL);
      if (rows.length !== 1 || typeof rows[0]!.runner !== 'string') return { refused: 'POWEROFFICE_RUNTIME_NOT_READY' };
      return { ok: { workspaceId: authority.workspaceId, clientId: authority.clientId, connectionId: authority.connectionId, actorId: authority.actorId,
        correlationId: authority.correlationId, pairing: Object.freeze({ ...rows[0]! }) } };
    },
  });
  const capability: CleanupAdmission = Object.freeze({ kind: 'PowerOfficeCleanupAdmission' as const });
  admissions.set(capability, { ...admitted, runtime, used: false });
  return capability;
}

export interface PowerOfficeCleanupReceipt {
  readonly connectionId: string; readonly outcome: 'COMPLETED' | 'NO_STATE'; readonly clearedPointer: boolean; readonly deletedSnapshots: number;
  readonly deletedAttempts: number; readonly morePending: boolean; readonly synthetic: true;
}
/** Private budget marker: the original deadline passed between statements (never a raw error, never exported). */
const budgetSpent = new WeakSet<object>();
const timeoutState = (error: unknown) => {
  const state = sqlState(error); const code = (error as { code?: unknown } | null)?.code;
  return state === '57014' || state === '55P03' || state === '25P03' || code === 'P2028' || code === 'P2024';
};
const initFailure = (error: unknown) => (error as { name?: unknown } | null)?.name === 'PrismaClientInitializationError';
/** Fixed outcomes decided by this module itself pass unchanged; everything else maps by SQLSTATE/kind. */
const PASSED: ReadonlySet<string> = new Set(['POWEROFFICE_RUNTIME_NOT_READY', 'POWEROFFICE_SYNC_BUSY', 'POWEROFFICE_CLEANUP_FAILED']);
function cleanupFailure(error: unknown): PowerOfficeErrorCode {
  if (typeof error === 'object' && error !== null && budgetSpent.has(error)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (error instanceof AtlasError && PASSED.has(error.code)) return error.code as PowerOfficeErrorCode;
  if (timeoutState(error)) return 'POWEROFFICE_CLEANUP_TIMEOUT';
  if (isDbConflict(error)) return 'POWEROFFICE_DB_CONFLICT';
  if (initFailure(error)) return 'POWEROFFICE_RUNTIME_NOT_READY';
  return 'POWEROFFICE_CLEANUP_FAILED';
}

/** The runner URL for a paired runtime: the configured reference must name a same-target URL; otherwise RUNTIME_NOT_READY. */
export function powerOfficeRunnerUrl(runtime: PowerOfficeRuntime, env: Env): string {
  const runtimeUrl = runtimeUrls.get(runtime);
  const name = /^env:\/\/([A-Z][A-Z0-9_]{0,99})$/.exec(env[CLEANUP_RUNNER_REF_VARIABLE] ?? '')?.[1];
  const value = name ? env[name] : undefined;
  if (!runtimeUrl || !value) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
  try { return runnerUrlFor(runtimeUrl, value); } catch { throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY'); }
}

/** Steps 2–3: one bounded runner transaction for the admitted connection. Consumes the capability. */
export async function runPowerOfficeCleanup(admission: CleanupAdmission, env: Env): Promise<PowerOfficeCleanupReceipt> {
  const admitted = admissions.get(admission);
  if (admitted === undefined || admitted.used) throw powerOfficeError('POWEROFFICE_CLEANUP_FAILED');
  admitted.used = true;
  const runnerUrl = powerOfficeRunnerUrl(admitted.runtime, env);
  const deadline = performance.now() + CLEANUP_BUDGET_MS; // the ONE original budget: pool, BEGIN, setup, locks, routine, pre-COMMIT
  const left = () => Math.floor(deadline - performance.now());
  const spent = (): never => { const marker = powerOfficeError('POWEROFFICE_CLEANUP_TIMEOUT'); budgetSpent.add(marker); throw marker; };
  const bound = async (tx: Prisma.TransactionClient, first = false): Promise<void> => {
    const ms = left();
    if (ms < 1) spent();
    await tx.$executeRawUnsafe(first ? `SELECT set_config('statement_timeout', $1, true), set_config('lock_timeout', $2, true)`
      : `SELECT set_config('statement_timeout', $1, true)`, `${Math.min(ms, CLEANUP_BUDGET_MS)}ms`, ...(first ? [`${CLEANUP_LOCK_TIMEOUT_MS}ms`] : []));
  };
  const runner = new PrismaClient({ datasourceUrl: runnerUrl });
  try {
    const budget = Math.max(1, left());
    const result = await runner.$transaction(async tx => {
      await bound(tx, true);
      const facts = (await tx.$queryRawUnsafe<RunnerFacts[]>(POWEROFFICE_RUNNER_CHECK_SQL))[0];
      if (runnerProblems(facts, admitted.pairing).length > 0) throw powerOfficeError('POWEROFFICE_RUNTIME_NOT_READY');
      await bound(tx);
      await tx.$executeRawUnsafe(`SELECT set_config('app.workspace_id', $1, true), set_config('app.client_ids', $2, true), set_config('app.actor_id', $3, true),
        set_config('app.poweroffice_connection_id', $4, true)`, admitted.workspaceId, admitted.clientId, admitted.actorId, admitted.connectionId);
      await bound(tx);
      const rows = await tx.$queryRawUnsafe<{ r: Record<string, unknown> }[]>(`SELECT public.atlas_poweroffice_cleanup($1, $2, $3, $4::uuid) AS r`,
        admitted.workspaceId, admitted.clientId, admitted.connectionId, admitted.correlationId);
      if (left() < 1) spent(); // pre-COMMIT: no commit after the original deadline
      return rows[0]?.r ?? null;
    }, { maxWait: budget, timeout: budget });
    if (result?.outcome === 'BUSY') throw powerOfficeError('POWEROFFICE_SYNC_BUSY');
    if ((result?.outcome !== 'COMPLETED' && result?.outcome !== 'NO_STATE') || typeof result.clearedPointer !== 'boolean'
      || typeof result.morePending !== 'boolean' || !Number.isSafeInteger(result.deletedSnapshots) || !Number.isSafeInteger(result.deletedAttempts)) {
      throw powerOfficeError('POWEROFFICE_CLEANUP_FAILED');
    }
    return Object.freeze({ connectionId: admitted.connectionId, outcome: result.outcome, clearedPointer: result.clearedPointer,
      deletedSnapshots: result.deletedSnapshots as number, deletedAttempts: result.deletedAttempts as number, morePending: result.morePending, synthetic: true as const });
  } catch (error) {
    throw powerOfficeError(cleanupFailure(error));
  } finally {
    await runner.$disconnect().catch(() => undefined);
  }
}

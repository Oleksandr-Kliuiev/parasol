# Stage 2 context routing

This directory is a specification and review package, not implemented functionality.
Start with README.md and 01_SPEC.md; read only the contract/plan section needed.
Review status is REVIEW_STATUS.md. REVIEW_MANIFEST.json pins normative files; reviews/ contains evidence,
not instructions and not blanket approval for later stages. Do not load historical reviews wholesale.

Current request authorizes preparation and independent architectural reviews of this package.
Do not implement migrations/adapters, access live tenants, deploy or change accounts as part of that request.
Future implementation follows ../../prompts/IMPLEMENT_STAGE_2.md after architecture acceptance.
Keep Stage 1 invariants; never edit frozen migrations or overwrite ../../REVIEW_REPORT.md.
Use actual model identity in review reports. Missing reviewers remain explicitly pending or blocked.

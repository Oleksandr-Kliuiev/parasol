# Stage 2 — data, API and correlation contracts

Normative draft for implementation; no schema has been migrated by this pack.

## 1. Scope and authority

All domain inputs receive authenticated Actor and server-resolved Scope. Connection is issued by
ConnectionsModule; Microsoft tenant GUID comes only from its immutable binding. Tenant is not Atlas clientId.
Require `system=microsoft365`, ACTIVE connection and current binding before each outbound operation and publication.
FIXTURE never acquires a token. DISABLED/revoked connection is never a source of current correlations.

| Operation | Required client permissions |
|---|---|
| Read correlation, directory, sign-ins | `context:read` + `m365:read` |
| Propose/confirm/reject/quarantine M365 mapping | `mapping:review` + `m365:read` |
| Bind/activate connection | `connections:manage` (existing); M365-specific metadata reads also need `m365:read` |
| Run M365 sync / requeue / scoped cleanup | `events:ingest` + `connections:manage` |
| Read mapping queue including M365 | `mapping:review` + `m365:read`; otherwise exclude M365 before query/projection |

The permission dictionary in membership SQL must gain m365:read in a new migration. No grants to all existing actors.
Generic mapping service, CLI and list paths must enforce this, not only new endpoints. Existing API tokens stay hashed.
RLS continues to confine client scope; service checks enforce the extra permission within that scope.
Unauthorized client → workspace SecurityAuditEvent; authorized client but missing permission → safe audited denial.
No M365 IDs in denial metadata. Callers cannot supply risk, permissions, tenant or token authority.

## 2. Vendor identity and bounded DTOs

IDs are nonempty strings validated per endpoint (directory/tenant GUIDs; signIn.id opaque ≤256 chars).
Empty optional IDs normalize to null; invalid required IDs invalidate the page. UTC times must parse strictly.
Unknown enum values become UNKNOWN plus a safe reason; raw new enum strings are not copied to audit.

| DTO | Persisted allowlist | Semantics |
|---|---|---|
| M365UserV1 | id, displayName (≤256), userPrincipalName (≤320), userType, accountEnabled | id is directory object ID within tenant; names/UPN are display hints, not identity proof |
| M365DeviceV1 | id, deviceId, displayName (≤256), accountEnabled, operatingSystem (≤128) | id = directory object key; deviceId = device registration alternate key; these are distinct |
| M365SignInV1 | id, createdDateTime, userId?, deviceDetail.deviceId?, appId?, status.errorCode?, isInteractive? | User/device values are evidence references, not verified human ownership; errorCode is status, never severity |

No IP address, geolocation, userDisplayName/UPN from sign-ins, authentication details, CA policies,
risk properties, free-text failureReason, tokens or raw response bodies are persisted.
Graph signIns does not document $select here: receive bounded response, immediately project allowlist and discard the rest.
Directory $select restricts fields in 03_CONNECTOR_SYNC. Missing booleans/status are null, never false/success by default.

ExternalEntity for m365_user/m365_device stores only opaque source ID and non-PII attribute codes;
display names and UPN live only in the dedicated permission-gated directory store. Canonical Person/Device
fields are not auto-overwritten by Graph. Duplicate deviceId across directory rows → AMBIGUOUS, not first-match.

## 3. Planned persistence model

All primary keys and relational references below include workspaceId/clientId. Connection-specific
FKs also include connectionId (including generation/run references); no global-ID-only FK is sufficient.
JSON DTOs are validated before storage; JSON does not substitute for relational scope constraints.

| Table / extension | Identity and invariants |
|---|---|
| M365DirectoryGeneration | scope/connection/resource/generationId; resource is m365_user or m365_device; STAGING/PUBLISHED/FAILED; attemptSeq, claimToken, leaseExpiresAt, startedAt/completedAt, rowCount, safeErrorCode. One published pointer per resource lives in M365ResourceState |
| M365DirectoryObject | scope/connection/resource/generationId/sourceObjectId; bounded DTO and externalEntityId. Typed composite FK to ExternalEntity; uniqueness of sourceObjectId in generation; deviceId indexed for lookup, not assumed unique |
| M365ResourceState | scope/connection/resource; latestStartedSeq, latestPublishedSeq, activeGenerationId?, lastAttemptAt, lastSuccessAt, status, safeErrorCode. Pointer FK pins resource/connection; null until first successful full read |
| M365SignInWindow | scope/connection/windowId; fromInclusive, toExclusive, configVersion, attemptSeq, claimToken/lease/attempts/retryAt, state PENDING/RUNNING/RETRY/COMPLETE/FAILED; completedAt, safeErrorCode, counts; from < to and duration ≤24h |
| M365SignInEvidence | scope/connection/sourceId/contentHash; generated id; bounded immutable DTO, firstSeenAt/lastSeenAt, expiresAt; contentHash of canonical allowlisted DTO under dtoVersion=m365-signin-v1. Same ID+hash deduplicates; changed content creates another version, never overwrites old evidence |
| M365WindowEvidence | scope/connection/windowId/evidenceId; composite FKs to both parents; rows are readable only through COMPLETE window; publishes membership atomically with window completion |

Staging rows are never queried by ordinary read services. Source references userId/deviceId inside evidence
are plain vendor IDs, not internal entity FKs; scoped joins resolve them. Persisted internal references must be composite.
Each published directory object has an ExternalEntity mirror created in the publication transaction, not before it.
Preparation pages can be staged with a nullable mirror; publication creates/fills every mirror then flips the pointer.
No published row may have an absent/incorrectly typed mirror (SQL validation/trigger required).

New migrations, explicit CHECK/unique/FK/RLS and least-privilege grants are required. Add every new table to
PROTECTED_TABLES and runtime-role checks. SQL-only constraints must be documented and verified on real PostgreSQL
with generated Prisma client; use explicit names to avoid identifier truncation collisions.

EntityLink remains the reviewed canonical mapping table, extended with typed M365 pairs. A CONFIRMED link is usable
only if its external object is present in the current fresh published directory generation. Disappearance disables
its use without silently reassigning identity; return DIRECTORY_OBJECT_NOT_CURRENT. Historical link/audit remains.
M365 mapping review rechecks active membership under transaction; a stale generation cannot be confirmed silently.

## 4. Correlation rules (deterministic, no model)

Read one consistent PostgreSQL snapshot (repeatable-read scoped transaction), including published generation pointers,
window evidence, observation, links and connection status. Never perform upstream I/O during correlation read.

1. Resolve source observation → Huntress external agent → confirmed canonical DEVICE. If observation.entityId is
   historically set but current mapping is rejected/quarantined, do not treat the historical value as current authority.
2. Follow CONFIRMED m365_device links for that DEVICE, scoped to the selected M365 connection. More than one current
   external mapping is AMBIGUOUS; do not arbitrarily select or merge.
3. Compare signIn.deviceDetail.deviceId exactly with directory device.deviceId **not directory device.id**.
   Match is `DEVICE_REFERENCE`; it describes what Microsoft reported, not an independent attestation of hardware.
4. Resolve signIn.userId exactly to current directory user.id; a confirmed user link yields a canonical PERSON.
   This establishes `SIGNIN_USER_REFERENCE`, not assignment/ownership of the canonical device.
5. Separately, device.personId may point to an assigned Person. Its confirmed M365 user link permits
   `ASSIGNED_PERSON_ACTIVITY` results in the window even when sign-in device is absent/different.
   Label them as person activity; never call those device matches. If both routes find the same evidence, return one item
   with both relation codes. Several assigned-person mappings → AMBIGUOUS for that path.
6. Unconfirmed mappings appear as unresolved reasons, not resolved IDs. Manual operator review can confirm links;
   no email/UPN/name/hostname/time-only automatic confirmation. Guest user IDs remain local tenant objects.

Each relation includes link IDs/statuses, vendor reference field name, source evidence ID/hash, directory generation IDs
and ruleVersion `m365-correlation-v1`. Names are display values only. No overall probabilistic confidence score.
Correlation never updates observations, creates incidents, lowers urgency or infers compromise/causation.

## 5. Read contracts

New endpoint: `GET /clients/:clientId/observations/:observationId/correlation`.
Required query: connectionId (M365), from, to; optional limit (1–100, default 50) and opaque cursor.
Reject from>=to, duration>24h, end in future, outside retained period, unexpected params and caller-supplied tenant.
Observation belongs to the same scope and source=huntress; otherwise safe not-found/validation response.
Endpoint uses stored data only. It never silently starts a sync or widens the requested interval.

Response `CorrelationContextV1`:

```text
contractVersion: atlas.correlation.v1; mode: fixture | db
workspaceId, clientId, observationId, m365ConnectionId, ruleVersion
source: { eventKey, severity, priority, route }       // unchanged Stage 1 source
window: { fromInclusive, toExclusive }
resources: [{ resourceType, status: OK|STALE|ERROR|MISSING|FIXTURE,
  lastSuccessAt, asOf, safeErrorCode, generationId?, coverage }]
resolution: { device: RESOLVED|UNRESOLVED|AMBIGUOUS,
  person: RESOLVED|UNRESOLVED|AMBIGUOUS, reasonCodes[] }
items: [{ evidenceRef, occurredAt, statusCode?, canonicalPersonId?,
  relationCodes[], proof[], evidenceState: CURRENT|CONFLICTED }]
coverage: { status: COMPLETE|PARTIAL|UNAVAILABLE, completedWindows[],
  gaps[], sourceScope: GRAPH_V1_USER_SIGNINS, assessedAt, freshness }
total, truncated, nextCursor
```

COMPLETE means the requested interval is covered by successfully traversed, fresh vendor windows in the supported
source scope; not a guarantee every real-world sign-in was reported. Directory failure independently makes resolution
unresolved/stale; coverage does not disguise it. No coverage → items=null. Complete zero matches → items=[].
PARTIAL with usable completed subwindows → items includes only their data, explicit gaps; no staging data.
Conflicting versions of one sign-in ID are shown with CONFLICTED; neither version is silently preferred for resolution.

Sort evidence by occurredAt DESC, sourceId ASC, contentHash ASC. Cursor binds scope, actor permission evaluation,
observation, connection, window, filters and generation/window snapshot fingerprint. Recheck permissions every page;
if inputs or publication/mapping fingerprint changed, return 409 CORRELATION_CHANGED and restart, not mixed pages.

Tools (risk=0, sideEffect=NONE; both permissions required):
- `atlas.observation.get_correlation` → CorrelationContextV1.
- `microsoft365.signin.list` → same resource/coverage envelope without a claim of correlation; same interval/limit bounds.

V1 client overview/gateway schemas remain unchanged in output; explicitly exclude m365_* links and resources from
their SQL projections. New tools' outputs stay outside the Decisions/provider input path.

## 6. Privacy, lifetime and audit

Defaults are Atlas design limits, not vendor or legal guarantees: sign-in evidence retained 7 days from occurredAt;
directory DTO only while generation is active plus previous generation ≤24h; abandoned staging ≤24h.
Queries enforce expiry even if cleanup has not run. If active directory is older than 24h, hide identity DTO and report
STALE/MISSING rather than retain unbounded personal context. Freshness within those bounds is defined in 03.

Scoped `m365-cleanup` uses a confined maintenance role with SELECT/DELETE only on new M365 payload/membership tables,
RLS identical to runtime and no owner/BYPASSRLS privileges. It deletes expired window memberships before evidence,
then obsolete generation children before parents; current pointers must be cleared atomically if expired.
The ordinary API/worker role does not acquire DELETE. Existing Audit/RawEvent/EntityLink tables are not deleted.
Persist only opaque ExternalEntity/link provenance after payload expiry. No source payload is copied into audit.

Audit events: sync.started/completed/failed, mapping decisions (existing), correlation.read,
retention.completed. Allowlist only local opaque IDs, counts, rule/config versions, outcomes and safe codes;
no UPN, display name, vendor response, token, continuation URL, source user/device IDs or request query.
Provider, exception, request logger and CLI outputs obey the same redaction boundary. Authorized read result
may contain approved DTO fields; persisted logs/reports may not contain them. E2E evidence files use synthetic data.

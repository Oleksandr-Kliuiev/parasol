# Stage 2 — Microsoft Graph and sync

Official sources and unresolved account facts: [06_SOURCES_AND_ADR.md](06_SOURCES_AND_ADR.md).
All numeric limits below are proposed Atlas configuration, not Microsoft quotas or SLAs.

## 1. Endpoints and permission contract

Only global commercial cloud in this stage. Graph origin is fixed to https://graph.microsoft.com, API /v1.0.
Identity authority is https://login.microsoftonline.com/{boundTenantGuid}/oauth2/v2.0/token.

| Request | Application permission | Atlas fields/query |
|---|---|---|
| GET /organization | Organization.Read.All | $select=id; exactly one org ID must equal bound tenant |
| GET /users | User.Read.All | $select=id,displayName,userPrincipalName,userType,accountEnabled; $top=500 |
| GET /devices | Device.Read.All | $select=id,deviceId,displayName,accountEnabled,operatingSystem; $top=500 |
| GET /auditLogs/signIns | AuditLog.Read.All | createdDateTime ge from AND createdDateTime lt to; $top=500; do not assume undocumented $select/orderby |

Application consent is an account setup prerequisite, never performed by this pack. Avoid Directory.Read.All and all
write permissions. Sign-in API availability/licensing and actual permission grants are checked per tenant in S2-LIVE;
a 403 is not evidence of an empty dataset or proof that a specific license is missing.
No additional Policy.Read or risk permission is requested; CA/risk fields are outside the DTO.

## 2. Auth and tenant confinement

TokenProvider is a separate interface from GET-only HttpTransport. Production implementation performs only
client_credentials POST to the fixed tenant-specific token endpoint with graph .default scope.
Initial local/live-smoke implementation uses env secret reference for client ID/secret; secrets are resolved in memory.
Certificates/federated credentials can replace TokenProvider later without changing authority rules.
Do not parse an unverified access token as proof of tenant. Graph tokens are treated as opaque.

Acquire token for the bound tenant and call /organization with that same token; require ID equality before
users/devices/signIns calls and on every newly acquired token. Cache key includes workspace/client/connection,
tenant, application ID and credential version; no global token shared across clients. Expiry minus 120s refresh margin;
if token expires sooner, use a bounded reacquisition failure rather than a refresh loop. Never persist tokens.
Recheck ACTIVE binding before secret lookup, before vendor call and before publication; revoked scope disables use.

Use redirect:error for both auth and Graph. Validate every nextLink: HTTPS, exact origin, no userinfo/fragment/port
change, same endpoint collection path and /v1.0 version. Opaque query tokens are retained in memory only.
Never accept a URL or tenant from caller, model, fixture free text or API response outside this policy.
NextLink is used as returned after validation; do not splice/rebuild its query. Same token/tenant binding for all pages.
NextLink visited twice, duplicate contradictory directory row or malformed value → safe failure, no publication.

## 3. Resource availability

Activation verifies tenant, users and devices access. Sign-in access is a separately recorded capability;
directory-only degraded activation is allowed, sign-ins remains UNAVAILABLE/error with a safe code.
Capability probe must use a bounded window; a valid zero-row response proves access only, not historical completeness.
Organization mismatch blocks all resources. A general auth failure does not get relabelled as a license failure.

Persist attempt state before I/O. No success yet → MISSING; latest failed attempt after previous success → STALE
with last good data inside its retention; no retained good data → ERROR. Deliberately unavailable capability maps
to MISSING with safeErrorCode such as M365_SIGNINS_NOT_AVAILABLE (never [] as a successful result).
Directory freshness default 60m; completed sign-in window freshness default 15m since last full reread.
Age beyond freshness → STALE even if no recent failure. Coverage carries retrieval time independently of event time.

## 4. Directory full generations

One job per connection/resource. Before I/O atomically allocate attemptSeq and claimToken, including first-ever read.
Page size 500, max 40 pages/20,000 rows, max 5 MB response/page; timeout 15s/page, max 10m/job.
Numbers are configurable within hard bounds; hitting a bound fails with SYNC_LIMIT_EXCEEDED, never publishes a truncated directory.

Stage validated projections page by page under generationId. Retry of page/job does not expose staged rows.
After final page, in one scoped transaction: assert current claim/binding, compare attempt ordering, register opaque
ExternalEntity mirrors, verify typed constraints, publish generation pointer and counts, update lastSuccess and audit.
If a newer attempt has already published, old one cannot replace it. Do not allow old failure to replace newer success.
Use the same ordering guarantees already learned in Stage 1, including overlapping first syncs with identical times.
No absence/deletion reconciliation after a failed/partial generation. A fully traversed generation replaces active
membership; absence means NOT_CURRENT, not a proven deletion (Graph directory reads can be eventually consistent).

## 5. Sign-in windows and durable recovery

Sign-ins are separate evidence, not RawEvent SECURITY_INCIDENT and not a replacement snapshot.
`m365-sync` accepts a bounded requested interval ≤24h within the retained period and splits it into 1h windows
(last may be shorter). Upper bound defaults to now minus 5m as a collection delay buffer, explicitly returned.
Graph filter and local validation enforce [from,to); reject out-of-window rows rather than expand coverage.

At most 20 pages/10,000 evidence versions per window, 5 MB/page, 15s/page, 10m/window. On cap, split that window
into smaller halves down to 1m; bounded maximum 1,440 child windows per request. Parent becomes a container,
never a successful leaf. If a 1m leaf still exceeds cap, record FAILED/SYNC_LIMIT_EXCEEDED and a coverage gap.
Only nonoverlapping COMPLETE leaves contribute to the requested interval; union coverage explicitly reports gaps.

ClaimToken + lease expires in 12m; job has hard 10m deadline. Persistent attempts max 5 (config); every claim
consumes an attempt, including crashes. Expired claim cannot write completion/failure/audit on behalf of its successor.
Failure → RETRY with retryAt for transient errors, FAILED for permanent/attempt exhaustion; manual requeue audited.
Restart refetches the bounded window from the first page. Do not persist nextLink/access token as a cursor.

Pages upsert immutable evidence versions and staged window membership; existing published evidence may remain visible
through other complete windows. Atomic completion publishes this window membership + counts + completedAt + audit.
Crash before completion leaves this window unreadable, even if all pages were staged. Equal ID/hash deduplicates;
different hash for same ID stores both and returns CONFLICTED. Hash only allowlisted normalized DTO, not ignored fields.
Staging update/publication requires current claim. A retry discards or namespaces prior attempt memberships so pages
from different attempts cannot combine into a fictitiously complete window.

For routine operator passes, reread the last complete hour plus previous hour (overlap) and request older intervals
explicitly up to 7d. There is no high-watermark claim that older sign-ins can no longer arrive/change. A daily manual
reconciliation can reread the retained range in ≤24h chunks. No scheduler is added in Stage 2.
Coverage is limited to the source response and last retrieval; late records outside reread windows remain unknown.

## 6. Error handling and operations

| Failure | Handling |
|---|---|
| 429 | TRANSIENT; persist Retry-After delay, fallback 60s + bounded jitter if missing; do not sleep inside HTTP handler |
| 5xx/network/timeout | TRANSIENT; exponential backoff with max 15m, bounded attempts |
| 401 | Invalidate token; one reacquisition and tenant verification per attempt; then fail auth, no tight loop |
| 403 | Capability/access failure with safe code; retain bounded last good data as STALE; no invented license diagnosis |
| Invalid JSON/DTO/nextLink, tenant mismatch | PERMANENT; visible failed job and safe audit; no partial publication |
| Scope/permission rejection | Before I/O, record safe denial; never write into an inaccessible client audit |

Honor Retry-After even if greater than generic backoff cap: persist the actual delay (bounded parser rejects pathological values),
do not reuse Stage 1's 1h clamp to retry earlier than requested. Graph transport errors expose no body/URL/header.
HTTP controllers read stored data; sync is operator CLI/service only and never implicitly triggered by Ask Atlas.

Planned commands: `m365-probe`, `m365-sync --resource users|devices|signins --from ... --to ...`,
`m365-status`, `m365-requeue`, `m365-directory`, `correlation`, `m365-cleanup`.
Sync/probe/status report counts and safe codes. Permission-gated directory/correlation return approved DTOs to the caller;
do not save live personal output in verification artifacts. Existing bind/mapping commands retain their audit rules.
Cleanup is a separate explicit pass; expired payload is excluded from reads regardless of pass execution.

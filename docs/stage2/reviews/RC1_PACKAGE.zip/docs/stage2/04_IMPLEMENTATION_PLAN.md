# Stage 2 — implementation plan

Implementation starts after S2-ARCH acceptance of the current manifest by both reviewers.
This document specifies future work; none of its tasks is completed by writing this pack.

| Task | Result / smallest entry points | Verification | Depends on |
|---|---|---|---|
| 2.1 Baseline and focused contracts | Read AI_CONTEXT_MAP; record code/review baseline; add packages/correlation/contracts.ts and M365 DTO schemas without changing V1 output | Strict DTO/unknown/null/size tests; Stage 1 output regression | S2-ARCH |
| 2.2 Persistence and grants | New migrations for M365 tables, m365:read, typed links, maintenance role; extend PROTECTED_TABLES; preserve all old migrations | Prisma validate/generate, real PostgreSQL migrate/runtime queries, RLS/FK/role tests, zero drift | 2.1 |
| 2.3 Permission and compatibility boundary | Filter old context/mapping paths; extend mapping services safely; new actor grants explicit; no M365 IDs to old callers | Same-client missing permission, cross-client/workspace/connection denial; fixture + DB; generic CLI bypass probes | 2.2 |
| **S2-A** | Contracts/schema/auth accepted | Evidence A1–A4, R1/R2 below | 2.3 |
| 2.4 Token and Graph adapters | connectors/microsoft365/auth.ts, http.ts, contract.ts, connector.ts; fixed authorities, per-token tenant check, allowlisted projection | Mock token/Graph requests; wrong tenant, malicious nextLink/redirect, expiry, minimal scopes, 403/429 | S2-A |
| 2.5 Directory generations | packages/m365/directory.ts; durable staging, atomic publication, active external mappings | Full/empty/malformed/partial/oversized reads, first-read race, disappearing object, revoke during I/O | 2.4 |
| 2.6 Sign-in windows | packages/m365/windows.ts + ingest.ts; durable claims, versions, bounded splitting, gaps/retry | Two workers, crash every boundary, same timestamp, duplicate/conflicting ID, cap, 429 delay, restart | 2.4 |
| **S2-B** | Mock/recorded connectors and recovery accepted | Evidence B1–B6 | 2.5, 2.6 |
| 2.7 Deterministic correlation | packages/correlation/resolve.ts + query.ts; separate device/person relations, snapshot-bound paging | Exact-ID positives; negative matching, stale/rejected links, guest, missing device, changed mapping/cursor | S2-B |
| 2.8 Read API/tools/CLI | Separate correlation endpoint; two read tools; operator commands in focused module, strict schemas | HTTP/CLI authorization, response redaction, read-only policy, ledger success/failure | 2.7 |
| 2.9 Retention and operational instructions | Expiry in queries; confined maintenance role and bounded cleanup; update RUNBOOK with M365 section/module | Cleanup crash/retry/FK/role tests; no audit deletion; stale/expired identity invisible | 2.8 |
| 2.10 Acceptance and handoff | Full synthetic journey, dated evidence and clear live status; maintain context map | Full local required suite + acceptance matrix; independent S2-C review | 2.9 |
| **S2-C** | Engineering implementation accepted | Evidence C1–C6 + regressions; no obligatory findings | 2.10 |
| **S2-LIVE** | Tenant-bound real reads and one verified correlation | Account authorization, permissions, license/capability, existing Stage 1 live evidence, L1–L4 | S2-C + account prerequisites |

## Checkpoint report

For each gate record exact commit, dirty files if any, schema delta, commands/results, new tests,
findings with severity and reproduction, supported environments, remaining live gates and next task.
New report: `docs/stage2/IMPLEMENTATION_STATUS.md` (created during implementation), with evidence files routed
under `verification/stage2/`. Do not overwrite Stage 1 independent review or reuse its test counts as new results.
Do not commit credentials, live UPNs, tokens, tenant IDs or response bodies into reports.

## Required checks once implementation changes code/schema

Use existing package scripts and throwaway PostgreSQL harness; no persistent tenant database for tests.

```text
npm run schema:validate
npm run db:generate
npm run typecheck
npm test
npm run api:build
npm run api:smoke
npm run test:pg
npm run db:check:pg17
npm run db:check:drift
git diff --check
```

PostgreSQL scripts need ATLAS_PG_ADMIN_URL; provide through the established local test setup, not a committed secret.
Add new tests to existing npm test/test:pg globs. Update explicit SQL constraint/role checks to include new tables.
Tests are split by behavior (auth, generations, windows, recovery, correlation, retention), shared synthetic fixtures
in small support modules. No active file exceeds 700 lines. Run focused tests during changes and full required gates
at checkpoint; repeat only when changes/failures justify it.

## Known Stage 1 limitations to carry forward

Live Atera/Huntress/Decisions not run; scheduler/long-lived worker, lease renewal, vault/provisioning,
retention of old RawEvent, production auth and dependency findings remain tracked in CHECKPOINT_REPORT.
Stage 2's bounded M365 jobs/maintenance role do not silently claim to fix those older limitations.
An independent review of this plan is not an approval of frozen code, dependencies or deployment.
